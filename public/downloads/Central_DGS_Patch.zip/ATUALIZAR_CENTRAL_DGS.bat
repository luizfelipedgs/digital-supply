@echo off
chcp 65001 > nul
title Central DGS - Atualizador Automático
color 0A

echo =======================================================================
echo          CENTRAL DGS - ATUALIZADOR OFICIAL (DIGITAL SUPPLY)
echo =======================================================================
echo.
echo Verificando ambiente de execução...

cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    set "PYTHON_CMD=.venv\Scripts\python.exe"
) else (
    set "PYTHON_CMD=python"
)

echo Iniciando verificação de atualizações...
echo.
"%PYTHON_CMD%" -m backend.updater

exit /b 0
