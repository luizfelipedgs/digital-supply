/**
 * DGS - Download em Massa
 * Background Service Worker (Manifest V3)
 * Gerencia downloads nativos com resolução direta de mídia, sem APIs DOM incompatíveis
 */

// Permite abrir o Side Panel com clique no ícone da extensão
if (chrome.sidePanel && typeof chrome.sidePanel.setPanelBehavior === "function") {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((err) => console.warn("Aviso ao configurar side panel:", err));
}

// Estado da Fila de Downloads
const queueState = {
  active: false,
  items: [],
  currentIndex: 0,
  total: 0,
  successCount: 0,
  failCount: 0,
  cancelled: false,
};

// --- CONVERSOR DE SHORTCODE DO INSTAGRAM PARA MEDIA ID ---
function getMediaIdFromShortcode(shortcode) {
  if (!shortcode || typeof shortcode !== "string") return null;
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  let mediaId = 0n;
  for (const char of shortcode) {
    const val = alphabet.indexOf(char);
    if (val < 0) return null;
    mediaId = mediaId * 64n + BigInt(val);
  }
  return mediaId.toString();
}

// --- RESOLVEDOR DE LINKS HD ORIGINAIS ---
async function resolveDirectVideoUrl(item) {
  if (item.videoUrl && typeof item.videoUrl === "string" && item.videoUrl.startsWith("http")) {
    return item.videoUrl;
  }

  // 1. INSTAGRAM
  if (item.platform === "instagram" && item.code) {
    // 1.1 Tenta Endpoint de Info Oficial do Instagram via Media ID
    const mediaId = getMediaIdFromShortcode(item.code);
    if (mediaId) {
      try {
        const infoUrl = `https://www.instagram.com/api/v1/media/${mediaId}/info/`;
        const res = await fetch(infoUrl, {
          headers: {
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
          },
        });
        if (res.ok) {
          const json = await res.json();
          const mediaObj = json?.items?.[0];
          if (mediaObj) {
            // Se tiver versões de vídeo
            if (Array.isArray(mediaObj.video_versions) && mediaObj.video_versions.length > 0) {
              const bestVideo = mediaObj.video_versions[0].url;
              if (bestVideo) return bestVideo;
            }
            // Se for carrossel com vídeo
            if (Array.isArray(mediaObj.carousel_media) && mediaObj.carousel_media.length > 0) {
              const firstVideo = mediaObj.carousel_media.find(
                (c) => Array.isArray(c.video_versions) && c.video_versions.length > 0
              );
              if (firstVideo) return firstVideo.video_versions[0].url;
            }
          }
        }
      } catch (err) {
        console.warn("[DGS] Falha ao consultar endpoint de info do Instagram:", err);
      }
    }

    // 1.2 Fallback: Extrai HTML da página do Reel
    try {
      const pageUrl = `https://www.instagram.com/reel/${item.code}/`;
      const res = await fetch(pageUrl, {
        headers: {
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      });
      const html = await res.text();

      const matchVersions = html.match(/"video_versions":\s*(\[[^\]]+\])/);
      if (matchVersions) {
        try {
          const list = JSON.parse(matchVersions[1]);
          if (Array.isArray(list) && list.length > 0 && list[0].url) {
            return list[0].url;
          }
        } catch (e) {}
      }

      const matchMp4 = html.match(/(https:[^"'\s<>\\]+\.mp4[^"'\s<>\\]*)/);
      if (matchMp4) {
        return matchMp4[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
      }
    } catch (err) {
      console.warn("[DGS] Fallback HTML do Instagram falhou:", err);
    }
  }

  // 2. TIKTOK
  if (item.platform === "tiktok" && item.postUrl) {
    try {
      const res = await fetch(item.postUrl);
      const html = await res.text();
      const matchPlayAddr = html.match(/"playAddr":\s*"([^"]+)"/);
      if (matchPlayAddr) {
        return matchPlayAddr[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/");
      }
    } catch (e) {}
  }

  return null;
}

// --- FUNÇÃO DE DOWNLOAD NATIVO CHROME ---
function executeSingleDownload(item) {
  return new Promise((resolve, reject) => {
    if (!item.videoUrl) {
      return reject(new Error("URL do arquivo de vídeo não encontrada."));
    }

    const cleanAuthor = (item.author || "perfil").replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 30);
    const cleanId = (item.code || item.rawId || item.id || Date.now().toString()).replace(/[^a-zA-Z0-9_\-]/g, "_");
    const platform = item.platform || "social";
    const filename = `DGS_Downloads/${platform}_${cleanAuthor}/${cleanId}.mp4`;

    chrome.downloads.download(
      {
        url: item.videoUrl,
        filename: filename,
        conflictAction: "uniquify",
        saveAs: false,
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!downloadId) {
          reject(new Error("Chrome não iniciou o download."));
        } else {
          resolve(downloadId);
        }
      }
    );
  });
}

function broadcastProgress(data) {
  chrome.runtime.sendMessage({
    action: "DOWNLOAD_PROGRESS_UPDATE",
    payload: data,
  }).catch(() => {
    // Painel ou content script podem estar desacoplados
  });
}

// --- EXECUÇÃO DA FILA DE DOWNLOADS EM MASSA ---
async function startDownloadQueue(items) {
  if (queueState.active) {
    console.warn("Fila de download já ativa.");
    return;
  }

  queueState.active = true;
  queueState.cancelled = false;
  queueState.items = items;
  queueState.total = items.length;
  queueState.currentIndex = 0;
  queueState.successCount = 0;
  queueState.failCount = 0;

  broadcastProgress({
    status: "started",
    current: 0,
    total: queueState.total,
    percentage: 0,
  });

  const DELAY_MS = 1200;

  for (let i = 0; i < items.length; i++) {
    if (queueState.cancelled) {
      console.log("Download de lote cancelado.");
      break;
    }

    queueState.currentIndex = i + 1;
    const item = items[i];

    if (!item.videoUrl) {
      broadcastProgress({
        status: "resolving",
        current: queueState.currentIndex,
        total: queueState.total,
        percentage: Math.round(((i + 0.3) / queueState.total) * 100),
        currentAuthor: item.author || "perfil",
        currentPlatform: item.platform || "video",
      });

      try {
        item.videoUrl = await resolveDirectVideoUrl(item);
      } catch (e) {
        console.warn(`[DGS] Erro ao resolver URL de ${item.id}:`, e);
      }
    }

    broadcastProgress({
      status: "downloading",
      current: queueState.currentIndex,
      total: queueState.total,
      percentage: Math.round(((i + 0.8) / queueState.total) * 100),
      currentAuthor: item.author || "perfil",
      currentPlatform: item.platform || "video",
    });

    try {
      if (!item.videoUrl) throw new Error("Link HD não pôde ser resolvido.");
      await executeSingleDownload(item);
      queueState.successCount++;
    } catch (err) {
      console.error(`[DGS] Falha ao baixar ${item.id}:`, err);
      queueState.failCount++;
    }

    if (i < items.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, DELAY_MS));
    }
  }

  queueState.active = false;
  broadcastProgress({
    status: "completed",
    current: queueState.total,
    total: queueState.total,
    percentage: 100,
    successCount: queueState.successCount,
    failCount: queueState.failCount,
  });
}

// --- LISTENER CENTRAL DE MENSAGENS DO SERVICE WORKER ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return false;

  // 1. Download Individual (Card na Grade do Perfil)
  if (message.action === "START_SINGLE_DOWNLOAD") {
    const item = message.video || message.item;
    if (!item) {
      sendResponse({ success: false, error: "Dados do vídeo não informados." });
      return false;
    }

    (async () => {
      try {
        if (!item.videoUrl) {
          item.videoUrl = await resolveDirectVideoUrl(item);
        }
        if (!item.videoUrl) {
          throw new Error("Não foi possível obter o link do arquivo de vídeo.");
        }
        const downloadId = await executeSingleDownload(item);
        sendResponse({ success: true, downloadId });
      } catch (err) {
        console.error("[DGS] Erro no download individual:", err);
        sendResponse({ success: false, error: err.message || "Falha no download." });
      }
    })();

    return true; // Mantém porta assíncrona aberta
  }

  // 2. Download em Lote (Botão "Download All" no Perfil ou Sidepanel)
  if (message.action === "START_BATCH_DOWNLOAD") {
    const rawItems = Array.isArray(message.items) ? message.items : [];
    const safeItems = rawItems.slice(0, 100);

    if (safeItems.length === 0) {
      sendResponse({ success: false, message: "Nenhum vídeo fornecido." });
      return false;
    }

    startDownloadQueue(safeItems);
    sendResponse({ success: true, count: safeItems.length });
    return true;
  }

  // 3. Cancelamento do Lote
  if (message.action === "CANCEL_BATCH_DOWNLOAD") {
    queueState.cancelled = true;
    queueState.active = false;
    broadcastProgress({ status: "cancelled", message: "Download cancelado." });
    sendResponse({ success: true });
    return true;
  }

  // 4. Status atual da fila
  if (message.action === "GET_DOWNLOAD_STATUS") {
    sendResponse({
      active: queueState.active,
      currentIndex: queueState.currentIndex,
      total: queueState.total,
      successCount: queueState.successCount,
      failCount: queueState.failCount,
    });
    return true;
  }

  // 5. Ping de Verificação
  if (message.action === "PING") {
    sendResponse({ status: "ready" });
    return false;
  }

  return false;
});
