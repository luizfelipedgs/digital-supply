/**
 * DGS - Download em Massa
 * Injected Script (Executa no contexto MAIN da página)
 * Intercepta silenciosamente APIs de rede e hidratação do TikTok e Instagram
 */

(function () {
  const SCRIPT_TAG = "[DGS Extrator]";

  function notifyVideosFound(videos, source) {
    if (!videos || !videos.length) return;
    window.postMessage(
      {
        type: "DGS_VIDEOS_DISCOVERED",
        source,
        videos,
      },
      "*"
    );
  }

  // --- PARSER TIKTOK ---
  function parseTikTokData(json) {
    const list = json?.itemList || json?.items || [];
    if (!Array.isArray(list) || !list.length) return [];

    const parsed = [];
    for (const item of list) {
      try {
        const id = item.id || item.video?.id;
        if (!id) continue;

        const videoUrl = item.video?.playAddr || item.video?.downloadAddr || null;
        const metrics = {
          views: Number(item.stats?.playCount || 0),
          likes: Number(item.stats?.diggCount || 0),
          comments: Number(item.stats?.commentCount || 0),
          shares: Number(item.stats?.shareCount || 0),
        };

        const caption = item.desc || "";
        const author = item.author?.uniqueId || item.author?.nickname || "tiktok_creator";
        const thumbnailUrl = item.video?.cover || item.video?.originCover || "";
        const createdAt = item.createTime ? Number(item.createTime) * 1000 : Date.now();

        const hashtags = [];
        if (Array.isArray(item.textExtra)) {
          for (const extra of item.textExtra) {
            if (extra.hashtagName) hashtags.push(extra.hashtagName.toLowerCase());
          }
        }
        const matches = caption.match(/#[a-zA-Z0-9_\u00C0-\u00FF]+/g);
        if (matches) {
          matches.forEach((tag) => {
            const clean = tag.replace("#", "").toLowerCase();
            if (!hashtags.includes(clean)) hashtags.push(clean);
          });
        }

        parsed.push({
          id: `tt_${id}`,
          rawId: id,
          platform: "tiktok",
          author,
          caption,
          hashtags,
          metrics,
          videoUrl,
          thumbnailUrl,
          createdAt,
        });
      } catch (e) {}
    }
    return parsed;
  }

  // --- PARSER INSTAGRAM ---
  function parseInstagramData(json) {
    const parsed = [];

    // Vasculha recursivamente nós de mídia dentro do JSON do Instagram
    function extractMediaNodes(obj, depth = 0) {
      if (!obj || depth > 8 || typeof obj !== "object") return;

      // Se for um nó de mídia do Instagram
      if (
        (obj.pk || obj.id || obj.code || obj.shortcode) &&
        (obj.is_video !== undefined || obj.video_versions || obj.media_type !== undefined || obj.video_view_count !== undefined)
      ) {
        processNode(obj);
      }

      // Varre listas
      if (Array.isArray(obj)) {
        for (const item of obj) {
          extractMediaNodes(item, depth + 1);
        }
        return;
      }

      // Varre chaves de objetos
      for (const key of Object.keys(obj)) {
        if (["user", "edges", "items", "node", "data", "timeline", "clips", "xdt_api__v1__clips__user__connection_v2", "xdt_api__v1__feed__user_timeline_graphql_connection"].includes(key)) {
          extractMediaNodes(obj[key], depth + 1);
        }
      }
    }

    function processNode(node) {
      try {
        if (!node) return;
        // Se for explicitamente foto (media_type === 1 ou is_video === false sem video_versions), ignora
        if (node.media_type === 1 || (node.is_video === false && !node.video_versions && !node.video_url)) {
          return;
        }

        const id = node.id || node.pk || node.code;
        const code = node.shortcode || node.code || id;
        if (!code) return;

        let videoUrl = node.video_url || null;
        if (!videoUrl && Array.isArray(node.video_versions) && node.video_versions.length > 0) {
          videoUrl = node.video_versions[0].url;
        }

        const views = Number(
          node.video_view_count ||
          node.play_count ||
          node.video_play_count ||
          node.view_count ||
          0
        );

        const likes = Number(
          node.edge_media_preview_like?.count ||
          node.like_count ||
          0
        );

        const comments = Number(
          node.edge_media_to_comment?.count ||
          node.comment_count ||
          0
        );

        let caption = "";
        if (node.edge_media_to_caption?.edges?.[0]?.node?.text) {
          caption = node.edge_media_to_caption.edges[0].node.text;
        } else if (node.caption?.text) {
          caption = node.caption.text;
        }

        const author = node.owner?.username || node.user?.username || "instagram_creator";
        const thumbnailUrl =
          node.display_url ||
          node.thumbnail_src ||
          node.image_versions2?.candidates?.[0]?.url ||
          "";

        const createdAt = node.taken_at_timestamp
          ? Number(node.taken_at_timestamp) * 1000
          : (node.taken_at ? Number(node.taken_at) * 1000 : Date.now());

        const hashtags = [];
        const matches = caption.match(/#[a-zA-Z0-9_\u00C0-\u00FF]+/g);
        if (matches) {
          matches.forEach((tag) => {
            const clean = tag.replace("#", "").toLowerCase();
            if (!hashtags.includes(clean)) hashtags.push(clean);
          });
        }

        parsed.push({
          id: `ig_${code}`,
          rawId: id,
          code,
          platform: "instagram",
          author,
          caption,
          hashtags,
          metrics: {
            views,
            likes,
            comments,
            shares: 0,
          },
          videoUrl,
          thumbnailUrl,
          postUrl: `https://www.instagram.com/reel/${code}/`,
          createdAt,
        });
      } catch (e) {}
    }

    extractMediaNodes(json);
    return parsed;
  }

  // --- INTERCEPÇÃO DE REDE FETCH ---
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    try {
      let url = "";
      if (typeof args[0] === "string") url = args[0];
      else if (args[0] && args[0].url) url = args[0].url;

      const isTikTok = url.includes("tiktok.com") || window.location.hostname.includes("tiktok.com");
      const isInstagram = url.includes("instagram.com") || window.location.hostname.includes("instagram.com");

      // Intercepta endpoints de feed, clips e GraphQL
      const shouldInspect =
        url.includes("/api/graphql") ||
        url.includes("/graphql/query") ||
        url.includes("/api/v1/") ||
        url.includes("/api/item_list") ||
        url.includes("/api/recommend/item_list");

      if ((isTikTok || isInstagram) && shouldInspect) {
        const clone = response.clone();
        clone.json().then((json) => {
          if (isTikTok) {
            const videos = parseTikTokData(json);
            if (videos.length) notifyVideosFound(videos, "tiktok_fetch");
          } else if (isInstagram) {
            const videos = parseInstagramData(json);
            if (videos.length) notifyVideosFound(videos, "instagram_fetch");
          }
        }).catch(() => {});
      }
    } catch (e) {}
    return response;
  };

  // --- INTERCEPÇÃO XHR ---
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._dgs_url = typeof url === "string" ? url : "";
    return originalOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener("load", function () {
      try {
        const url = this._dgs_url || "";
        const isTikTok = url.includes("tiktok.com") || window.location.hostname.includes("tiktok.com");
        const isInstagram = url.includes("instagram.com") || window.location.hostname.includes("instagram.com");

        if ((isTikTok || isInstagram) && this.responseText) {
          const json = JSON.parse(this.responseText);
          if (isTikTok) {
            const videos = parseTikTokData(json);
            if (videos.length) notifyVideosFound(videos, "tiktok_xhr");
          } else if (isInstagram) {
            const videos = parseInstagramData(json);
            if (videos.length) notifyVideosFound(videos, "instagram_xhr");
          }
        }
      } catch (e) {}
    });
    return originalSend.apply(this, args);
  };

  console.log(`${SCRIPT_TAG} Motor de interceptação ativo.`);
})();
