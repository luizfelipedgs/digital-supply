/**
 * DGS - Download em Massa
 * Content Script (Contexto ISOLATED)
 * Injeta o botão "Download all" no perfil, botões nos cards e monitora rolagem
 */

(function () {
  const SCRIPT_NAME = "[DGS Content Script]";
  const tabVideosCache = new Map();
  let activeBatchDownloading = false;

  // --- INJEÇÃO DOS ESTILOS CSS OFICIAIS (Perfil e Cards) ---
  function injectAllStyles() {
    if (document.getElementById("dgs-injected-styles")) return;

    const style = document.createElement("style");
    style.id = "dgs-injected-styles";
    style.textContent = `
      /* ============================================================
         1. BOTÃO "DOWNLOAD ALL" NO PERFIL (EXATO DO PRINT DO ZETRR)
         ============================================================ */
      .dgs-download-all-btn {
        -webkit-appearance: none;
        appearance: none;
        position: relative;
        isolation: isolate;
        display: inline-flex !important;
        align-items: center;
        gap: 10px;
        min-height: 44px;
        margin: 12px 0 8px 0;
        padding: 6px 18px 6px 10px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.42);
        border-radius: 14px;
        background:
          radial-gradient(circle at 18% 0%, rgba(255, 255, 255, 0.34), transparent 38%),
          linear-gradient(118deg, #6d35f2 0%, #9c30ec 47%, #ef3f8f 100%);
        box-shadow:
          0 9px 22px rgba(111, 45, 224, 0.25),
          0 2px 7px rgba(239, 63, 143, 0.18),
          inset 0 1px 0 rgba(255, 255, 255, 0.3);
        color: #ffffff !important;
        cursor: pointer;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        text-align: left;
        transform: translateY(0);
        transition: transform 0.2s ease, box-shadow 0.2s ease, filter 0.2s ease;
        z-index: 99;
        user-select: none;
      }

      .dgs-download-all-btn:hover {
        filter: saturate(1.15) brightness(1.05);
        transform: translateY(-2px);
        box-shadow:
          0 13px 28px rgba(111, 45, 224, 0.35),
          0 4px 12px rgba(239, 63, 143, 0.25),
          inset 0 1px 0 rgba(255, 255, 255, 0.4);
      }

      .dgs-download-all-btn:active {
        transform: translateY(0) scale(0.98);
      }

      .dgs-download-all-btn:disabled {
        cursor: wait;
        opacity: 0.85;
        transform: none;
      }

      .dgs-download-all-btn__icon {
        position: relative;
        z-index: 1;
        display: grid;
        width: 32px;
        height: 32px;
        flex: 0 0 32px;
        place-items: center;
        border: 1px solid rgba(255, 255, 255, 0.36);
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.18);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(8px);
      }

      .dgs-download-all-btn__icon svg {
        width: 19px;
        height: 19px;
        stroke: #ffffff;
      }

      .dgs-download-all-btn__label {
        position: relative;
        z-index: 1;
        display: flex;
        flex-direction: column;
        line-height: 1.1;
      }

      .dgs-download-all-btn__label strong {
        color: #ffffff;
        font-size: 13px;
        font-weight: 750;
        letter-spacing: -0.01em;
      }

      .dgs-download-all-btn__label small {
        margin-top: 2px;
        color: rgba(255, 255, 255, 0.82);
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }

      .dgs-download-all-btn__shine {
        position: absolute;
        z-index: 0;
        top: -40%;
        bottom: -40%;
        left: -42%;
        width: 30%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.35), transparent);
        transform: skewX(-18deg);
        transition: left 0.55s ease;
      }

      .dgs-download-all-btn:hover .dgs-download-all-btn__shine {
        left: 116%;
      }

      .dgs-download-all-btn.is-busy .dgs-download-all-btn__icon svg {
        animation: dgs-spin 1s linear infinite;
      }

      /* ============================================================
         2. BOTÃO DE DOWNLOAD DIRETO NO CARD / REEL DA GRADE
         ============================================================ */
      .dgs-card-download-btn {
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) scale(0.95) !important;
        width: 44px !important;
        height: 44px !important;
        border-radius: 50% !important;
        background: rgba(0, 0, 0, 0.7) !important;
        backdrop-filter: blur(6px) !important;
        -webkit-backdrop-filter: blur(6px) !important;
        border: 1.5px solid rgba(255, 255, 255, 0.4) !important;
        color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        z-index: 99999 !important;
        opacity: 0 !important;
        transition: opacity 0.2s ease, transform 0.2s ease, background 0.2s ease, border-color 0.2s ease !important;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6) !important;
        pointer-events: auto !important;
        user-select: none !important;
        padding: 0 !important;
        margin: 0 !important;
        outline: none !important;
      }

      /* Revela no hover do card */
      a:hover > .dgs-card-download-btn,
      div:hover > .dgs-card-download-btn,
      .dgs-card-download-btn:hover {
        opacity: 1 !important;
        transform: translate(-50%, -50%) scale(1) !important;
      }

      .dgs-card-download-btn:hover {
        background: rgba(154, 205, 50, 0.95) !important;
        border-color: #9acd32 !important;
        color: #070805 !important;
        box-shadow: 0 0 20px rgba(154, 205, 50, 0.65) !important;
        transform: translate(-50%, -50%) scale(1.1) !important;
      }

      .dgs-card-download-btn:active {
        transform: translate(-50%, -50%) scale(0.92) !important;
      }

      .dgs-card-download-btn.dgs-loading {
        opacity: 1 !important;
        background: rgba(13, 15, 10, 0.9) !important;
        border-color: #9acd32 !important;
        cursor: wait !important;
      }

      .dgs-card-download-btn.dgs-loading svg {
        animation: dgs-spin 0.8s linear infinite !important;
        stroke: #9acd32 !important;
      }

      .dgs-card-download-btn.dgs-success {
        opacity: 1 !important;
        background: #22c55e !important;
        border-color: #4ade80 !important;
        color: #ffffff !important;
        transform: translate(-50%, -50%) scale(1.1) !important;
        box-shadow: 0 0 22px rgba(34, 197, 94, 0.7) !important;
      }

      .dgs-card-download-btn.dgs-error {
        opacity: 1 !important;
        background: #ef4444 !important;
        border-color: #f87171 !important;
        color: #ffffff !important;
      }

      @keyframes dgs-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }

      /* ============================================================
         3. PAINEL FLUTUANTE DE PROGRESSO (AO BAIXAR NA PÁGINA)
         ============================================================ */
      .dgs-floating-panel {
        position: fixed;
        right: 22px;
        bottom: 22px;
        z-index: 2147483646;
        width: min(360px, calc(100vw - 32px));
        box-sizing: border-box;
        overflow: hidden;
        padding: 16px;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 18px;
        background: rgba(13, 15, 10, 0.92);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        box-shadow: 0 16px 40px rgba(0, 0, 0, 0.7);
        color: #f3f4f6;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 13px;
        transition: all 0.3s ease;
      }

      .dgs-floating-panel.hidden {
        display: none !important;
      }

      .dgs-floating-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }

      .dgs-floating-title {
        font-size: 13px;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .dgs-floating-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #9acd32;
        box-shadow: 0 0 8px #9acd32;
      }

      .dgs-floating-close {
        background: transparent;
        border: none;
        color: #9ca3af;
        font-size: 18px;
        cursor: pointer;
        line-height: 1;
        padding: 2px 6px;
      }

      .dgs-floating-close:hover {
        color: #fff;
      }

      .dgs-floating-desc {
        font-size: 11px;
        color: #9ca3af;
        margin-bottom: 10px;
        line-height: 1.3;
      }

      .dgs-floating-track {
        width: 100%;
        height: 5px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 4px;
        overflow: hidden;
        margin-bottom: 10px;
      }

      .dgs-floating-fill {
        height: 100%;
        width: 0%;
        background: linear-gradient(90deg, #6d35f2, #ef3f8f, #9acd32);
        border-radius: 4px;
        transition: width 0.3s ease;
      }

      .dgs-floating-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 11px;
      }

      .dgs-floating-btn-cancel {
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.4);
        color: #ef4444;
        border-radius: 6px;
        padding: 3px 8px;
        cursor: pointer;
        font-size: 11px;
      }

      .dgs-floating-btn-cancel:hover {
        background: rgba(239, 68, 68, 0.25);
      }
    `;

    (document.head || document.documentElement).appendChild(style);
  }

  // --- ÍCONES SVG PARA OS BOTÕES ---
  const SVG_DOWNLOAD = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
  `;

  const SVG_LOADING = `
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
      <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
    </svg>
  `;

  const SVG_SUCCESS = `
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  `;

  const SVG_ERROR = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="8" x2="12" y2="12"></line>
      <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>
  `;

  // --- PAINEL FLUTUANTE DE DOWNLOADS NA PÁGINA ---
  let floatingPanel = null;
  function getOrCreateFloatingPanel() {
    if (floatingPanel && floatingPanel.isConnected) return floatingPanel;

    floatingPanel = document.createElement("div");
    floatingPanel.id = "dgs-floating-panel";
    floatingPanel.className = "dgs-floating-panel hidden";
    floatingPanel.innerHTML = `
      <div class="dgs-floating-header">
        <div class="dgs-floating-title">
          <span class="dgs-floating-dot"></span>
          <span id="dgs-panel-title">DGS - Download em Massa</span>
        </div>
        <button id="dgs-panel-close" class="dgs-floating-close" title="Fechar">&times;</button>
      </div>
      <p id="dgs-panel-desc" class="dgs-floating-desc">Iniciando download...</p>
      <div class="dgs-floating-track">
        <div id="dgs-panel-fill" class="dgs-floating-fill"></div>
      </div>
      <div class="dgs-floating-footer">
        <span id="dgs-panel-count">0/0</span>
        <button id="dgs-panel-cancel" class="dgs-floating-btn-cancel">Cancelar</button>
      </div>
    `;

    document.body.appendChild(floatingPanel);

    floatingPanel.querySelector("#dgs-panel-close").onclick = () => {
      floatingPanel.classList.add("hidden");
    };

    floatingPanel.querySelector("#dgs-panel-cancel").onclick = () => {
      chrome.runtime.sendMessage({ action: "CANCEL_BATCH_DOWNLOAD" });
      updateFloatingPanel("Download cancelado", 0, "Cancelado pelo usuário.");
      setTimeout(() => floatingPanel.classList.add("hidden"), 2000);
    };

    return floatingPanel;
  }

  function updateFloatingPanel(title, pct, desc, countText) {
    const panel = getOrCreateFloatingPanel();
    panel.classList.remove("hidden");
    if (title) panel.querySelector("#dgs-panel-title").textContent = title;
    if (typeof pct === "number") panel.querySelector("#dgs-panel-fill").style.width = `${pct}%`;
    if (desc) panel.querySelector("#dgs-panel-desc").textContent = desc;
    if (countText) panel.querySelector("#dgs-panel-count").textContent = countText;
  }

  // --- INJEÇÃO DO BOTÃO "DOWNLOAD ALL" NO PERFIL (EXATO DO PRINT) ---
  function injectProfileDownloadAllButton() {
    if (!document.body) return;

    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");

    if (isInstagram) {
      // Localiza o header do perfil do Instagram
      const headerSection = document.querySelector("header section") || document.querySelector("header");
      if (!headerSection) return;
      if (headerSection.querySelector(".dgs-download-all-btn")) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dgs-download-all-btn";
      btn.setAttribute("aria-label", "Download all reels and posts in original quality");
      btn.title = "Baixar todos os vídeos deste perfil em alta qualidade";
      btn.innerHTML = `
        <span class="dgs-download-all-btn__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3v11m0 0 4-4m-4 4-4-4M5 18v2h14v-2" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </span>
        <span class="dgs-download-all-btn__label">
          <strong>Download all</strong>
          <small>ORIGINAL QUALITY</small>
        </span>
        <span class="dgs-download-all-btn__shine" aria-hidden="true"></span>
      `;

      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        triggerBulkDownloadFromPage(btn);
      });

      // Insere logo abaixo da bio/descrição no header
      const bioDiv = headerSection.querySelector("div.-vDIg, div._aa_c") || headerSection.lastElementChild;
      if (bioDiv && bioDiv.parentNode === headerSection) {
        headerSection.insertBefore(btn, bioDiv.nextSibling);
      } else {
        headerSection.appendChild(btn);
      }
    }

    if (isTikTok) {
      const header = document.querySelector('[data-e2e="user-page-header"]') || document.querySelector("header");
      if (!header || header.querySelector(".dgs-download-all-btn")) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dgs-download-all-btn";
      btn.title = "Baixar todos os vídeos do perfil TikTok";
      btn.innerHTML = `
        <span class="dgs-download-all-btn__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3v11m0 0 4-4m-4 4-4-4M5 18v2h14v-2" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </span>
        <span class="dgs-download-all-btn__label">
          <strong>Download all</strong>
          <small>ORIGINAL QUALITY</small>
        </span>
        <span class="dgs-download-all-btn__shine" aria-hidden="true"></span>
      `;

      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        triggerBulkDownloadFromPage(btn);
      });

      header.appendChild(btn);
    }
  }

  // Dispara o download em massa com feedback visual na página
  function triggerBulkDownloadFromPage(btn) {
    if (activeBatchDownloading) return;

    scanCurrentPageDOM();
    const allVideos = Array.from(tabVideosCache.values()).slice(0, 100);

    if (allVideos.length === 0) {
      alert("Role um pouco a página para carregar os vídeos do perfil antes de baixar.");
      return;
    }

    activeBatchDownloading = true;
    if (btn) btn.classList.add("is-busy");

    updateFloatingPanel(
      "DGS - Download em Massa",
      5,
      `Iniciando lote de ${allVideos.length} vídeos...`,
      `0/${allVideos.length}`
    );

    chrome.runtime.sendMessage(
      {
        action: "START_BATCH_DOWNLOAD",
        items: allVideos,
      },
      (res) => {
        if (chrome.runtime.lastError || !res || !res.success) {
          activeBatchDownloading = false;
          if (btn) btn.classList.remove("is-busy");
          updateFloatingPanel("Erro no Download", 0, res?.message || "Não foi possível iniciar o download.");
        }
      }
    );
  }

  // --- ANEXA BOTÃO INDIVIDUAL DIRETO NA GRADE DO CARD (EXATO DO PRINT) ---
  function attachDownloadButtonToTile(containerEl, videoItem) {
    if (!containerEl || !videoItem) return;

    const existingBtn = containerEl.querySelector(".dgs-card-download-btn");
    if (existingBtn) {
      existingBtn._dgsVideo = videoItem;
      return;
    }

    const compStyle = window.getComputedStyle(containerEl);
    if (compStyle.position === "static") {
      containerEl.style.position = "relative";
    }

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "dgs-card-download-btn";
    btn.title = "Baixar este vídeo em alta qualidade";
    btn.setAttribute("aria-label", "Baixar vídeo");
    btn.innerHTML = SVG_DOWNLOAD;
    btn._dgsVideo = videoItem;

    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (btn.classList.contains("dgs-loading")) return;

      btn.classList.remove("dgs-success", "dgs-error");
      btn.classList.add("dgs-loading");
      btn.innerHTML = SVG_LOADING;

      const itemToDownload = btn._dgsVideo || videoItem;

      chrome.runtime.sendMessage(
        {
          action: "START_SINGLE_DOWNLOAD",
          video: itemToDownload,
        },
        (res) => {
          btn.classList.remove("dgs-loading");
          if (chrome.runtime.lastError || !res || !res.success) {
            btn.classList.add("dgs-error");
            btn.innerHTML = SVG_ERROR;
            setTimeout(() => {
              btn.classList.remove("dgs-error");
              btn.innerHTML = SVG_DOWNLOAD;
            }, 2500);
          } else {
            btn.classList.add("dgs-success");
            btn.innerHTML = SVG_SUCCESS;
            setTimeout(() => {
              btn.classList.remove("dgs-success");
              btn.innerHTML = SVG_DOWNLOAD;
            }, 2500);
          }
        }
      );
    });

    containerEl.appendChild(btn);
  }

  // --- PARSERS E EXTRATORES DE DADOS ---
  function parseMetricString(str) {
    if (!str) return 0;
    const clean = str.toString().trim().toLowerCase().replace(/\s+/g, "");
    if (!clean) return 0;

    let multiplier = 1;
    let numPart = clean;

    if (/bi$|b$/i.test(clean)) {
      multiplier = 1000000000;
      numPart = clean.replace(/bi$|b$/i, "");
    } else if (/mi$/i.test(clean) || (clean.endsWith("m") && !clean.endsWith("mil"))) {
      multiplier = 1000000;
      numPart = clean.replace(/mi$|m$/i, "");
    } else if (clean.endsWith("mil") || clean.endsWith("k")) {
      multiplier = 1000;
      numPart = clean.replace(/mil$|k$/i, "");
    }

    if (numPart.includes(",")) {
      numPart = numPart.replace(/\./g, "").replace(",", ".");
    } else if (numPart.includes(".")) {
      if (/^\d{1,3}\.\d{3}$/.test(numPart) && multiplier === 1) {
        numPart = numPart.replace(".", "");
      }
    }

    const val = parseFloat(numPart);
    return isNaN(val) ? 0 : Math.round(val * multiplier);
  }

  function getAuthorFromPage() {
    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");

    if (isTikTok) {
      const match = window.location.pathname.match(/@([a-zA-Z0-9_.-]+)/);
      if (match) return match[1];
    }

    if (isInstagram) {
      const pathParts = window.location.pathname.split("/").filter(Boolean);
      if (pathParts.length > 0 && !["explore", "direct", "stories", "reels"].includes(pathParts[0])) {
        return pathParts[0].replace("@", "");
      }
    }

    return "perfil";
  }

  function extractThumbnail(el) {
    if (!el) return "";

    const img = el.querySelector("img");
    if (img) {
      if (img.currentSrc && !img.currentSrc.startsWith("data:") && !img.currentSrc.startsWith("blob:")) {
        return img.currentSrc;
      }
      if (img.src && !img.src.startsWith("data:") && !img.src.startsWith("blob:")) {
        return img.src;
      }
      const rawSrc = img.getAttribute("src");
      if (rawSrc && !rawSrc.startsWith("data:") && !rawSrc.startsWith("blob:")) {
        return rawSrc;
      }
      const srcset = img.srcset || img.getAttribute("srcset");
      if (srcset) {
        const candidates = srcset
          .split(",")
          .map((s) => s.trim().split(/\s+/)[0])
          .filter(Boolean);
        const valid = candidates.filter((u) => !u.startsWith("data:") && !u.startsWith("blob:"));
        if (valid.length > 0) return valid[valid.length - 1];
      }
    }

    const source = el.querySelector("picture source");
    if (source) {
      const srcset = source.srcset || source.getAttribute("srcset");
      if (srcset) {
        const candidates = srcset
          .split(",")
          .map((s) => s.trim().split(/\s+/)[0])
          .filter(Boolean);
        const valid = candidates.filter((u) => !u.startsWith("data:") && !u.startsWith("blob:"));
        if (valid.length > 0) return valid[valid.length - 1];
      }
    }

    return "";
  }

  // --- VARREDURA ROBUSTA DO DOM PARA INSTAGRAM & TIKTOK ---
  function scanCurrentPageDOM() {
    injectAllStyles();
    injectProfileDownloadAllButton();

    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");
    const defaultAuthor = getAuthorFromPage();
    let updatedOrNewCount = 0;

    // 1. INSTAGRAM
    if (isInstagram) {
      const anchors = document.querySelectorAll('a[href*="/reel/"], a[href*="/p/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/(?:p|reel)\/([A-Za-z0-9_-]+)/);
          if (!match) return;
          const code = match[1];
          const id = `ig_${code}`;

          const isReelUrl = href.includes("/reel/");
          const isReelsTab = window.location.pathname.includes("/reels");
          const isVideo = isReelsTab || isReelUrl || !!a.querySelector("video");

          if (!isVideo && !isReelUrl) return;

          const thumb = extractThumbnail(a);
          const img = a.querySelector("img");
          const alt = img ? img.alt || "" : "";

          let detectedViews = 0;
          const textBlocks = Array.from(a.querySelectorAll("span, div"))
            .map((el) => el.innerText.trim())
            .filter(Boolean);

          for (const t of textBlocks) {
            if (/^[0-9]+([.,][0-9]+)?\s*(k|m|mil|mi)?$/i.test(t)) {
              detectedViews = parseMetricString(t);
              break;
            }
          }

          if (tabVideosCache.has(id)) {
            const existing = tabVideosCache.get(id);
            let itemChanged = false;
            if (detectedViews > 0 && (!existing.metrics.views || existing.metrics.views === 0)) {
              existing.metrics.views = detectedViews;
              itemChanged = true;
            }
            if (thumb && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
              existing.thumbnailUrl = thumb;
              itemChanged = true;
            }
            if (itemChanged) updatedOrNewCount++;

            attachDownloadButtonToTile(a, existing);
            return;
          }

          const videoItem = {
            id,
            rawId: code,
            code,
            platform: "instagram",
            author: defaultAuthor,
            caption: alt || `Reel Instagram @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views: detectedViews,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null,
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          updatedOrNewCount++;

          attachDownloadButtonToTile(a, videoItem);
        } catch (e) {}
      });
    }

    // 2. TIKTOK
    if (isTikTok) {
      const anchors = document.querySelectorAll('a[href*="/video/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/video\/([0-9]+)/);
          if (!match) return;
          const videoId = match[1];
          const id = `tt_${videoId}`;

          const thumb = extractThumbnail(a);
          const img = a.querySelector("img");
          const alt = img ? img.alt || "" : "";

          let views = 0;
          const viewsEl = a.querySelector('[data-e2e="video-views"]') || a.querySelector("strong");
          if (viewsEl && viewsEl.innerText) {
            views = parseMetricString(viewsEl.innerText);
          }

          if (tabVideosCache.has(id)) {
            const existing = tabVideosCache.get(id);
            let itemChanged = false;
            if (views > 0 && (!existing.metrics.views || existing.metrics.views === 0)) {
              existing.metrics.views = views;
              itemChanged = true;
            }
            if (thumb && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
              existing.thumbnailUrl = thumb;
              itemChanged = true;
            }
            if (itemChanged) updatedOrNewCount++;

            attachDownloadButtonToTile(a, existing);
            return;
          }

          const videoItem = {
            id,
            rawId: videoId,
            platform: "tiktok",
            author: defaultAuthor,
            caption: alt || `Vídeo TikTok @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null,
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          updatedOrNewCount++;

          attachDownloadButtonToTile(a, videoItem);
        } catch (e) {}
      });
    }

    if (updatedOrNewCount > 0) {
      broadcastCapturedVideos();
    }

    return updatedOrNewCount;
  }

  function extractHashtags(text) {
    if (!text) return [];
    const matches = text.match(/#[a-zA-Z0-9_\u00C0-\u00FF]+/g);
    if (!matches) return [];
    return matches.map((m) => m.replace("#", "").toLowerCase());
  }

  function broadcastCapturedVideos() {
    chrome.runtime.sendMessage({
      action: "VIDEOS_CAPTURED",
      allVideos: Array.from(tabVideosCache.values()),
      totalInTab: tabVideosCache.size,
      url: window.location.href,
    }).catch(() => {});
  }

  // --- RECONCILIAÇÃO COM INJECTED.JS (Interceptação de APIs de Rede) ---
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.type !== "DGS_VIDEOS_DISCOVERED") {
      return;
    }

    const { videos } = event.data;
    if (!Array.isArray(videos)) return;

    let addedOrUpdated = 0;
    videos.forEach((v) => {
      if (!v || !v.id) return;
      if (tabVideosCache.has(v.id)) {
        const existing = tabVideosCache.get(v.id);
        if (v.metrics) {
          if (v.metrics.views) existing.metrics.views = v.metrics.views;
          if (v.metrics.likes) existing.metrics.likes = v.metrics.likes;
          if (v.metrics.comments) existing.metrics.comments = v.metrics.comments;
        }
        if (v.videoUrl) existing.videoUrl = v.videoUrl;
        if (v.thumbnailUrl && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
          existing.thumbnailUrl = v.thumbnailUrl;
        }
      } else {
        tabVideosCache.set(v.id, v);
      }
      addedOrUpdated++;
    });

    if (addedOrUpdated > 0) {
      broadcastCapturedVideos();
    }
  });

  // --- ESCUTA ATUALIZAÇÕES DE PROGRESSO DE DOWNLOADS DO BACKGROUND ---
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "DOWNLOAD_PROGRESS_UPDATE" && message.payload) {
      const p = message.payload;
      if (p.status === "resolving") {
        updateFloatingPanel(
          "Obtendo vídeo HD...",
          p.percentage,
          `Preparando vídeo ${p.current} de ${p.total} (@${p.currentAuthor})`,
          `${p.current}/${p.total}`
        );
      } else if (p.status === "downloading") {
        updateFloatingPanel(
          "Baixando Lote DGS...",
          p.percentage,
          `Baixando ${p.current} de ${p.total} (@${p.currentAuthor})`,
          `${p.current}/${p.total}`
        );
      } else if (p.status === "completed") {
        activeBatchDownloading = false;
        document.querySelectorAll(".dgs-download-all-btn").forEach((b) => b.classList.remove("is-busy"));
        updateFloatingPanel(
          "Download Concluído!",
          100,
          `Lote finalizado com sucesso! ${p.successCount} vídeos salvos na pasta Downloads.`,
          `${p.successCount}/${p.total}`
        );
        setTimeout(() => {
          if (floatingPanel) floatingPanel.classList.add("hidden");
        }, 5500);
      } else if (p.status === "cancelled") {
        activeBatchDownloading = false;
        document.querySelectorAll(".dgs-download-all-btn").forEach((b) => b.classList.remove("is-busy"));
        updateFloatingPanel("Cancelado", 0, "Download cancelado.");
        setTimeout(() => {
          if (floatingPanel) floatingPanel.classList.add("hidden");
        }, 2000);
      }
    }
  });

  // --- INICIALIZAÇÃO SEGURA DO SCRIPT ---
  function init() {
    injectAllStyles();
    scanCurrentPageDOM();

    let scanTimer = null;
    const observer = new MutationObserver(() => {
      if (scanTimer) return;
      scanTimer = setTimeout(() => {
        scanTimer = null;
        scanCurrentPageDOM();
      }, 500);
    });

    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }

    window.addEventListener(
      "scroll",
      () => {
        if (scanTimer) return;
        scanTimer = setTimeout(() => {
          scanTimer = null;
          scanCurrentPageDOM();
        }, 400);
      },
      { passive: true }
    );
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  console.log(`${SCRIPT_NAME} Inicializado com sucesso: Download All no perfil e na grade.`);
})();
