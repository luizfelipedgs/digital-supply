"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.6.0"
BUILD_DATE = "2026-11-27"
APP_NAME = "Central DGS"
DESCRIPTION = "Central DGS - Agendamento 100% autônomo na nuvem, disparo imediato e conexão oficial com Instagram e TikTok."
