"""
Motor de Renderização DGS - Resolução e Execução Segura de FFmpeg/FFprobe
Garante compatibilidade total em qualquer máquina Windows de alunos sem depender
de instalação prévia manual ou alteração de variáveis de ambiente globais.
"""
import os
import sys
import shutil
import subprocess
import threading
from typing import Optional, Tuple

_FFMPEG_RESOLVED_PATH: Optional[str] = None
_FFPROBE_RESOLVED_PATH: Optional[str] = None
_RESOLVE_LOCK = threading.Lock()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _search_system_or_local() -> Optional[str]:
    # 1. Variável de ambiente explícita
    env_p = os.environ.get("FFMPEG_PATH")
    if env_p and os.path.exists(env_p):
        return env_p

    # 2. Caminhos locais no diretório da Central
    candidate_dirs = [
        os.path.join(BASE_DIR, "bin"),
        os.path.join(BASE_DIR, "storage", "bin"),
        r"C:\Central_DGS\bin",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Central_DGS", "bin")
    ]
    for c_dir in candidate_dirs:
        p = os.path.join(c_dir, "ffmpeg.exe")
        if os.path.exists(p):
            return p

    # 3. Busca no pacote imageio_ffmpeg se já estiver importável
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and os.path.exists(exe):
            return exe
    except Exception:
        pass

    # 4. PATH do Windows / winget
    sys_p = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if sys_p and os.path.exists(sys_p):
        return sys_p

    # 5. Busca em pacotes WinGet do usuário (muito comum em Windows 10/11)
    localapp = os.environ.get("LOCALAPPDATA", "")
    if localapp:
        winget_root = os.path.join(localapp, "Microsoft", "WinGet", "Packages")
        if os.path.exists(winget_root):
            try:
                for root, dirs, files in os.walk(winget_root):
                    if "ffmpeg.exe" in files:
                        found = os.path.join(root, "ffmpeg.exe")
                        if os.path.exists(found):
                            return found
            except Exception:
                pass

    return None

def _auto_install_imageio() -> Optional[str]:
    """Tenta instalar imageio-ffmpeg via pip em segundo plano se ausente."""
    try:
        from backend.database import add_log
        add_log("Inicializando motor de renderização DGS...", "INFO")
    except Exception:
        pass

    try:
        # Usa sys.executable para instalar no ambiente atual (.venv ou Python)
        res = subprocess.run(
            [sys.executable, "-m", "pip", "install", "imageio-ffmpeg>=0.5.1", "--quiet"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=120
        )
        if res.returncode == 0:
            import importlib
            if "imageio_ffmpeg" in sys.modules:
                del sys.modules["imageio_ffmpeg"]
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
            if exe and os.path.exists(exe):
                return exe
    except Exception:
        pass
    return None

def get_ffmpeg_binary() -> str:
    """
    Retorna o caminho do executável funcional do FFmpeg.
    Se não estiver instalado no sistema, provisiona automaticamente.
    Garante que nunca ocorra [WinError 2].
    """
    global _FFMPEG_RESOLVED_PATH

    if _FFMPEG_RESOLVED_PATH and os.path.exists(_FFMPEG_RESOLVED_PATH):
        return _FFMPEG_RESOLVED_PATH

    with _RESOLVE_LOCK:
        if _FFMPEG_RESOLVED_PATH and os.path.exists(_FFMPEG_RESOLVED_PATH):
            return _FFMPEG_RESOLVED_PATH

        # 1. Busca local, sistema ou imageio pré-instalado
        found = _search_system_or_local()
        if found:
            _FFMPEG_RESOLVED_PATH = found
            return found

        # 2. Provisionamento automático via pip
        found = _auto_install_imageio()
        if found:
            _FFMPEG_RESOLVED_PATH = found
            return found

        # 3. Fallback final: tenta 'ffmpeg' bare name caso o sistema tenha no PATH dinâmico
        return "ffmpeg"

def get_ffprobe_binary() -> Optional[str]:
    """Retorna o executável ffprobe ou None se ausente (usar fallback via ffmpeg)."""
    global _FFPROBE_RESOLVED_PATH

    if _FFPROBE_RESOLVED_PATH and os.path.exists(_FFPROBE_RESOLVED_PATH):
        return _FFPROBE_RESOLVED_PATH

    sys_p = shutil.which("ffprobe") or shutil.which("ffprobe.exe")
    if sys_p and os.path.exists(sys_p):
        _FFPROBE_RESOLVED_PATH = sys_p
        return sys_p

    # Verifica na mesma pasta do ffmpeg encontrado
    ff = get_ffmpeg_binary()
    if ff and os.path.isabs(ff):
        probe_cand = os.path.join(os.path.dirname(ff), "ffprobe.exe")
        if os.path.exists(probe_cand):
            _FFPROBE_RESOLVED_PATH = probe_cand
            return probe_cand

    return None

def extract_video_metadata(video_path: str) -> Tuple[float, bool]:
    """
    Retorna (duration_seconds, has_audio) utilizando ffprobe ou ffmpeg de forma universal.
    """
    duration = 0.0
    has_audio = False

    ffprobe = get_ffprobe_binary()
    if ffprobe:
        try:
            dur_cmd = [ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", video_path]
            dur_out = subprocess.check_output(dur_cmd, stderr=subprocess.DEVNULL, timeout=10).decode().strip()
            if dur_out:
                duration = float(dur_out)

            aud_cmd = [ffprobe, "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "default=noprint_wrappers=1:nokey=1", video_path]
            aud_out = subprocess.check_output(aud_cmd, stderr=subprocess.DEVNULL, timeout=10).decode().strip()
            has_audio = bool(aud_out)
            return duration, has_audio
        except Exception:
            pass

    # Fallback robusto usando apenas ffmpeg -i
    ffmpeg = get_ffmpeg_binary()
    try:
        cmd = [ffmpeg, "-i", video_path]
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, timeout=10)
        output = res.stderr or ""
        import re
        dur_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)", output)
        if dur_match:
            h = float(dur_match.group(1))
            m = float(dur_match.group(2))
            s = float(dur_match.group(3))
            duration = h * 3600 + m * 60 + s

        if "Audio:" in output or "Stream #" in output and "Audio" in output:
            has_audio = True
    except Exception:
        pass

    return duration, has_audio

def generate_video_thumbnail(video_path: str, thumbnail_path: str) -> bool:
    """Gera thumbnail de alta qualidade do vídeo."""
    try:
        ffmpeg = get_ffmpeg_binary()
        cmd = [
            ffmpeg, "-ss", "00:00:00.500", "-i", video_path,
            "-vframes", "1", "-q:v", "3", thumbnail_path, "-y"
        ]
        res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
        return res.returncode == 0 and os.path.exists(thumbnail_path)
    except Exception:
        return False
