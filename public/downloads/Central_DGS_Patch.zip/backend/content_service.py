import json
import urllib.request
import urllib.parse
import os
import time
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from backend.database import get_setting, add_log
from backend.auth_service import refresh_session_tokens, get_current_session

SUPABASE_URL = os.environ.get("NEXT_PUBLIC_SUPABASE_URL", "https://oipbnfcahgmqiwpqhnvt.supabase.co").rstrip("/")
SUPABASE_ANON_KEY = os.environ.get(
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pcGJuZmNhaGdtcWl3cHFobnZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NjcxODMsImV4cCI6MjEwMzU0MzE4M30.bU2yDCbWICGcoxDucNOzjBi8H1iOUNPdCxeD-5BEWQs"
)

def _auth_headers(content_type: str = "application/json") -> Dict[str, str]:
    token = get_setting("auth_access_token", "") or SUPABASE_ANON_KEY
    headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {token}",
        "Prefer": "return=representation"
    }
    if content_type:
        headers["Content-Type"] = content_type
    return headers

def _supabase_request(url: str, method: str = "GET", data: Any = None, content_type: str = "application/json", retry_auth: bool = True) -> Any:
    """Executa requisição ao Supabase REST/Storage com auto-refresh de token em caso de 401."""
    headers = _auth_headers(content_type=content_type)
    req_body = None
    if data is not None:
        if isinstance(data, (dict, list)):
            req_body = json.dumps(data).encode("utf-8")
        elif isinstance(data, bytes):
            req_body = data
        elif isinstance(data, str):
            req_body = data.encode("utf-8")

    req = urllib.request.Request(url, data=req_body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15.0) as resp:
            raw = resp.read()
            if not raw:
                return {}
            try:
                return json.loads(raw.decode("utf-8"))
            except Exception:
                return raw.decode("utf-8")
    except urllib.error.HTTPError as e:
        if e.code == 401 and retry_auth:
            try:
                refresh_session_tokens()
                return _supabase_request(url, method=method, data=data, content_type=content_type, retry_auth=False)
            except Exception:
                pass
        err_msg = ""
        try:
            err_msg = e.read().decode("utf-8")
        except Exception:
            pass
        raise Exception(f"Erro Supabase HTTP {e.code}: {err_msg or str(e)}")

# ==========================================
# 1. BIBLIOTECA DE MÚSICAS (music_library + storage)
# ==========================================

def get_public_music_url(storage_path: str) -> str:
    if not storage_path:
        return ""
    if storage_path.startswith("http://") or storage_path.startswith("https://"):
        return storage_path
    return f"{SUPABASE_URL}/storage/v1/object/public/music-library/{storage_path}"

def admin_get_music_library() -> List[Dict[str, Any]]:
    """Busca todas as faixas cadastradas na biblioteca com URLs públicas."""
    url = f"{SUPABASE_URL}/rest/v1/music_library?select=*&order=order_index.asc,created_at.desc"
    items = _supabase_request(url, method="GET")
    if not isinstance(items, list):
        items = []
    for item in items:
        item["public_url"] = get_public_music_url(item.get("storage_path", ""))
    return items

def admin_upload_music_track(file_bytes: bytes, filename: str, title: str) -> Dict[str, Any]:
    """Admin: Faz upload do arquivo de áudio pro bucket music-library e grava na tabela music_library."""
    ext = filename.split(".")[-1].lower() if "." in filename else "mp3"
    storage_path = f"{int(time.time()*1000)}-{uuid.uuid4().hex[:6]}.{ext}"

    # 1. Upload para o bucket
    upload_url = f"{SUPABASE_URL}/storage/v1/object/music-library/{storage_path}"
    content_type = "audio/mpeg" if ext == "mp3" else ("audio/wav" if ext == "wav" else "application/octet-stream")
    _supabase_request(upload_url, method="POST", data=file_bytes, content_type=content_type)

    # 2. Obter próximo order_index
    current_tracks = admin_get_music_library()
    next_order = len(current_tracks)

    # 3. Gravar na tabela
    insert_url = f"{SUPABASE_URL}/rest/v1/music_library"
    payload = {
        "title": title.strip() or filename,
        "storage_path": storage_path,
        "order_index": next_order
    }
    inserted = _supabase_request(insert_url, method="POST", data=payload)
    item = inserted[0] if isinstance(inserted, list) and len(inserted) > 0 else inserted
    item["public_url"] = get_public_music_url(storage_path)

    add_log(f"Admin: Nova música adicionada à biblioteca: '{item.get('title')}'", "SUCCESS", "admin")
    return item

def admin_rename_music_track(track_id: str, new_title: str) -> Dict[str, Any]:
    """Admin: Atualiza o título de uma música na biblioteca."""
    url = f"{SUPABASE_URL}/rest/v1/music_library?id=eq.{track_id}"
    payload = {"title": new_title.strip()}
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log(f"Admin: Música {track_id} renomeada para '{new_title.strip()}'", "INFO", "admin")
    return {"success": True, "data": res}

def admin_delete_music_track(track_id: str) -> bool:
    """Admin: Remove a faixa do storage e apaga da tabela music_library."""
    # 1. Busca faixa para obter o storage_path
    url_get = f"{SUPABASE_URL}/rest/v1/music_library?id=eq.{track_id}"
    tracks = _supabase_request(url_get, method="GET")
    if isinstance(tracks, list) and len(tracks) > 0:
        storage_path = tracks[0].get("storage_path")
        if storage_path:
            try:
                del_url = f"{SUPABASE_URL}/storage/v1/object/music-library"
                del_payload = {"prefixes": [storage_path]}
                _supabase_request(del_url, method="DELETE", data=del_payload)
            except Exception as e_del:
                add_log(f"Admin: Aviso ao deletar arquivo do bucket ({str(e_del)})", "WARNING", "admin")

    # 2. Deleta registro da tabela
    del_row_url = f"{SUPABASE_URL}/rest/v1/music_library?id=eq.{track_id}"
    _supabase_request(del_row_url, method="DELETE")
    add_log(f"Admin: Música {track_id} removida da biblioteca", "SUCCESS", "admin")
    return True

# ==========================================
# 2. AULAS & MÉTODOS (treinamento_licoes)
# ==========================================

def get_lessons() -> List[Dict[str, Any]]:
    """Busca as aulas e lições de treinamento da comunidade."""
    url = f"{SUPABASE_URL}/rest/v1/treinamento_licoes?select=*&order=order_index.asc,created_at.asc"
    try:
        items = _supabase_request(url, method="GET")
        return items if isinstance(items, list) else []
    except Exception as e:
        add_log(f"Falha ao carregar aulas: {str(e)}", "WARNING")
        return []

def admin_get_lessons() -> List[Dict[str, Any]]:
    return get_lessons()

def admin_create_lesson(
    title: str,
    subtitle: Optional[str] = None,
    content_type: str = "video",
    video_url: Optional[str] = None,
    body_text: Optional[str] = None,
    is_bonus: bool = False
) -> Dict[str, Any]:
    """Admin: Cria uma nova aula no treinamento."""
    lessons = get_lessons()
    max_order = max([l.get("order_index", 0) for l in lessons], default=0)

    url = f"{SUPABASE_URL}/rest/v1/treinamento_licoes"
    payload = {
        "title": title.strip(),
        "subtitle": subtitle.strip() if subtitle else None,
        "content_type": content_type or "video",
        "video_url": video_url.strip() if video_url else None,
        "body_text": body_text if body_text else None,
        "is_bonus": bool(is_bonus),
        "order_index": max_order + 1
    }
    inserted = _supabase_request(url, method="POST", data=payload)
    item = inserted[0] if isinstance(inserted, list) and len(inserted) > 0 else inserted
    add_log(f"Admin: Nova aula criada: '{title}'", "SUCCESS", "admin")
    return item

def admin_update_lesson(
    lesson_id: str,
    title: str,
    subtitle: Optional[str] = None,
    content_type: str = "video",
    video_url: Optional[str] = None,
    body_text: Optional[str] = None,
    is_bonus: bool = False
) -> Dict[str, Any]:
    """Admin: Atualiza uma aula existente."""
    url = f"{SUPABASE_URL}/rest/v1/treinamento_licoes?id=eq.{lesson_id}"
    payload = {
        "title": title.strip(),
        "subtitle": subtitle.strip() if subtitle else None,
        "content_type": content_type or "video",
        "video_url": video_url.strip() if video_url else None,
        "body_text": body_text if body_text else None,
        "is_bonus": bool(is_bonus)
    }
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log(f"Admin: Aula {lesson_id} atualizada", "INFO", "admin")
    return {"success": True, "data": res}

def admin_delete_lesson(lesson_id: str) -> bool:
    """Admin: Apaga uma aula do treinamento."""
    url = f"{SUPABASE_URL}/rest/v1/treinamento_licoes?id=eq.{lesson_id}"
    _supabase_request(url, method="DELETE")
    add_log(f"Admin: Aula {lesson_id} removida", "SUCCESS", "admin")
    return True

def admin_reorder_lesson(lesson_id: str, direction: str) -> bool:
    """Admin: Troca ordem da aula com a vizinha (up / down)."""
    lessons = get_lessons()
    idx = next((i for i, l in enumerate(lessons) if l.get("id") == lesson_id), -1)
    if idx == -1:
        return False
    target_idx = idx - 1 if direction == "up" else idx + 1
    if target_idx < 0 or target_idx >= len(lessons):
        return False

    curr = lessons[idx]
    target = lessons[target_idx]

    curr_order = curr.get("order_index", 0)
    target_order = target.get("order_index", 0)

    # Inverte os order_index
    _supabase_request(f"{SUPABASE_URL}/rest/v1/treinamento_licoes?id=eq.{curr['id']}", method="PATCH", data={"order_index": target_order})
    _supabase_request(f"{SUPABASE_URL}/rest/v1/treinamento_licoes?id=eq.{target['id']}", method="PATCH", data={"order_index": curr_order})
    return True

# ==========================================
# 3. CAMPANHAS MUSICAIS (campaigns)
# ==========================================

def get_campaigns() -> List[Dict[str, Any]]:
    """Busca as campanhas ativas com premiações no Supabase."""
    url = f"{SUPABASE_URL}/rest/v1/campaigns?select=*&order=featured.desc,created_at.desc"
    try:
        items = _supabase_request(url, method="GET")
        if not isinstance(items, list):
            items = []
        for c in items:
            c_path = c.get("cover_path")
            if c_path:
                c["cover_url"] = f"{SUPABASE_URL}/storage/v1/object/public/content-covers/{c_path}"
            else:
                c["cover_url"] = None
        return items
    except Exception as e:
        add_log(f"Falha ao carregar campanhas: {str(e)}", "WARNING")
        return []

def admin_get_campaigns() -> List[Dict[str, Any]]:
    return get_campaigns()

def admin_create_campaign(
    title: str,
    description: Optional[str] = None,
    prize_label: Optional[str] = None,
    start_date: str = "",
    end_date: str = "",
    link_url: str = "",
    featured: bool = False
) -> Dict[str, Any]:
    """Admin: Cria uma nova campanha com premiação."""
    sess = get_current_session()
    user_id = sess.get("user", {}).get("id")

    if not start_date:
        start_date = datetime.now().strftime("%Y-%m-%d")
    if not end_date:
        end_date = datetime.now().strftime("%Y-%m-%d")

    url = f"{SUPABASE_URL}/rest/v1/campaigns"
    payload = {
        "title": title.strip(),
        "description": description.strip() if description else None,
        "prize_label": prize_label.strip() if prize_label else None,
        "start_date": start_date,
        "end_date": end_date,
        "link_url": link_url.strip(),
        "featured": bool(featured),
        "created_by": user_id
    }
    inserted = _supabase_request(url, method="POST", data=payload)
    item = inserted[0] if isinstance(inserted, list) and len(inserted) > 0 else inserted
    add_log(f"Admin: Nova campanha criada: '{title}' ({prize_label})", "SUCCESS", "admin")
    return item

def admin_update_campaign(
    campaign_id: str,
    title: str,
    description: Optional[str] = None,
    prize_label: Optional[str] = None,
    start_date: str = "",
    end_date: str = "",
    link_url: str = "",
    featured: bool = False
) -> Dict[str, Any]:
    """Admin: Atualiza uma campanha existente."""
    url = f"{SUPABASE_URL}/rest/v1/campaigns?id=eq.{campaign_id}"
    payload = {
        "title": title.strip(),
        "description": description.strip() if description else None,
        "prize_label": prize_label.strip() if prize_label else None,
        "start_date": start_date,
        "end_date": end_date,
        "link_url": link_url.strip(),
        "featured": bool(featured)
    }
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log(f"Admin: Campanha {campaign_id} atualizada", "INFO", "admin")
    return {"success": True, "data": res}

def admin_delete_campaign(campaign_id: str) -> bool:
    """Admin: Apaga uma campanha."""
    url = f"{SUPABASE_URL}/rest/v1/campaigns?id=eq.{campaign_id}"
    _supabase_request(url, method="DELETE")
    add_log(f"Admin: Campanha {campaign_id} removida", "SUCCESS", "admin")
    return True

# ==========================================
# 4. AVISOS & COMUNICADOS (announcements)
# ==========================================

def admin_get_announcements() -> List[Dict[str, Any]]:
    """Busca todos os comunicados e avisos publicados."""
    url = f"{SUPABASE_URL}/rest/v1/announcements?select=*&order=created_at.desc"
    try:
        items = _supabase_request(url, method="GET")
        return items if isinstance(items, list) else []
    except Exception as e:
        add_log(f"Falha ao carregar avisos: {str(e)}", "WARNING")
        return []

def admin_create_announcement(title: str, body: Optional[str] = None) -> Dict[str, Any]:
    """Admin: Publica novo aviso para todos os alunos."""
    sess = get_current_session()
    user_id = sess.get("user", {}).get("id")

    url = f"{SUPABASE_URL}/rest/v1/announcements"
    payload = {
        "title": title.strip(),
        "body": body.strip() if body else None,
        "created_by": user_id
    }
    inserted = _supabase_request(url, method="POST", data=payload)
    item = inserted[0] if isinstance(inserted, list) and len(inserted) > 0 else inserted
    add_log(f"Admin: Novo comunicado publicado: '{title}'", "SUCCESS", "admin")
    return item

def admin_delete_announcement(announcement_id: str) -> bool:
    """Admin: Remove um aviso."""
    url = f"{SUPABASE_URL}/rest/v1/announcements?id=eq.{announcement_id}"
    _supabase_request(url, method="DELETE")
    add_log(f"Admin: Aviso {announcement_id} removido", "SUCCESS", "admin")
    return True

# ==========================================
# 5. GRUPO DGS PRO & REGRAS
# ==========================================

def get_grupo_info() -> Dict[str, Any]:
    """Busca as configurações e regras do Grupo Oficial DGS."""
    settings_url = f"{SUPABASE_URL}/rest/v1/grupo_settings?select=*&id=eq.main"
    regras_url = f"{SUPABASE_URL}/rest/v1/grupo_regras?select=*&order=order_index.asc"
    
    settings = {}
    try:
        res = _supabase_request(settings_url, method="GET")
        if isinstance(res, list) and len(res) > 0:
            settings = res[0]
    except Exception as e:
        add_log(f"Falha ao carregar grupo_settings: {e}", "WARNING")

    regras = []
    try:
        r_res = _supabase_request(regras_url, method="GET")
        if isinstance(r_res, list):
            regras = r_res
    except Exception as e:
        add_log(f"Falha ao carregar grupo_regras: {e}", "WARNING")

    return {
        "settings": settings or {
            "group_link": "https://chat.whatsapp.com/I4h3zQRr1869hsC0rRzTQ7",
            "title": "Grupo exclusivo DGS PRO",
            "description": "Entre para acompanhar as orientações da comunidade, tirar dúvidas e ficar por dentro das oportunidades e estratégias."
        },
        "regras": regras
    }

def admin_update_grupo_settings(group_link: str, title: str, description: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/grupo_settings?id=eq.main"
    payload = {
        "group_link": group_link.strip() if group_link else None,
        "title": title.strip() if title else "Grupo exclusivo DGS PRO",
        "description": description.strip() if description else None,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log("Admin: Configurações do Grupo DGS atualizadas", "SUCCESS", "admin")
    return {"success": True, "data": res}

def admin_create_grupo_regra(text: str) -> Dict[str, Any]:
    curr = get_grupo_info().get("regras", [])
    max_idx = max([r.get("order_index", 0) for r in curr], default=-1) + 1

    url = f"{SUPABASE_URL}/rest/v1/grupo_regras"
    payload = {
        "text": text.strip(),
        "order_index": max_idx
    }
    res = _supabase_request(url, method="POST", data=payload)
    add_log(f"Admin: Nova regra do grupo adicionada: '{text[:30]}...'", "SUCCESS", "admin")
    return {"success": True, "data": res}

def admin_update_grupo_regra(regra_id: str, text: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/grupo_regras?id=eq.{regra_id}"
    payload = {"text": text.strip()}
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log(f"Admin: Regra {regra_id} atualizada", "SUCCESS", "admin")
    return {"success": True, "data": res}

def admin_delete_grupo_regra(regra_id: str) -> bool:
    url = f"{SUPABASE_URL}/rest/v1/grupo_regras?id=eq.{regra_id}"
    _supabase_request(url, method="DELETE")
    add_log(f"Admin: Regra {regra_id} removida", "SUCCESS", "admin")
    return True

# ==========================================
# 6. INDIQUE E GANHE (affiliate_settings)
# ==========================================

def get_affiliate_info() -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/affiliate_settings?select=*&id=eq.main"
    try:
        res = _supabase_request(url, method="GET")
        if isinstance(res, list) and len(res) > 0:
            return res[0]
    except Exception as e:
        add_log(f"Falha ao carregar affiliate_settings: {e}", "WARNING")

    return {
        "affiliate_link": "https://app.cakto.com.br/affiliate/invite/07b3ed32-bf4d-4f8d-b575-8cd0042bce7f",
        "title": "Programa de Afiliados DGS",
        "commission_headline": "25% até 40%",
        "commission_note": "Comissão inicial de 25%, podendo chegar até 40% de acordo com o seu desenvolvimento dentro da comunidade.",
        "intro_text": "Indique novos membros e receba comissão por recorrência a cada assinatura realizada pelo seu link."
    }

def admin_update_affiliate_settings(affiliate_link: str, title: str, commission_headline: str, commission_note: str, intro_text: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/affiliate_settings?id=eq.main"
    payload = {
        "affiliate_link": affiliate_link.strip() if affiliate_link else None,
        "title": title.strip() if title else "Programa de Afiliados DGS",
        "commission_headline": commission_headline.strip() if commission_headline else "25% até 40%",
        "commission_note": commission_note.strip() if commission_note else None,
        "intro_text": intro_text.strip() if intro_text else None,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log("Admin: Configurações de Afiliação atualizadas", "SUCCESS", "admin")
    return {"success": True, "data": res}

# ==========================================
# 7. VÍDEO TUTORIAL /BEMVINDO (desktop_app_settings)
# ==========================================

def get_desktop_tutorial_settings() -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/desktop_app_settings?select=*&id=eq.main"
    try:
        res = _supabase_request(url, method="GET")
        if isinstance(res, list) and len(res) > 0:
            return res[0]
    except Exception as e:
        add_log(f"Falha ao carregar desktop_app_settings: {e}", "WARNING")

    return {
        "id": "main",
        "tutorial_video_url": "https://youtu.be/m3JFaMjhTis"
    }

def admin_update_desktop_tutorial_settings(tutorial_video_url: str) -> Dict[str, Any]:
    url = f"{SUPABASE_URL}/rest/v1/desktop_app_settings?id=eq.main"
    payload = {
        "tutorial_video_url": tutorial_video_url.strip() if tutorial_video_url else None,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    res = _supabase_request(url, method="PATCH", data=payload)
    add_log("Admin: Link do vídeo tutorial /bemvindo atualizado", "SUCCESS", "admin")
    return {"success": True, "data": res}
