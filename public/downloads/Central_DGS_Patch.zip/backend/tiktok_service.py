"""
Serviço Oficial TikTok Content Posting API v2 para a Central DGS.
Gerencia autenticação oficial (OAuth 2.0 PKCE / Authorization Code),
obtenção de perfil de usuário e publicação direta de vídeos no TikTok.
"""

import os
import json
import time
import hashlib
import secrets
try:
    import httpx
except ImportError:
    try:
        import subprocess, sys
        subprocess.run([sys.executable, "-m", "pip", "install", "httpx", "--quiet"], check=False)
        import httpx
    except Exception:
        import requests as httpx
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

# Constantes Oficiais da API v2 do TikTok
TIKTOK_API_BASE = "https://open.tiktokapis.com"
TIKTOK_AUTH_BASE = "https://www.tiktok.com/v2/auth/authorize/"

# Credenciais do Aplicativo Central DGS
# Produção (Em análise para liberação pública para todos os alunos/usuários):
# Client Key: awz4ftsph91dd2ev / Client Secret: m2jb3eOReYOUD2D4CqdNsXZWk8PjdMtR
# Sandbox (Testes restritos):
# Client Key: sbawjwr9fmnoab719c / Client Secret: u7b8BIOcdTFc23D5um5Mj0vLTFZfk591
TIKTOK_CLIENT_KEY = os.getenv("TIKTOK_CLIENT_KEY", "awz4ftsph91dd2ev")
TIKTOK_CLIENT_SECRET = os.getenv("TIKTOK_CLIENT_SECRET", "m2jb3eOReYOUD2D4CqdNsXZWk8PjdMtR")

# Escopos oficiais necessários para login, perfil e publicação
TIKTOK_SCOPES = [
    "user.info.basic",
    "user.info.stats",
    "video.upload",
    "video.publish"
]

def generate_pkce_pair() -> tuple[str, str]:
    """
    Gera o par code_verifier e code_challenge (SHA-256) exigido pelo TikTok v2 OAuth 2.0 PKCE.
    """
    code_verifier = secrets.token_urlsafe(64)
    # TikTok exige code_challenge = hashlib.sha256(code_verifier.encode('utf-8')).hexdigest()
    code_challenge = hashlib.sha256(code_verifier.encode("utf-8")).hexdigest()
    return code_verifier, code_challenge

def get_tiktok_oauth_url(redirect_uri: str, state: str = "central_dgs_tiktok", code_challenge: Optional[str] = None) -> str:
    """
    Gera a URL oficial de autorização do TikTok para o usuário autorizar em 1 clique.
    Inclui code_challenge e code_challenge_method=S256 exigidos pelo TikTok.
    """
    import urllib.parse
    scopes_str = ",".join(TIKTOK_SCOPES)
    params = {
        "client_key": TIKTOK_CLIENT_KEY,
        "scope": scopes_str,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "state": state
    }
    if code_challenge:
        params["code_challenge"] = code_challenge
        params["code_challenge_method"] = "S256"
        
    query_string = urllib.parse.urlencode(params)
    return f"{TIKTOK_AUTH_BASE}?{query_string}"

def exchange_code_for_token(code: str, redirect_uri: str, code_verifier: Optional[str] = None) -> Dict[str, Any]:
    """
    Troca o authorization code pelo access token e refresh token oficiais do TikTok.
    Envia code_verifier se PKCE foi utilizado.
    """
    url = f"{TIKTOK_API_BASE}/v2/oauth/token/"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Cache-Control": "no-cache"
    }
    payload = {
        "client_key": TIKTOK_CLIENT_KEY,
        "client_secret": TIKTOK_CLIENT_SECRET,
        "code": code.strip(),
        "grant_type": "authorization_code",
        "redirect_uri": redirect_uri
    }
    if code_verifier:
        payload["code_verifier"] = code_verifier

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, data=payload, headers=headers)
            data = resp.json()

            if "error" in data or data.get("error_code", 0) != 0:
                err_desc = data.get("error_description") or data.get("message") or str(data.get("error", "Erro ao trocar token"))
                return {"success": False, "error": f"Erro TikTok OAuth: {err_desc}"}

            access_token = data.get("access_token")
            refresh_token = data.get("refresh_token")
            expires_in = data.get("expires_in", 86400)
            open_id = data.get("open_id")

            if not access_token:
                return {"success": False, "error": "Token de acesso não retornado pelo TikTok."}

            # Busca informações do perfil com o token recém-obtido
            profile_res = get_user_profile(access_token)
            if not profile_res.get("success"):
                return profile_res

            account_info = profile_res["account"]
            account_info["access_token"] = access_token
            account_info["refresh_token"] = refresh_token
            account_info["open_id"] = open_id
            account_info["expires_in"] = expires_in

            return {
                "success": True,
                "account": account_info
            }
    except Exception as e:
        return {"success": False, "error": f"Falha de conexão com a API do TikTok: {str(e)}"}

def refresh_access_token(refresh_token: str) -> Dict[str, Any]:
    """
    Renova um access token expirado usando o refresh token.
    """
    url = f"{TIKTOK_API_BASE}/v2/oauth/token/"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    payload = {
        "client_key": TIKTOK_CLIENT_KEY,
        "client_secret": TIKTOK_CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": refresh_token.strip()
    }
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, data=payload, headers=headers)
            data = resp.json()
            if "error" in data or data.get("error_code", 0) != 0:
                return {"success": False, "error": data.get("error_description", "Falha ao renovar token")}
            return {
                "success": True,
                "access_token": data.get("access_token"),
                "refresh_token": data.get("refresh_token"),
                "expires_in": data.get("expires_in")
            }
    except Exception as e:
        return {"success": False, "error": str(e)}

def get_user_profile(access_token: str) -> Dict[str, Any]:
    """
    Obtém informações do usuário conectado (username, avatar, seguidores).
    """
    url = f"{TIKTOK_API_BASE}/v2/user/info/"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    params = {
        "fields": "open_id,union_id,avatar_url,avatar_url_100,display_name,bio_description,profile_deep_link,is_verified,follower_count,following_count,likes_count,video_count"
    }
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.get(url, headers=headers, params=params)
            data = resp.json()

            if data.get("error", {}).get("code") != "ok" and data.get("error_code", 0) != 0:
                err_msg = data.get("error", {}).get("message", "Erro ao obter dados do perfil do TikTok")
                return {"success": False, "error": err_msg}

            user = data.get("data", {}).get("user", {})
            d_name = user.get("display_name", "Usuário TikTok")
            avatar = user.get("avatar_url_100") or user.get("avatar_url", "")
            open_id = user.get("open_id", "")
            
            # Formata username
            uname = f"@{d_name.replace(' ', '_').lower()}" if not d_name.startswith("@") else d_name

            return {
                "success": True,
                "account": {
                    "open_id": open_id,
                    "username": uname,
                    "name": d_name,
                    "avatar": avatar,
                    "followers_count": user.get("follower_count", 0),
                    "following_count": user.get("following_count", 0),
                    "likes_count": user.get("likes_count", 0),
                    "video_count": user.get("video_count", 0),
                    "is_verified": user.get("is_verified", False)
                }
            }
    except Exception as e:
        return {"success": False, "error": f"Erro ao consultar perfil: {str(e)}"}

def publish_video_to_tiktok(
    access_token: str,
    video_path: str,
    caption: str = "",
    privacy_level: str = "PUBLIC_TO_EVERYONE",
    disable_duet: bool = False,
    disable_comment: bool = False,
    disable_stitch: bool = False,
    brand_organic_toggle: bool = False,
    brand_content_toggle: bool = False
) -> Dict[str, Any]:
    """
    Publica diretamente um vídeo na conta do TikTok via TikTok Content Posting API v2.
    Fluxo oficial em 2 etapas:
    1. /v2/post/publish/video/init/ -> Obtém a URL de upload binário e o publish_id
    2. Upload binário direto via PUT do arquivo de vídeo .mp4
    """
    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo de vídeo não encontrado no caminho: {video_path}"}

    file_size = os.path.getsize(video_path)
    if file_size == 0:
        return {"success": False, "error": "Arquivo de vídeo está vazio (0 bytes)."}

    # Etapa 1: Inicializa o post
    init_url = f"{TIKTOK_API_BASE}/v2/post/publish/video/init/"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json; charset=UTF-8"
    }

    # Opções de privacidade válidas: PUBLIC_TO_EVERYONE, MUTUAL_FOLLOW_FRIENDS, SELF_ONLY, FOLLOWER_OF_CREATOR
    post_info = {
        "title": caption[:2200],  # Limite de legenda do TikTok
        "privacy_level": privacy_level,
        "disable_duet": disable_duet,
        "disable_comment": disable_comment,
        "disable_stitch": disable_stitch,
        "video_cover_timestamp_ms": 1000
    }
    if brand_organic_toggle or brand_content_toggle:
        post_info["brand_organic_toggle"] = brand_organic_toggle
        post_info["brand_content_toggle"] = brand_content_toggle

    source_info = {
        "source": "FILE_UPLOAD",
        "video_size": file_size,
        "chunk_size": file_size,
        "total_chunk_count": 1
    }

    payload = {
        "post_info": post_info,
        "source_info": source_info
    }

    try:
        with httpx.Client(timeout=60.0) as client:
            init_resp = client.post(init_url, json=payload, headers=headers)
            init_data = init_resp.json()

            if init_data.get("error", {}).get("code") != "ok" and init_data.get("error_code", 0) != 0:
                err_msg = init_data.get("error", {}).get("message") or init_data.get("message", "Falha ao inicializar post no TikTok.")
                return {"success": False, "error": f"Erro TikTok Init: {err_msg}"}

            res_data = init_data.get("data", {})
            publish_id = res_data.get("publish_id")
            upload_url = res_data.get("upload_url")

            if not upload_url:
                return {"success": False, "error": "TikTok não retornou a URL de upload de vídeo."}

            # Etapa 2: Upload do arquivo de vídeo para o endpoint retornado
            with open(video_path, "rb") as video_file:
                video_bytes = video_file.read()

            upload_headers = {
                "Content-Range": f"bytes 0-{file_size - 1}/{file_size}",
                "Content-Type": "video/mp4",
                "Content-Length": str(file_size)
            }

            upload_resp = client.put(upload_url, content=video_bytes, headers=upload_headers, timeout=120.0)

            if upload_resp.status_code not in [200, 201, 206]:
                return {
                    "success": False,
                    "error": f"Falha no envio do vídeo para o TikTok (Status {upload_resp.status_code}): {upload_resp.text}"
                }

            return {
                "success": True,
                "publish_id": publish_id,
                "message": "Vídeo enviado com sucesso para os servidores do TikTok!"
            }

    except Exception as e:
        return {"success": False, "error": f"Exceção durante a postagem no TikTok: {str(e)}"}

def check_publish_status(access_token: str, publish_id: str) -> Dict[str, Any]:
    """
    Verifica o status de processamento da publicação no TikTok.
    Status possíveis: PROCESSING_DOWNLOAD, PROCESSING_UPLOAD, SUCCESS, FAILED
    """
    url = f"{TIKTOK_API_BASE}/v2/post/publish/status/fetch/"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json; charset=UTF-8"
    }
    payload = {"publish_id": publish_id}

    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, json=payload, headers=headers)
            data = resp.json()
            if data.get("error", {}).get("code") != "ok" and data.get("error_code", 0) != 0:
                return {"success": False, "error": data.get("error", {}).get("message", "Erro ao checar status")}

            status_data = data.get("data", {})
            return {
                "success": True,
                "status": status_data.get("status"),
                "fail_reason": status_data.get("fail_reason", ""),
                "publicaly_available_post_id": status_data.get("publicaly_available_post_id", [])
            }
    except Exception as e:
        return {"success": False, "error": str(e)}
