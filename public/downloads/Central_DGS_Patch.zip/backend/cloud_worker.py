"""
=============================================================================
DIGITAL SUPPLY — CLOUD DISPATCHER WORKER 24H (Nuvem Multi-Aluno)
=============================================================================
Este serviço executa de forma autônoma 24/7 na VPS Kamatera.
Ele consulta a fila global de agendamentos no Supabase para TODOS os alunos
da Comunidade Digital Supply e realiza a publicação oficial via Meta Graph API
e TikTok Content Posting API v2 na data e minuto exatos, permitindo que os
alunos fechem a Central e desliguem seus computadores.
=============================================================================
"""

import os
import sys
import time
import json
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime, timezone
import httpx

# Configurações do Supabase da Comunidade Digital Supply
SUPABASE_URL = "https://oipbnfcahgmqiwpqhnvt.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pcGJuZmNhaGdtcWl3cHFobnZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NjcxODMsImV4cCI6MjEwMzU0MzE4M30.bU2yDCbWICGcoxDucNOzjBi8H1iOUNPdCxeD-5BEWQs"

# Segredo de execução autônoma 24/7 do Cloud Worker
WORKER_SECRET = "dgs_cloud_worker_24h_secret_key_2026"

# Base local de cache temporário de vídeos na VPS
BASE_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache_videos")
os.makedirs(BASE_CACHE_DIR, exist_ok=True)

class DGSCloudWorker:
    def __init__(self):
        self.client = httpx.Client(timeout=60.0)

    def log(self, msg: str, level: str = "INFO"):
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{now_str}] [{level}] {msg}", flush=True)

    def get_pending_posts(self):
        """Busca posts agendados na fila global cuja data/hora já chegou via RPC segura."""
        url = f"{SUPABASE_URL}/rest/v1/rpc/get_pending_cloud_posts"
        headers = {
            "apikey": SUPABASE_ANON_KEY,
            "Content-Type": "application/json"
        }
        payload = {"p_secret": WORKER_SECRET}
        try:
            resp = self.client.post(url, json=payload, headers=headers)
            if resp.status_code == 200:
                posts = resp.json()
                return posts if isinstance(posts, list) else []
            else:
                self.log(f"Erro ao consultar fila no Supabase: {resp.status_code} - {resp.text}", "WARNING")
                return []
        except Exception as e:
            self.log(f"Erro de rede ao consultar fila: {str(e)}", "ERROR")
            return []

    def update_post_status(self, post_id: str, status: str, detail: str, published_url: str = None, media_id: str = None, error_msg: str = None):
        """Atualiza o status de um post na fila global no Supabase via RPC segura."""
        url = f"{SUPABASE_URL}/rest/v1/rpc/update_cloud_post_status"
        headers = {
            "apikey": SUPABASE_ANON_KEY,
            "Content-Type": "application/json"
        }
        payload = {
            "p_secret": WORKER_SECRET,
            "p_post_id": post_id,
            "p_status": status,
            "p_detail": detail,
            "p_published_url": published_url,
            "p_media_id": media_id,
            "p_error_message": error_msg
        }
        try:
            self.client.post(url, json=payload, headers=headers)
        except Exception as e:
            self.log(f"Erro ao atualizar status do post {post_id}: {e}", "ERROR")

    def download_video_to_cache(self, storage_path: str, local_filename: str) -> str:
        """Baixa o arquivo do vídeo do bucket Supabase Storage para cache local na VPS."""
        local_path = os.path.join(BASE_CACHE_DIR, local_filename)
        
        # Se for URL completa
        if storage_path.startswith("http://") or storage_path.startswith("https://"):
            url = storage_path
        else:
            url = f"{SUPABASE_URL}/storage/v1/object/public/cloud-videos/{storage_path}"

        headers = {"apikey": SUPABASE_ANON_KEY}
        with httpx.stream("GET", url, headers=headers, timeout=120.0) as r:
            if r.status_code != 200:
                raise Exception(f"Erro ao baixar vídeo do storage ({r.status_code}): {url}")
            with open(local_path, "wb") as f:
                for chunk in r.iter_bytes(chunk_size=65536):
                    f.write(chunk)

        return local_path

    def publish_instagram(self, post: dict, account: dict) -> dict:
        """Publica Reel via Meta Graph API oficial do Instagram."""
        token = account.get("meta_access_token")
        ig_user_id = account.get("meta_account_id")

        if not token or not ig_user_id:
            return {"success": False, "error": "Credenciais da Meta não encontradas na conta."}

        # Baixa vídeo
        storage_path = post.get("video_storage_path")
        local_name = f"{post['id']}_{post.get('video_filename', 'video.mp4')}"
        video_path = self.download_video_to_cache(storage_path, local_name)
        file_size = os.path.getsize(video_path)

        caption = post.get("caption") or ""
        hashtags = post.get("hashtags") or ""
        full_caption = f"{caption}\n\n{hashtags}".strip()

        # Passo 1: Criar container
        init_url = f"https://graph.facebook.com/v21.0/{ig_user_id}/media"
        init_payload = {
            "media_type": "REELS",
            "upload_type": "resumable",
            "caption": full_caption,
            "share_to_feed": True,
            "access_token": token
        }
        init_resp = self.client.post(init_url, data=init_payload)
        init_data = init_resp.json()
        if "error" in init_data:
            return {"success": False, "error": init_data["error"].get("message", "Erro ao iniciar container")}

        container_id = init_data.get("id")
        upload_uri = init_data.get("uri")

        # Passo 2: Upload binário
        with open(video_path, "rb") as f:
            v_bytes = f.read()

        up_headers = {
            "Authorization": f"OAuth {token}",
            "offset": "0",
            "file_size": str(file_size),
            "Content-Type": "application/octet-stream"
        }
        up_resp = self.client.post(upload_uri, headers=up_headers, content=v_bytes, timeout=180.0)
        if up_resp.status_code not in (200, 201):
            return {"success": False, "error": f"Erro upload binário Meta: HTTP {up_resp.status_code}"}

        # Passo 3: Polling até FINISHED
        for _ in range(35):
            time.sleep(3)
            chk_resp = self.client.get(f"https://graph.facebook.com/v21.0/{container_id}", params={"fields": "status_code", "access_token": token})
            code = chk_resp.json().get("status_code")
            if code == "FINISHED":
                break
            elif code in ("ERROR", "EXPIRED"):
                return {"success": False, "error": "Meta rejeitou o vídeo no processamento."}

        # Passo 4: Publicar
        pub_resp = self.client.post(f"https://graph.facebook.com/v21.0/{ig_user_id}/media_publish", data={"creation_id": container_id, "access_token": token})
        pub_data = pub_resp.json()
        if "error" in pub_data:
            return {"success": False, "error": pub_data["error"].get("message", "Erro ao publicar")}

        media_id = pub_data.get("id")
        permalink = f"https://www.instagram.com/reel/{media_id}/"
        try:
            link_resp = self.client.get(f"https://graph.facebook.com/v21.0/{media_id}", params={"fields": "permalink", "access_token": token})
            permalink = link_resp.json().get("permalink", permalink)
        except Exception:
            pass

        # Limpeza do arquivo em cache local da VPS para não acumular disco
        try:
            if os.path.exists(video_path):
                os.remove(video_path)
        except Exception:
            pass

        return {
            "success": True,
            "media_id": str(media_id),
            "url": permalink,
            "detail": "Publicado oficialmente via Nuvem DGS"
        }

    def publish_tiktok(self, post: dict, account: dict) -> dict:
        """Publica vídeo via TikTok Content Posting API v2 oficial."""
        token = account.get("tiktok_access_token")
        if not token:
            return {"success": False, "error": "Token oficial do TikTok não encontrado na conta."}

        storage_path = post.get("video_storage_path")
        local_name = f"{post['id']}_{post.get('video_filename', 'video.mp4')}"
        video_path = self.download_video_to_cache(storage_path, local_name)
        file_size = os.path.getsize(video_path)

        caption = f"{post.get('caption', '')} {post.get('hashtags', '')}".strip()

        # Passo 1: Init TikTok
        init_url = "https://open.tiktokapis.com/v2/post/publish/video/init/"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json; charset=UTF-8"
        }
        payload = {
            "post_info": {
                "title": caption[:2200],
                "privacy_level": "PUBLIC_TO_EVERYONE",
                "disable_duet": False,
                "disable_comment": False,
                "disable_stitch": False,
                "video_cover_timestamp_ms": 1000
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": file_size,
                "chunk_size": file_size,
                "total_chunk_count": 1
            }
        }
        resp = self.client.post(init_url, json=payload, headers=headers)
        data = resp.json()
        if data.get("error", {}).get("code") != "ok":
            return {"success": False, "error": data.get("error", {}).get("message", "Erro ao iniciar TikTok")}

        upload_url = data.get("data", {}).get("upload_url")
        publish_id = data.get("data", {}).get("publish_id")

        # Passo 2: Upload PUT
        with open(video_path, "rb") as f:
            v_bytes = f.read()

        put_headers = {
            "Content-Type": "video/mp4",
            "Content-Range": f"bytes 0-{file_size - 1}/{file_size}"
        }
        put_resp = self.client.put(upload_url, headers=put_headers, content=v_bytes, timeout=180.0)
        if put_resp.status_code not in (200, 201):
            return {"success": False, "error": f"Erro upload PUT TikTok: {put_resp.status_code}"}

        try:
            if os.path.exists(video_path):
                os.remove(video_path)
        except Exception:
            pass

        return {
            "success": True,
            "media_id": str(publish_id),
            "url": "https://www.tiktok.com",
            "detail": "Vídeo enviado para processamento no TikTok via Nuvem DGS"
        }

    def run_loop(self):
        """Loop principal contínuo do Cloud Worker na VPS."""
        self.log("=================================================================", "INFO")
        self.log("   DIGITAL SUPPLY — CLOUD DISPATCHER WORKER 24H INICIADO         ", "INFO")
        self.log("=================================================================", "INFO")
        self.log("Conectado à nuvem Supabase com RPC autenticado 24/7.", "SUCCESS")

        while True:
            try:
                pending_posts = self.get_pending_posts()
                if pending_posts:
                    self.log(f"Encontrado(s) {len(pending_posts)} post(s) para disparo neste minuto!", "INFO")

                    for post in pending_posts:
                        post_id = post["id"]
                        platform = post["platform"].lower()
                        account = post.get("cloud_social_accounts") or {}

                        self.log(f"Iniciando post #{post_id} ({platform}) para usuário {post.get('user_id')}...", "INFO")
                        self.update_post_status(post_id, "uploading", "Processando envio pela Nuvem DGS...")

                        if platform == "instagram":
                            res = self.publish_instagram(post, account)
                        elif platform == "tiktok":
                            res = self.publish_tiktok(post, account)
                        else:
                            res = {"success": False, "error": f"Plataforma '{platform}' não suportada"}

                        if res.get("success"):
                            self.update_post_status(
                                post_id=post_id,
                                status="published",
                                detail=res.get("detail", "Publicado com sucesso"),
                                published_url=res.get("url"),
                                media_id=res.get("media_id")
                            )
                            self.log(f"Post #{post_id} publicado com sucesso na Nuvem DGS! Link: {res.get('url')}", "SUCCESS")
                        else:
                            err_msg = res.get("error", "Falha no envio")
                            self.update_post_status(
                                post_id=post_id,
                                status="failed",
                                detail=f"Erro de envio: {err_msg}",
                                error_msg=err_msg
                            )
                            self.log(f"Falha ao enviar post #{post_id}: {err_msg}", "ERROR")

            except Exception as e:
                self.log(f"Exceção no ciclo do Cloud Worker: {str(e)}", "ERROR")

            # Aguarda 20 segundos antes da próxima checagem
            time.sleep(20)

if __name__ == "__main__":
    worker = DGSCloudWorker()
    worker.run_loop()
