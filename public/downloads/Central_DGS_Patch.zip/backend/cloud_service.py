"""
=============================================================================
DIGITAL SUPPLY — CLOUD SERVICE BRIDGE (Desktop App -> Supabase Cloud)
=============================================================================
Sincroniza contas sociais e envia publicações agendadas para a Nuvem DGS
(Supabase Storage + public.cloud_queue), permitindo que o Cloud Worker 24/7
na VPS Kamatera publique oficialmente sem que o aluno precise deixar o PC ligado.
=============================================================================
"""

import os
import uuid
import json
import mimetypes
from datetime import datetime, timezone
try:
    import httpx
except ImportError:
    try:
        import subprocess, sys
        subprocess.run([sys.executable, "-m", "pip", "install", "httpx", "--quiet"], check=False)
        import httpx
    except Exception:
        import requests as httpx

from backend.database import (
    get_setting,
    get_account_by_id,
    get_queue_item,
    get_video_by_id,
    update_queue_status,
    add_log,
    get_db
)

SUPABASE_URL = "https://oipbnfcahgmqiwpqhnvt.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pcGJuZmNhaGdtcWl3cHFobnZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NjcxODMsImV4cCI6MjEwMzU0MzE4M30.bU2yDCbWICGcoxDucNOzjBi8H1iOUNPdCxeD-5BEWQs"

def _get_auth(force_refresh: bool = False):
    from backend.auth_service import refresh_session_tokens
    user_id = get_setting("auth_user_id", "")
    if force_refresh:
        try:
            token = refresh_session_tokens()
        except Exception:
            token = get_setting("auth_access_token", "")
    else:
        token = get_setting("auth_access_token", "")
    return user_id, token

def sync_account_to_cloud(account_id: int) -> str:
    """
    Sincroniza ou atualiza as credenciais da conta do aluno em public.cloud_social_accounts.
    Retorna o UUID da conta na nuvem.
    """
    user_id, token = _get_auth()
    if not user_id or not token:
        return ""

    acc = get_account_by_id(account_id)
    if not acc:
        return ""

    platform = (acc.get("platform") or "instagram").lower()
    headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }

    # Verifica se já existe mapeamento salvo
    cloud_acc_id = acc.get("cloud_account_id")
    client = httpx.Client(timeout=15.0)

    payload = {
        "user_id": user_id,
        "platform": platform,
        "account_name": acc.get("name") or acc.get("username") or "Conta Social",
        "username": acc.get("username") or "",
        "avatar_url": acc.get("avatar") or "",
        "status": "connected"
    }

    if platform == "instagram":
        payload["meta_access_token"] = acc.get("meta_access_token") or ""
        payload["meta_account_id"] = str(acc.get("meta_account_id") or "")
        payload["meta_page_id"] = str(acc.get("meta_page_id") or "")
    elif platform == "tiktok":
        payload["tiktok_access_token"] = acc.get("tiktok_access_token") or ""

    try:
        # Se já tem UUID na nuvem, tenta atualizar
        if cloud_acc_id:
            patch_url = f"{SUPABASE_URL}/rest/v1/cloud_social_accounts?id=eq.{cloud_acc_id}"
            resp = client.patch(patch_url, json=payload, headers=headers)
            if resp.status_code in (200, 204):
                return str(cloud_acc_id)

        # Caso contrário, insere nova conta
        post_url = f"{SUPABASE_URL}/rest/v1/cloud_social_accounts"
        resp = client.post(post_url, json=payload, headers=headers)
        if resp.status_code == 401:
            user_id, token = _get_auth(force_refresh=True)
            headers["Authorization"] = f"Bearer {token}"
            resp = client.post(post_url, json=payload, headers=headers)

        if resp.status_code in (200, 201):
            created = resp.json()
            if created and len(created) > 0:
                new_cloud_id = created[0]["id"]
                # Salva localmente
                conn = get_db()
                conn.cursor().execute("UPDATE accounts SET cloud_account_id = ? WHERE id = ?", (new_cloud_id, account_id))
                conn.commit()
                conn.close()
                return str(new_cloud_id)
    except Exception as e:
        add_log(f"Falha ao sincronizar conta com Nuvem DGS: {str(e)}", "WARNING")

    return ""

def upload_video_to_cloud(video_path: str, user_id: str, token: str) -> str:
    """
    Faz upload do arquivo MP4 local para o Supabase Storage (cloud-videos/{user_id}/{filename}).
    Retorna o caminho relativo dentro do bucket.
    """
    if not os.path.isfile(video_path):
        raise FileNotFoundError(f"Arquivo de vídeo não encontrado: {video_path}")

    import re
    raw_name = os.path.basename(video_path)
    clean_base = re.sub(r'[^a-zA-Z0-9._-]', '_', raw_name)
    clean_name = f"{uuid.uuid4().hex[:8]}_{clean_base}"
    storage_path = f"{user_id}/{clean_name}"

    upload_url = f"{SUPABASE_URL}/storage/v1/object/cloud-videos/{storage_path}"
    headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {token}",
        "Content-Type": "video/mp4",
        "x-upsert": "true"
    }

    with open(video_path, "rb") as f:
        file_bytes = f.read()

    client = httpx.Client(timeout=120.0)
    resp = client.post(upload_url, headers=headers, content=file_bytes)
    if resp.status_code not in (200, 201):
        raise Exception(f"Erro no upload para Nuvem DGS ({resp.status_code}): {resp.text}")

    return storage_path

def sync_queue_item_to_cloud(queue_id: int) -> bool:
    """
    Pega um post agendado na fila local do SQLite, envia o vídeo para a Nuvem DGS
    e cria a entrada correspondente em public.cloud_queue para o Cloud Worker 24/7.
    """
    user_id, token = _get_auth()
    if not user_id or not token:
        add_log("Aluno não autenticado na Central DGS; post agendado apenas localmente.", "INFO")
        return False

    item = get_queue_item(queue_id)
    if not item:
        return False

    # Se já está sincronizado na nuvem, ignora
    if item.get("is_cloud_synced") and item.get("cloud_queue_id"):
        return True

    account_id = item["account_id"]
    cloud_acc_id = sync_account_to_cloud(account_id)
    if not cloud_acc_id:
        add_log(f"Aviso: Não foi possível sincronizar credenciais da conta #{account_id} na Nuvem.", "WARNING")
        return False

    video = get_video_by_id(item["video_id"])
    v_path = (video.get("filepath") or video.get("file_path")) if video else None
    if not v_path or not os.path.isfile(v_path):
        add_log(f"Vídeo do post #{queue_id} não encontrado no disco.", "ERROR")
        return False

    video_path = v_path
    filename = os.path.basename(video_path)

    try:
        add_log(f"Enviando vídeo do post #{queue_id} para a Nuvem DGS...", "INFO")
        storage_path = upload_video_to_cloud(video_path, user_id, token)

        # Formata data ISO com timezone UTC
        dt_local = datetime.fromisoformat(item["scheduled_time"])
        # Garante representação ISO completa
        iso_str = dt_local.astimezone(timezone.utc).isoformat()

        queue_payload = {
            "user_id": user_id,
            "account_id": cloud_acc_id,
            "platform": item.get("platform", "instagram"),
            "video_storage_path": storage_path,
            "video_filename": filename,
            "caption": item.get("custom_caption") or item.get("caption") or "",
            "hashtags": item.get("custom_hashtags") or item.get("hashtags") or "",
            "scheduled_time": iso_str,
            "status": "pending",
            "status_detail": "Aguardando disparo autônomo na Nuvem DGS (PC pode ser desligado)"
        }

        headers = {
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        client = httpx.Client(timeout=30.0)
        resp = client.post(f"{SUPABASE_URL}/rest/v1/cloud_queue", json=queue_payload, headers=headers)
        if resp.status_code in (200, 201):
            res_data = resp.json()
            cloud_qid = res_data[0]["id"] if res_data else str(uuid.uuid4())

            conn = get_db()
            conn.cursor().execute(
                "UPDATE queue SET cloud_queue_id = ?, is_cloud_synced = 1, status_detail = ? WHERE id = ?",
                (cloud_qid, "Agendado na Nuvem DGS (PC pode ser desligado)", queue_id)
            )
            conn.commit()
            conn.close()

            add_log(f"Post #{queue_id} sincronizado com sucesso na Nuvem DGS! (Cloud ID: {cloud_qid})", "SUCCESS")
            return True
        else:
            add_log(f"Erro ao registrar post na fila da nuvem: {resp.status_code} - {resp.text}", "WARNING")
            return False

    except Exception as e:
        add_log(f"Erro ao enviar post #{queue_id} para a Nuvem DGS: {str(e)}", "WARNING")
        return False
