import os
import asyncio
from typing import Dict, Any
from playwright.async_api import async_playwright
from backend.automation.browser_manager import BrowserManager
from backend.database import add_log

async def post_youtube_short(profile_dir: str, video_path: str, title: str, caption: str = "", hashtags: str = "", headless: bool = False) -> Dict[str, Any]:
    """
    Publica um vídeo / Shorts no YouTube Studio usando Playwright com perfil persistente.
    """
    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo de vídeo não encontrado: {video_path}"}

    final_title = title if title else "Vídeo DGS"
    if "#Shorts" not in final_title and "#shorts" not in final_title:
        final_title = f"{final_title} #Shorts"

    description = f"{caption}\n\n{hashtags}".strip()

    add_log(f"Iniciando postagem no YouTube: {final_title}", "INFO", "youtube")

    async with async_playwright() as p:
        args = BrowserManager.get_context_args(profile_dir, headless=headless)
        context = await p.chromium.launch_persistent_context(**args)
        
        # Injeta cookies exportados caso existam
        json_cookies_path = os.path.join(profile_dir, "cookies.json")
        if os.path.exists(json_cookies_path):
            try:
                import json
                with open(json_cookies_path, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
                await context.add_cookies(c_data)
            except Exception:
                pass

        page = context.pages[0] if context.pages else await context.new_page()

        if not headless:
            try:
                await page.bring_to_front()
            except Exception:
                pass

        try:
            await page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            """)

            await page.goto("https://studio.youtube.com/", wait_until="domcontentloaded", timeout=60000)
            await asyncio.sleep(4)

            # Verifica se precisa de login
            if "accounts.google.com" in page.url:
                add_log("YouTube: Canal não autenticado. Faça login primeiro na Central.", "ERROR", "youtube")
                await context.close()
                return {"success": False, "error": "Login necessário no YouTube Studio"}

            # Clica no botão CRIAR ou Upload
            create_btn = page.locator("#create-icon, ytcp-button#create-icon, button:has-text('Criar'), button:has-text('Create')").first
            if await create_btn.count() > 0:
                await create_btn.click()
                await asyncio.sleep(1)
                # Clica em "Enviar vídeos"
                upload_item = page.locator("tp-yt-paper-item:has-text('Enviar vídeos'), tp-yt-paper-item:has-text('Upload videos')").first
                if await upload_item.count() > 0:
                    await upload_item.click()

            await asyncio.sleep(2)
            file_input = page.locator("input[type='file']").first
            if await file_input.count() == 0:
                await context.close()
                return {"success": False, "error": "Botão de upload do YouTube Studio não encontrado."}

            await file_input.set_input_files(os.path.abspath(video_path))
            add_log("YouTube: Arquivo enviado. Configurando título e detalhes...", "INFO", "youtube")
            await asyncio.sleep(6)

            # Preenchimento do Título
            title_input = page.locator("#title-textarea #textbox").first
            if await title_input.count() > 0:
                await title_input.click()
                await page.keyboard.press("Control+A")
                await page.keyboard.press("Backspace")
                await page.keyboard.type(final_title[:100], delay=20)
                await asyncio.sleep(1)

            # Preenchimento da Descrição
            if description:
                desc_input = page.locator("#description-textarea #textbox").first
                if await desc_input.count() > 0:
                    await desc_input.click()
                    await page.keyboard.type(description, delay=15)
                    await asyncio.sleep(1)

            # Seleciona "Não é conteúdo para crianças"
            not_kids_radio = page.locator("tp-yt-paper-radio-button[name='VIDEO_MADE_FOR_KIDS_NOT_MFK']").first
            if await not_kids_radio.count() > 0:
                await not_kids_radio.click()
                await asyncio.sleep(1)

            # Pega o link do vídeo se já estiver visível
            video_url = ""
            link_elem = page.locator("a.ytcp-video-info").first
            if await link_elem.count() > 0:
                video_url = await link_elem.get_attribute("href") or ""

            # Avança as etapas clicando em "Próximo" até a aba de Visibilidade
            for _ in range(3):
                next_btn = page.locator("#next-button").first
                if await next_btn.count() > 0 and await next_btn.is_enabled():
                    await next_btn.click()
                    await asyncio.sleep(2)

            # Na aba Visibilidade: seleciona "Público" (Public)
            public_radio = page.locator("tp-yt-paper-radio-button[name='PUBLIC']").first
            if await public_radio.count() > 0:
                await public_radio.click()
                await asyncio.sleep(1)

            # Clica no botão "Publicar" ou "Salvar"
            done_btn = page.locator("#done-button").first
            if await done_btn.count() > 0:
                await done_btn.click()
                add_log("YouTube: Botão Publicar acionado. Finalizando...", "INFO", "youtube")
                await asyncio.sleep(5)
            else:
                await context.close()
                return {"success": False, "error": "Botão Concluir/Publicar não encontrado no YouTube"}

            add_log(f"YouTube: Short publicado com sucesso! {video_url}", "SUCCESS", "youtube")
            await context.close()
            return {"success": True, "detail": "Publicado no YouTube Shorts", "url": video_url}

        except Exception as e:
            add_log(f"Erro no envio do YouTube: {str(e)}", "ERROR", "youtube")
            await context.close()
            return {"success": False, "error": str(e)}
