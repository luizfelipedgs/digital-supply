import os
import asyncio
from typing import Dict, Any
from playwright.async_api import async_playwright
from backend.automation.browser_manager import BrowserManager
from backend.database import add_log

def format_caption_paragraphs(text: str) -> str:
    """
    Normaliza a descrição com salto de linha duplo (\n\n) entre parágrafos,
    idêntico ao padrão diagramado no Canva e utilizado no Instagram.
    """
    if not text:
        return ""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = [b.strip() for b in normalized.split("\n") if b.strip()]
    return "\n\n".join(blocks)

async def clear_tiktok_draft_prompts(page):
    """
    Descarta proativamente rascunhos anteriores e modais de confirmação do TikTok Studio
    na tela inicial de upload ANTES de carregar um novo arquivo.
    Garante que tanto o card de rascunho pendente quanto o diálogo de confirmação
    ('Descartar esta publicação?') sejam totalmente dispensados.
    NUNCA toca no botão 'Descartar' do rodapé do formulário principal de publicação.
    """
    for cycle in range(3):
        try:
            # 1. Clica no botão Descartar EXCLUSIVAMENTE do card de rascunho anterior
            draft_card_btn = page.locator("[data-e2e='local_draft_container'] button:has-text('Descartar'), .local-draft-card button:has-text('Descartar')").first
            if await draft_card_btn.count() > 0 and await draft_card_btn.is_visible():
                add_log("TikTok: Card de rascunho anterior detectado. Clicando em Descartar...", "INFO", "tiktok")
                await draft_card_btn.click(force=True)
                await asyncio.sleep(1.2)

            # 2. Clica no botão Descartar do modal/diálogo de confirmação ('Descartar esta publicação?')
            modal_discard = page.locator("""
                div[role='dialog'] button:has-text('Descartar'),
                div[role='alertdialog'] button:has-text('Descartar'),
                .TUXModal button:has-text('Descartar'),
                div[role='dialog'] button.TUXButton--danger,
                div[role='dialog'] [class*='TUXButton--primary']:has-text('Descartar')
            """).first
            if await modal_discard.count() > 0 and await modal_discard.is_visible():
                add_log("TikTok: Modal de confirmação de descarte de rascunho detectado. Confirmando Descartar...", "INFO", "tiktok")
                await modal_discard.click(force=True)
                await asyncio.sleep(1.2)

            # 3. Fallback nativo no DOM via JS para varrer qualquer botão restante dentro de modais de diálogo
            still_open = await page.evaluate("""() => {
                const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [role="alertdialog"], .TUXModal, [data-e2e="local_draft_container"]'));
                for (const d of dialogs) {
                    const btns = Array.from(d.querySelectorAll('button, [role="button"]'));
                    const discard = btns.find(b => {
                        const t = (b.innerText || '').trim().toLowerCase();
                        return t === 'descartar' || t === 'discard';
                    });
                    if (discard) {
                        discard.click();
                        return true;
                    }
                }
                return false;
            }""")
            if still_open:
                await asyncio.sleep(1.2)
            else:
                break
        except Exception:
            break

async def deactivate_tiktok_verification_switches(page):
    """
    Desativa proativamente as duas chaves de verificação do TikTok:
    1. 'Verificação de direitos autorais de música' (com confirmação obrigatória de 'Parar' / 'Stop' no modal).
    2. 'verificação de conteúdo simples' (que atrasa a postagem em ~10 minutos).
    Garante a publicação direta e imediata sem esperas desnecessárias.
    """
    try:
        # Remove joyrides / tooltips se existirem
        await page.evaluate("""() => {
            const el = document.getElementById('react-joyride-portal');
            if (el) el.remove();
            document.querySelectorAll('.react-joyride__overlay, .react-joyride__spotlight, [class*="joyride"]').forEach(e => e.remove());
        }""")

        # 1. Chave de Verificação de Direitos Autorais de Música
        copy_sw = page.locator(".copyright-check .Switch__root, .copyright-check .Switch__content, div:has-text('direitos autorais de música') .Switch__root, div:has-text('Music copyright check') .Switch__root").first
        if await copy_sw.count() > 0:
            is_checked = await page.evaluate("""() => {
                const el = document.querySelector('.copyright-check input.Switch__input') ||
                           Array.from(document.querySelectorAll('input[role="switch"], input.Switch__input')).find(i => {
                               const p = i.closest('div');
                               return p && p.innerText && (p.innerText.toLowerCase().includes('direitos autorais') || p.innerText.toLowerCase().includes('copyright'));
                           });
                return el ? el.checked : true;
            }""")
            if is_checked:
                await copy_sw.scroll_into_view_if_needed()
                await copy_sw.click(force=True)
                await asyncio.sleep(1)
                # Confirma 'Parar' no diálogo que o TikTok abre ao tentar desligar a verificação de direitos
                parar_btn = page.locator("div[role='dialog'] button:has-text('Parar'), div[role='dialog'] button:has-text('Stop'), [role='alertdialog'] button:has-text('Parar'), [role='alertdialog'] button:has-text('Stop')").first
                if await parar_btn.count() > 0 and await parar_btn.is_visible():
                    await parar_btn.click(force=True)
                    await asyncio.sleep(1.5)
                add_log("TikTok: Chave de verificação de direitos autorais de música desativada com confirmação ('Parar').", "INFO", "tiktok")

        # 2. Chave de Verificação de Conteúdo Simples (evita a trava de 10 minutos)
        content_sw = page.locator(".headline-switch:has-text('conteúdo simples') .Switch__root, div:has-text('conteúdo simples') .Switch__root, div:has-text('Content check lite') .Switch__root").first
        if await content_sw.count() > 0:
            is_checked2 = await page.evaluate("""() => {
                const el = Array.from(document.querySelectorAll('input.Switch__input, input[role="switch"]')).find(i => {
                    let p = i.closest('div');
                    return p && (p.innerText || '').toLowerCase().includes('conteúdo simples');
                });
                return el ? el.checked : true;
            }""")
            if is_checked2:
                await content_sw.scroll_into_view_if_needed()
                await content_sw.click(force=True)
                await asyncio.sleep(1)
                parar_btn2 = page.locator("div[role='dialog'] button:has-text('Parar'), div[role='dialog'] button:has-text('Stop'), [role='alertdialog'] button:has-text('Parar'), [role='alertdialog'] button:has-text('Stop')").first
                if await parar_btn2.count() > 0 and await parar_btn2.is_visible():
                    await parar_btn2.click(force=True)
                    await asyncio.sleep(1.5)
                add_log("TikTok: Chave de verificação de conteúdo simples desativada (evitando espera de 10 min).", "INFO", "tiktok")

    except Exception as e_sw:
        add_log(f"TikTok: Aviso ao ajustar chaves de verificação: {e_sw}", "WARNING", "tiktok")

async def post_tiktok_video(
    profile_dir: str, 
    video_path: str, 
    caption: str, 
    hashtags: str = "", 
    headless: bool = False,
    sound_name: str = "",
    account_name: str = ""
) -> Dict[str, Any]:
    """
    Publica um vídeo no TikTok Studio usando Playwright com perfil persistente autenticado.
    Executa o fluxo completo solicitado:
    1. Upload do arquivo de vídeo após limpar eventuais rascunhos anteriores.
    2. Preenchimento instantâneo da legenda e hashtags/@ com parágrafos separados.
    3. Seleção de capa inteligente anti-duplicidade na timeline.
    4. Adição de música da aba 'Favoritos' correspondente a sound_name.
    5. Ajuste do volume da música para -59 dB (mantendo o áudio original do vídeo).
    6. Desativação ativa das chaves de verificação (Direitos Autorais e Conteúdo Simples).
    7. Publicação oficial com resolução ativa de modais de confirmação.
    """
    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo de vídeo não encontrado: {video_path}"}

    clean_caption = format_caption_paragraphs(caption)
    clean_hashtags = hashtags.strip() if hashtags else ""
    if clean_hashtags:
        full_caption = f"{clean_caption}\n\n{clean_hashtags}" if clean_caption else clean_hashtags
    else:
        full_caption = clean_caption

    acc_label = f" ({account_name})" if account_name else ""
    mode_str = "background (oculto)" if headless else "visível na tela"
    add_log(f"Iniciando postagem no TikTok{acc_label} [{mode_str}]: {os.path.basename(video_path)}", "INFO", "tiktok")

    async with async_playwright() as p:
        args = BrowserManager.get_context_args(profile_dir, headless=headless)
        context = await p.chromium.launch_persistent_context(**args)
        
        # Injeta cookies exportados caso existam
        json_cookies_path = os.path.join(profile_dir, "cookies.json")
        if os.path.exists(json_cookies_path):
            try:
                import json
                with open(json_cookies_path, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
                await context.add_cookies(c_data)
            except Exception:
                pass

        page = context.pages[0] if context.pages else await context.new_page()

        if not headless:
            try:
                await page.bring_to_front()
            except Exception:
                pass

        try:
            await page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            """)
            if headless:
                await page.add_init_script("window.__mute_audio_force = true;")

            # 1. Acessa o TikTok Studio Upload
            await page.goto("https://www.tiktok.com/tiktokstudio/upload?from=webapp&tab=video", wait_until="domcontentloaded", timeout=60000)
            await asyncio.sleep(6)

            # Checa se foi redirecionado para página de login
            if "login" in page.url.lower():
                add_log("TikTok: Conta não autenticada. Verifique a conexão da sessão na Central.", "ERROR", "tiktok")
                await context.close()
                return {"success": False, "error": "Login necessário no TikTok"}

            # Limpa proativamente rascunhos anteriores e modais de descarte antes de carregar o arquivo
            await clear_tiktok_draft_prompts(page)
            await asyncio.sleep(2)

            # Localiza o input de arquivo com tolerância de carregamento
            file_input = page.locator("input[type='file']").first
            for _ in range(12):
                if await file_input.count() > 0:
                    break
                await asyncio.sleep(2)

            if await file_input.count() == 0:
                await page.goto("https://www.tiktok.com/upload", wait_until="domcontentloaded")
                await asyncio.sleep(4)
                for _ in range(8):
                    file_input = page.locator("input[type='file']").first
                    if await file_input.count() > 0:
                        break
                    await asyncio.sleep(2)

            if await file_input.count() == 0:
                await context.close()
                return {"success": False, "error": "Campo de upload do TikTok não localizado."}

            await file_input.set_input_files(os.path.abspath(video_path))
            add_log("TikTok: Arquivo de vídeo enviado ao formulário. Aguardando upload e processamento completo...", "INFO", "tiktok")

            # Aguarda o upload do vídeo ser 100% concluído e processado pelos servidores do TikTok
            upload_ready = False
            for poll_idx in range(60): # até 180 segundos com verificações a cada 3s
                await asyncio.sleep(3)
                try:
                    # Remove tooltips de onboarding / joyride se existirem
                    await page.evaluate("""() => {
                        const el = document.getElementById('react-joyride-portal');
                        if (el) el.remove();
                        document.querySelectorAll('.react-joyride__overlay, .react-joyride__spotlight, [class*="joyride"]').forEach(e => e.remove());
                    }""")
                except Exception:
                    pass

                upload_ready = await page.evaluate("""() => {
                    const text = (document.body.innerText || '').toLowerCase();
                    
                    // Se ainda estiver na fase de envio com porcentagem menor que 100%
                    const m = text.match(/(\d+)%/);
                    if (m && parseInt(m[1]) < 100) return false;

                    const hasReplace = text.includes('substituir') || text.includes('replace');
                    const hasUploaded = text.includes('upload concluído') || text.includes('carregamento concluído') || text.includes('uploaded');
                    
                    const videoEl = document.querySelector('video');
                    const videoReady = videoEl && videoEl.readyState >= 1 && (videoEl.duration > 0 || videoEl.videoWidth > 0);
                    
                    // Verifica se o botão de capa ou sons já está ativo
                    const capaBtn = document.querySelector("div.edit-container, [class*='edit-cover'], [class*='editCover']");
                    const capaActive = capaBtn && !capaBtn.getAttribute('disabled') && !capaBtn.classList.contains('disabled');

                    return (hasReplace || hasUploaded || (videoReady && capaActive));
                }""")

                if upload_ready:
                    add_log(f"TikTok: Upload e processamento do vídeo concluídos com sucesso (tempo: {(poll_idx + 1) * 3}s).", "INFO", "tiktok")
                    break

            if not upload_ready:
                add_log("TikTok: Vídeo demorou para responder, prosseguindo com tolerância para edição...", "WARNING", "tiktok")

            # Pausa humana estratégica para estabilizar todos os controles e miniaturas
            await asyncio.sleep(5)

            # 2. Descrição Completa com # e @ (Instantâneo via Clipboard + Control+V)
            caption_input = page.locator("div[contenteditable='true'], div.notranslate.public-DraftEditor-content").first
            if await caption_input.count() > 0 and await caption_input.is_visible():
                try:
                    await caption_input.click()
                    await asyncio.sleep(0.5)
                    await page.keyboard.press("Control+A")
                    await page.keyboard.press("Backspace")
                    await asyncio.sleep(0.5)
                    await page.evaluate("""async (text) => {
                        await navigator.clipboard.writeText(text);
                    }""", full_caption)
                    await page.keyboard.press("Control+V")
                    await asyncio.sleep(1.5)
                    await page.keyboard.press("Escape") # Fecha popups de autocompletar hashtags
                    add_log("TikTok: Descrição, hashtags e menções inseridas com sucesso.", "INFO", "tiktok")
                except Exception as e:
                    add_log(f"TikTok: Fallback de digitação da legenda: {e}", "WARNING", "tiktok")
                    await page.keyboard.type(full_caption, delay=10)

            await asyncio.sleep(3)

            # 3. Seleção Inteligente de Capa (Anti-duplicidade na timeline)
            try:
                # Remove joyride overlays se existirem
                await page.evaluate("""() => {
                    const el = document.getElementById('react-joyride-portal');
                    if (el) el.remove();
                    document.querySelectorAll('.react-joyride__overlay, .react-joyride__spotlight, [class*="joyride"]').forEach(e => e.remove());
                }""")

                capa_btn = page.locator("div.edit-container, [class*='edit-cover'], [class*='editCover'], div:has-text('Editar capa'), button:has-text('Editar capa'), div:has-text('Edit cover'), button:has-text('Edit cover')").last
                for _ in range(8):
                    if await capa_btn.count() > 0 and await capa_btn.is_visible():
                        break
                    await asyncio.sleep(1.5)

                if await capa_btn.count() > 0 and await capa_btn.is_visible():
                    await capa_btn.scroll_into_view_if_needed()
                    await asyncio.sleep(1.5)
                    await capa_btn.click(force=True)
                    add_log("TikTok: Abrindo seletor de capa do vídeo...", "INFO", "tiktok")
                    await asyncio.sleep(5)

                    # Aguarda a timeline de frames carregar
                    timeline = page.locator(".FramePicker__canvas, .CoverPicker__framePickerContainer, .FramePicker__root, div[class*='framePicker'], div[class*='FramePicker'], canvas").first
                    timeline_ready = False
                    for _ in range(12):
                        if await timeline.count() > 0 and await timeline.is_visible():
                            box = await timeline.bounding_box()
                            if box and box.get("width", 0) > 20:
                                timeline_ready = True
                                break
                        await asyncio.sleep(1)

                    if timeline_ready:
                        box = await timeline.bounding_box()
                        target_x = box["x"] + (box["width"] * 0.45)
                        target_y = box["y"] + (box["height"] / 2)
                        await page.mouse.click(target_x, target_y)
                        add_log("TikTok: Frame da timeline (45%) selecionado para a capa.", "INFO", "tiktok")
                        await asyncio.sleep(3)

                    # Localiza e clica no botão Salvar/Save dentro do modal de capa
                    modal_save = page.locator("[role='dialog'], .semi-modal, .Dialog__content, div[class*='modal']").locator("button.header-button, button[class*='primary'], button:has-text('Salvar'), button:has-text('Save'), button:has-text('Concluir'), button:has-text('Done')").filter(has_not_text="rascunho").filter(has_not_text="draft").last
                    if await modal_save.count() == 0:
                        modal_save = page.locator(".Dialog__content button:has-text('Salvar'), .Dialog__content button:has-text('Save'), [role='dialog'] button:has-text('Salvar'), [role='dialog'] button:has-text('Save')").first

                    if await modal_save.count() > 0 and await modal_save.is_visible():
                        await modal_save.click(force=True)
                        await asyncio.sleep(3)

                    # Confirmação de fechamento do modal de capa
                    for _ in range(8):
                        is_open = await page.evaluate("""() => {
                            const m = document.querySelector('.Dialog__content, [role="dialog"], .semi-modal');
                            return !!m;
                        }""")
                        if not is_open:
                            break
                        if await modal_save.count() > 0 and await modal_save.is_visible():
                            await modal_save.click(force=True)
                        await asyncio.sleep(1.5)

                    add_log("TikTok: Capa do vídeo alterada e salva com sucesso (anti-duplicidade na timeline).", "SUCCESS", "tiktok")
                    await asyncio.sleep(3)
                else:
                    add_log("TikTok: Botão 'Editar capa' não localizado na interface.", "WARNING", "tiktok")
            except Exception as e_cover:
                add_log(f"TikTok: Aviso na seleção de capa: {e_cover}", "WARNING", "tiktok")

            # 4. Adicionar Sons dos 'Favoritos' + Volume -59 dB + Salvar
            # Executa sempre que sound_name for fornecido ou para vincular som dos Favoritos
            clean_sound = sound_name.strip() if sound_name else ""
            if clean_sound or True: # Sempre tenta verificar sons dos favoritos para fortalecer o alcance algorítmico
                add_log(f"TikTok: Iniciando integração de som {'(' + clean_sound + ')' if clean_sound else '(Top Favoritos)'}...", "INFO", "tiktok")
                try:
                    await page.evaluate("""() => {
                        const el = document.getElementById('react-joyride-portal');
                        if (el) el.remove();
                        document.querySelectorAll('.react-joyride__overlay, .react-joyride__spotlight, [class*="joyride"]').forEach(e => e.remove());
                    }""")

                    async def dismiss_editor_popups():
                        try:
                            await page.evaluate("""() => {
                                const el = document.getElementById('react-joyride-portal');
                                if (el) el.remove();
                                document.querySelectorAll('.react-joyride__overlay, .react-joyride__spotlight').forEach(e => e.remove());
                            }""")
                            popups = await page.locator("button:has-text('Got it'), button:has-text('Entendi'), button:has-text('OK'), button:has-text('Ok'), .semi-modal-close").all()
                            for p in popups:
                                if await p.is_visible():
                                    await p.click(force=True)
                                    await asyncio.sleep(0.5)
                        except Exception:
                            pass

                    # Localiza o botão Sons
                    sounds_btn = page.locator("button[data-button-name='sounds'], button:has-text('Sons'), button:has-text('Sounds'), div:has-text('Adicionar som'), div:has-text('Add sound'), [class*='sound-btn'], [class*='audio-btn']").last
                    drawer_opened = False

                    for attempt in range(5):
                        if await sounds_btn.count() > 0:
                            await sounds_btn.scroll_into_view_if_needed()
                            await asyncio.sleep(1.5)
                            await sounds_btn.click(force=True)
                            await asyncio.sleep(4)

                        await dismiss_editor_popups()

                        # Verifica se o painel/drawer de música abriu
                        drawer_opened = await page.evaluate("""() => {
                            const root = document.querySelector('.MusicPanelContainer__root, [class*="MusicPanel"], [class*="music-panel"]');
                            const hasFav = document.body.innerText.includes('Favoritos') || document.body.innerText.includes('Favorites');
                            return !!root || hasFav;
                        }""")
                        if drawer_opened:
                            break
                        await asyncio.sleep(2)

                    if drawer_opened:
                        add_log("TikTok: Painel de músicas aberto com sucesso. Acessando Favoritos...", "INFO", "tiktok")
                        await asyncio.sleep(2)

                        # Clica na aba 'Favoritos' / 'Favorites'
                        fav_tab = page.locator("button[role='tab']:has-text('Favoritos'), [role='tab']:has-text('Favorites')").first
                        if await fav_tab.count() == 0:
                            fav_tab = page.locator("div:text-is('Favoritos'), span:text-is('Favoritos'), div:text-is('Favorites'), span:text-is('Favorites')").last
                        if await fav_tab.count() > 0:
                            await fav_tab.click(force=True)
                            await asyncio.sleep(3)

                        await dismiss_editor_popups()

                        # Aguarda pacientemente a lista de músicas dos Favoritos carregar do servidor do TikTok
                        add_log("TikTok: Aguardando carregamento da lista de músicas dos Favoritos...", "INFO", "tiktok")
                        fav_loaded = False
                        for _ in range(15): # até 15s aguardando itens
                            await asyncio.sleep(1)
                            fav_loaded = await page.evaluate("""() => {
                                const container = document.querySelector('.MusicPanelContainer__root, [class*="MusicPanel"], [class*="music-panel"]');
                                if (!container) return false;
                                const btns = container.querySelectorAll('button:not([role="tab"])');
                                return btns.length > 0;
                            }""")
                            if fav_loaded:
                                break

                        await asyncio.sleep(2)

                        # Adiciona a música desejada da lista de favoritos
                        sound_added = await page.evaluate("""(targetSound) => {
                            const container = document.querySelector('.MusicPanelContainer__root, [class*="MusicPanel"], [class*="music-panel"]');
                            if (!container) return false;
                            
                            // 1. Se foi passado nome específico de som, procura correspondência na lista
                            if (targetSound && targetSound.trim().length > 0) {
                                const cleanTarget = targetSound.trim().toLowerCase();
                                const songRows = Array.from(container.querySelectorAll('div, li')).filter(el => {
                                    const t = (el.innerText || '').toLowerCase();
                                    return t.includes(cleanTarget) && !el.querySelector('[role="tablist"]');
                                });
                                
                                for (const row of songRows) {
                                    const btn = row.querySelector('button.Button__root--type-primary, button[class*="primary"], button');
                                    if (btn && btn.getAttribute('role') !== 'tab') {
                                        btn.click();
                                        return true;
                                    }
                                }
                            }
                            
                            // 2. Fallback: clica no primeiro botão de adicionar da lista de Favoritos (que não seja aba)
                            const allAddBtns = Array.from(container.querySelectorAll('button.Button__root--type-primary, button[class*="primary"], button'))
                                .filter(b => b.getAttribute('role') !== 'tab' && !(b.innerText || '').includes('Favoritos') && !(b.innerText || '').includes('Para você'));
                            if (allAddBtns.length > 0) {
                                allAddBtns[0].click();
                                return true;
                            }
                            
                            return false;
                        }""", clean_sound)

                        # Se ainda não adicionou e havia nome específico, tenta o campo de busca
                        if not sound_added and clean_sound:
                            search_box = page.locator("input[placeholder*='Procurar sons'], input[placeholder*='sons' i], input[placeholder*='Search sounds' i], input[type='search']").first
                            if await search_box.count() > 0 and await search_box.is_visible():
                                await search_box.click()
                                await asyncio.sleep(1)
                                await page.keyboard.press("Control+A")
                                await page.keyboard.type(clean_sound, delay=30)
                                await page.keyboard.press("Enter")
                                add_log(f"TikTok: Pesquisando som '{clean_sound}' na barra de busca...", "INFO", "tiktok")
                                await asyncio.sleep(4)

                                sound_added = await page.evaluate("""() => {
                                    const container = document.querySelector('.MusicPanelContainer__root, [class*="MusicPanel"], [class*="music-panel"]');
                                    if (!container) return false;
                                    const allAddBtns = Array.from(container.querySelectorAll('button.Button__root--type-primary, button[class*="primary"], button'))
                                        .filter(b => b.getAttribute('role') !== 'tab');
                                    if (allAddBtns.length > 0) {
                                        allAddBtns[0].click();
                                        return true;
                                    }
                                    return false;
                                }""")

                        if sound_added:
                            add_log("TikTok: Som selecionado com sucesso! Aguardando renderização do controle de volume...", "SUCCESS", "tiktok")
                            await asyncio.sleep(3)
                            await dismiss_editor_popups()

                            # Ajusta o volume para -59 dB (via DOM events e digitação)
                            await page.evaluate("""() => {
                                const volWrap = document.querySelector('.PropSettingAudioVolume__wrap, [class*="AudioVolume"], [class*="volume"]');
                                if (volWrap) {
                                    const numInput = volWrap.querySelector('input.PropSettingInput__input, input[type="text"], input[type="number"]');
                                    if (numInput) {
                                        numInput.focus();
                                        numInput.value = '-59';
                                        numInput.dispatchEvent(new Event('input', { bubbles: true }));
                                        numInput.dispatchEvent(new Event('change', { bubbles: true }));
                                        numInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
                                        numInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', bubbles: true }));
                                    }
                                    const range = volWrap.querySelector('input[type="range"]');
                                    if (range) {
                                        range.value = '-59';
                                        range.dispatchEvent(new Event('input', { bubbles: true }));
                                        range.dispatchEvent(new Event('change', { bubbles: true }));
                                    }
                                }
                            }""")

                            vol_loc = page.locator(".PropSettingAudioVolume__wrap input.PropSettingInput__input, .PropSettingAudioVolume__wrap input[type='text'], input.PropSettingInput__input[maxlength='3']").first
                            if await vol_loc.count() > 0 and await vol_loc.is_visible():
                                try:
                                    await vol_loc.click()
                                    await page.keyboard.press("Control+A")
                                    await page.keyboard.type("-59")
                                    await page.keyboard.press("Enter")
                                except Exception:
                                    pass

                            add_log("TikTok: Volume do som ajustado para -59 dB (áudio original preservado).", "INFO", "tiktok")
                            await asyncio.sleep(2)

                            # Clica no botão Salvar/Save/Concluir do painel de som (evita tocar em 'Salvar rascunho' do form)
                            save_clicked = await page.evaluate("""() => {
                                const container = document.querySelector('.MusicPanelContainer__root, [class*="MusicPanel"], [class*="music-panel"]');
                                const searchScope = container ? [container, document.body] : [document.body];
                                
                                for (const scope of searchScope) {
                                    const btns = Array.from(scope.querySelectorAll('button')).filter(b => {
                                        const t = (b.innerText || '').trim().toLowerCase();
                                        const rect = b.getBoundingClientRect();
                                        const isSaveWord = t === 'salvar' || t === 'save' || t === 'concluir' || t === 'done' || t === 'confirmar';
                                        return isSaveWord && !t.includes('rascunho') && !t.includes('draft');
                                    });
                                    if (btns.length > 0) {
                                        btns[0].click();
                                        return true;
                                    }
                                }
                                return false;
                            }""")

                            if not save_clicked:
                                top_save = page.locator("button.Button__root--type-primary:has-text('Salvar'), button.Button__root--type-primary:has-text('Save'), button:has-text('Salvar'), button:has-text('Concluir')").filter(has_not_text="rascunho").filter(has_not_text="draft").last
                                if await top_save.count() > 0 and await top_save.is_visible():
                                    await top_save.click(force=True)
                                    save_clicked = True

                            await asyncio.sleep(4)
                            add_log("TikTok: Música vinculada e salva no vídeo com sucesso!", "SUCCESS", "tiktok")
                        else:
                            add_log("TikTok: Nenhuma música disponível nos Favoritos para adicionar.", "WARNING", "tiktok")
                            # Fecha o painel caso não tenha adicionado
                            close_btn = page.locator("[data-button-name='close'], .MusicPanel__close, button[aria-label*='close' i], button:has([data-icon='Close']), button:has([data-icon='Back']), .semi-modal-close").first
                            if await close_btn.count() > 0 and await close_btn.is_visible():
                                await close_btn.click(force=True)
                                await asyncio.sleep(2)
                    else:
                        add_log("TikTok: Painel de música não pôde ser aberto na página.", "WARNING", "tiktok")

                except Exception as e_sound:
                    add_log(f"TikTok: Aviso na configuração do som: {e_sound}. Prosseguindo...", "WARNING", "tiktok")
                    try:
                        close_fb = page.locator("[data-button-name='close'], button[aria-label*='close' i], .semi-modal-close, button:has([data-icon='Close'])").first
                        if await close_fb.count() > 0 and await close_fb.is_visible():
                            await close_fb.click(force=True)
                    except Exception:
                        pass

            # 5. Ativa Carregamento em Alta Qualidade (HD)
            try:
                hd_switch = page.locator("label:has-text('Carregamentos de alta qualidade'), label:has-text('High-quality uploads'), div:has-text('alta qualidade') input[type='checkbox'], div:has-text('High-quality') input[type='checkbox']").first
                if await hd_switch.count() > 0:
                    is_checked = await hd_switch.is_checked() if await hd_switch.evaluate("e => e.tagName === 'INPUT'") else False
                    if not is_checked:
                        await hd_switch.click(force=True)
            except Exception:
                pass

            # 5.5. Desativação das Chaves de Verificação (Liberação Imediata da Publicação)
            await deactivate_tiktok_verification_switches(page)
            await asyncio.sleep(3)

            # 6. Clica no botão "Publicar" / "Post" (Aguardando ficar habilitado e NUNCA tocar em 'Salvar rascunho')
            post_btn = None
            add_log("TikTok: Aguardando habilitação do botão Publicar...", "INFO", "tiktok")
            for _ in range(35): # até 70s aguardando o processamento do vídeo e habilitação do botão
                candidates = page.locator("""
                    button:has-text('Publicar'),
                    [role='button']:has-text('Publicar'),
                    button:has-text('Post'),
                    [role='button']:has-text('Post')
                """).filter(has_not_text="rascunho").filter(has_not_text="draft").filter(has_not_text="Schedule").filter(has_not_text="Programar")
                
                count = await candidates.count()
                if count > 0:
                    cand = candidates.last
                    if await cand.is_visible():
                        is_dis = await cand.is_disabled()
                        if not is_dis:
                            post_btn = cand
                            break
                await asyncio.sleep(2)

            if post_btn:
                await post_btn.scroll_into_view_if_needed()
                await asyncio.sleep(2)
                try:
                    await post_btn.click()
                except Exception:
                    await post_btn.click(force=True)
                add_log("TikTok: Botão Publicar acionado com sucesso. Aguardando confirmação da rede...", "INFO", "tiktok")
            else:
                await context.close()
                return {"success": False, "error": "Botão de publicar não encontrado ou desabilitado no TikTok"}

            # 7. Aguarda confirmação oficial da publicação e resolve a "última janela de publicar" (modais e diálogos)
            confirmado = False
            for cycle in range(40): # até 80 segundos com verificações ativas
                await asyncio.sleep(2)

                try:
                    page_text = (await page.content()).lower()
                    current_url = page.url.lower()
                except Exception:
                    page_text = ""
                    current_url = ""

                if (
                    "gerenciar suas publicações" in page_text or 
                    "manage your posts" in page_text or 
                    "publicado" in page_text or 
                    "your video has been uploaded" in page_text or
                    "your video is being uploaded" in page_text or
                    "sua publicação foi enviada" in page_text or
                    "seu vídeo foi publicado" in page_text or
                    "/content" in current_url or
                    "/manage" in current_url or
                    "tiktokstudio/content" in current_url or
                    "post_success" in current_url
                ):
                    confirmado = True
                    break

                # --- RESOLUÇÃO ATIVA DA "ÚLTIMA JANELA DE PUBLICAR" (Modais e Confirmações do TikTok) ---
                try:
                    # 1. Modais de 'Publicar mesmo assim' / 'Post anyway' (quando verificação de direitos ainda está ativa)
                    post_anyway = page.locator("""
                        button:has-text('Publicar mesmo assim'),
                        [role='button']:has-text('Publicar mesmo assim'),
                        button:has-text('Post anyway'),
                        [role='button']:has-text('Post anyway'),
                        button:has-text('Publicar mesmo assim ('),
                        button:has-text('Post anyway (')
                    """).first
                    if await post_anyway.count() > 0 and await post_anyway.is_visible():
                        add_log("TikTok: Modal de confirmação detectado ('Publicar mesmo assim'). Confirmando envio...", "INFO", "tiktok")
                        await post_anyway.click(force=True)
                        await asyncio.sleep(2)
                        continue

                    # 2. Modais de 'Publicar agora' / 'Post now'
                    post_now = page.locator("""
                        button:has-text('Publicar agora'),
                        [role='button']:has-text('Publicar agora'),
                        button:has-text('Post now'),
                        [role='button']:has-text('Post now')
                    """).first
                    if await post_now.count() > 0 and await post_now.is_visible():
                        add_log("TikTok: Modal de confirmação detectado ('Publicar agora'). Confirmando envio...", "INFO", "tiktok")
                        await post_now.click(force=True)
                        await asyncio.sleep(2)
                        continue

                    # 3. Botão primário de confirmação em diálogos/modais (role='dialog', role='alertdialog', .semi-modal, div[class*='modal'])
                    modal_confirm = page.locator("""
                        div[role='dialog'] button:has-text('Publicar'),
                        div[role='dialog'] [role='button']:has-text('Publicar'),
                        div[role='dialog'] button:has-text('Post'),
                        div[role='dialog'] [role='button']:has-text('Post'),
                        div[role='dialog'] button[class*='primary'],
                        div[role='dialog'] [class*='TUXButton--primary'],
                        div[role='alertdialog'] button:has-text('Publicar'),
                        div[role='alertdialog'] button:has-text('Post'),
                        div[role='alertdialog'] button:has-text('Confirmar'),
                        div[role='alertdialog'] button:has-text('Confirm'),
                        div[role='alertdialog'] button[class*='primary'],
                        div[class*='modal'] button:has-text('Publicar'),
                        div[class*='modal'] button:has-text('Post'),
                        div[class*='modal'] button:has-text('Confirmar'),
                        div[class*='modal'] button:has-text('Confirm'),
                        div[class*='modal'] button:has-text('Continuar'),
                        div[class*='modal'] button:has-text('Continue'),
                        .semi-modal-footer button.semi-button-primary,
                        .semi-modal-footer button:has-text('Publicar'),
                        .semi-modal-footer button:has-text('Post'),
                        div[class*='modal-footer'] button:has-text('Publicar'),
                        div[class*='modal-footer'] button:has-text('Post')
                    """).last
                    if await modal_confirm.count() > 0 and await modal_confirm.is_visible():
                        btn_txt = (await modal_confirm.inner_text()).strip()
                        if not any(neg in btn_txt.lower() for neg in ["cancel", "rascunho", "draft", "voltar"]):
                            add_log(f"TikTok: Acionando confirmação na janela de publicação ('{btn_txt}')...", "INFO", "tiktok")
                            await modal_confirm.click(force=True)
                            await asyncio.sleep(2)
                            continue

                    # 4. Popups de tutorial/novidade ou avisos que bloqueiam a tela (Got it / Entendi)
                    got_it = page.locator("button:has-text('Got it'), [role='button']:has-text('Got it'), button:has-text('Entendi'), [role='button']:has-text('Entendi'), button:has-text('OK'), .semi-modal-close, button[aria-label*='Close' i]").first
                    if await got_it.count() > 0 and await got_it.is_visible():
                        await got_it.click(force=True)
                        await asyncio.sleep(1)

                    # 5. Se o botão principal de postar ainda estiver visível e habilitado (caso o primeiro clique não tenha disparado)
                    if cycle in (3, 7, 12, 18):
                        main_post = page.locator("button:has-text('Publicar'), button:has-text('Post'), [role='button']:has-text('Publicar'), [role='button']:has-text('Post')").filter(has_not_text="rascunho").filter(has_not_text="draft").last
                        if await main_post.count() > 0 and await main_post.is_visible():
                            is_disabled = await main_post.is_disabled()
                            if not is_disabled:
                                await main_post.click(force=True)

                except Exception:
                    pass

            if confirmado:
                add_log(f"TikTok: Vídeo publicado com sucesso em {account_name or 'TikTok'}!", "SUCCESS", "tiktok")
                await context.close()
                clean_user = account_name.replace("@", "").strip() if account_name else ""
                pub_url = f"https://www.tiktok.com/@{clean_user}" if clean_user else "https://www.tiktok.com"
                return {"success": True, "detail": "Publicado e confirmado no TikTok", "url": pub_url}
            else:
                try:
                    screenshot_err_path = os.path.join(profile_dir, "tiktok_publish_timeout.png")
                    await page.screenshot(path=screenshot_err_path)
                except Exception:
                    pass
                err_msg = "A publicação não foi confirmada pelo TikTok após o envio (verifique se a conta requer verificação manual ou se o vídeo ainda está sendo codificado)."
                add_log(f"TikTok: {err_msg}", "ERROR", "tiktok")
                await context.close()
                return {"success": False, "error": err_msg}

        except Exception as e:
            add_log(f"Erro no envio do TikTok: {str(e)}", "ERROR", "tiktok")
            await context.close()
            return {"success": False, "error": str(e)}
