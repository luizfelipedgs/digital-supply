import os
import json
import random
import asyncio
from typing import Dict, Any, Tuple
from playwright.async_api import async_playwright, Page
from backend.automation.browser_manager import BrowserManager, HumanController, STEALTH_INIT_SCRIPT
from backend.database import add_log

def format_caption_paragraphs(text: str) -> str:
    """
    Garante que os parágrafos do texto fiquem perfeitamente espaçados
    com linha em branco dupla (\\n\\n), idêntico à formatação original do Canva.
    """
    if not text:
        return ""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = [b.strip() for b in normalized.split("\n") if b.strip()]
    return "\n\n".join(blocks)

# ========================================================
# MOTOR DE ENTROPIA COMPORTAMENTAL (VARIAÇÃO NÃO-REPETITIVA)
# ========================================================
WARMUP_ARCHETYPES = [
    ("feed_curator", "Arquétipo A: Curador do Feed (Feed Orgânico + Salvar Posts nos Favoritos)", "Curador do Feed"),
    ("social_engager", "Arquétipo B: Engajador Social (Feed Orgânico + Curtir + Expandir Legenda)", "Engajador Social"),
    ("explore_wanderer", "Arquétipo C: Explorador de Tendências (Aba Explorar + Dwell em Grade)", "Explorador de Tendências"),
    ("reels_viewer", "Arquétipo D: Espectador de Reels (Aba Reels + Player Vertical)", "Espectador de Reels")
]

COOLDOWN_ARCHETYPES = [
    ("profile_grid_refresh", "Pós-Ação A: Conferência de Grade do Perfil", "Conferência de Grade"),
    ("feed_relaxation", "Pós-Ação B: Descompressão no Feed Inicial", "Descompressão no Feed"),
    ("reels_afterparty", "Pós-Ação C: Consumo Rápido de Reels", "Consumo de Reels"),
    ("explore_scan", "Pós-Ação D: Olhada no Explorar Pós-Envio", "Olhada no Explorar")
]

def get_account_behavior_history(profile_dir: str) -> dict:
    history_file = os.path.join(profile_dir, "behavior_history.json")
    if os.path.exists(history_file):
        try:
            with open(history_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_warmup": None, "last_cooldown": None, "total_runs": 0}

def save_account_behavior_history(profile_dir: str, data: dict):
    history_file = os.path.join(profile_dir, "behavior_history.json")
    try:
        os.makedirs(profile_dir, exist_ok=True)
        with open(history_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass

def select_unique_archetypes(profile_dir: str):
    history = get_account_behavior_history(profile_dir)
    last_warmup = history.get("last_warmup")
    last_cooldown = history.get("last_cooldown")

    # Garante matematicamente que o novo arquétipo NUNCA seja igual ao anterior da mesma conta
    w_candidates = [w for w in WARMUP_ARCHETYPES if w[0] != last_warmup] or WARMUP_ARCHETYPES
    c_candidates = [c for c in COOLDOWN_ARCHETYPES if c[0] != last_cooldown] or COOLDOWN_ARCHETYPES

    selected_w = random.choice(w_candidates)
    selected_c = random.choice(c_candidates)
    return selected_w, selected_c, history

# --------------------------------------------------------
# Executores dos 4 Arquétipos de Pré-Aquecimento Inicial
# --------------------------------------------------------
async def execute_warmup_feed_curator(page: Page, target_sec: float) -> Tuple[int, str]:
    """Arquétipo A: Rola o feed por ~1 min e salva de 1 a 2 posts nos favoritos."""
    start_t = asyncio.get_event_loop().time()
    posts_viewed = 0
    saved_count = 0
    max_saves = random.choice([1, 2])

    while (asyncio.get_event_loop().time() - start_t) < target_sec:
        posts_viewed += 1
        dwell = random.uniform(5.5, 9.5)

        viewport_w = page.viewport_size["width"] if page.viewport_size else 1280
        target_x = random.uniform(viewport_w * 0.35, viewport_w * 0.65)
        target_y = random.uniform(250, 650)
        await HumanController.move_mouse(page, target_x, target_y)

        # Salva post visível nos favoritos
        if saved_count < max_saves and random.random() < 0.50:
            try:
                save_locators = page.locator("svg[aria-label*='Salvar' i], svg[aria-label*='Save' i]")
                count = await save_locators.count()
                target_save = None
                for idx in range(count):
                    loc = save_locators.nth(idx)
                    if await loc.is_visible():
                        box = await loc.bounding_box()
                        if box and 100 < box["y"] < 750:
                            target_save = (loc, box)
                            break
                if target_save:
                    s_loc, s_box = target_save
                    btn_x = s_box["x"] + s_box["width"] / 2
                    btn_y = s_box["y"] + s_box["height"] / 2
                    await HumanController.move_mouse(page, btn_x, btn_y)
                    await asyncio.sleep(random.uniform(0.3, 0.7))
                    await s_loc.click()
                    saved_count += 1
                    add_log(f"Instagram: Post #{posts_viewed} salvo nos favoritos ({saved_count}/{max_saves})!", "SUCCESS", "instagram")
                    await HumanController.sleep(1.2, 2.2)
            except Exception:
                pass

        remaining = target_sec - (asyncio.get_event_loop().time() - start_t)
        await asyncio.sleep(min(dwell, max(1.5, remaining)))

        if (asyncio.get_event_loop().time() - start_t) >= target_sec:
            break

        if random.random() < 0.20:
            await HumanController.smooth_scroll(page, distance=-random.randint(90, 160), steps=random.randint(5, 8))
            await asyncio.sleep(random.uniform(1.2, 2.0))

        scroll_dist = random.randint(450, 750)
        await HumanController.smooth_scroll(page, distance=scroll_dist, steps=random.randint(14, 22))
        elapsed_now = int(asyncio.get_event_loop().time() - start_t)
        add_log(f"Instagram: [Curador do Feed] {elapsed_now}s / ~60s - Post #{posts_viewed} visualizado...", "INFO", "instagram")

    return posts_viewed, f"{saved_count} post(s) salvo(s)"

async def execute_warmup_social_engager(page: Page, target_sec: float) -> Tuple[int, str]:
    """Arquétipo B: Rola o feed por ~1 min, curte 1 post e expande a legenda para leitura."""
    start_t = asyncio.get_event_loop().time()
    posts_viewed = 0
    liked_count = 0
    expanded_caption = False

    while (asyncio.get_event_loop().time() - start_t) < target_sec:
        posts_viewed += 1
        dwell = random.uniform(5.5, 9.5)

        viewport_w = page.viewport_size["width"] if page.viewport_size else 1280
        target_x = random.uniform(viewport_w * 0.35, viewport_w * 0.65)
        target_y = random.uniform(250, 650)
        await HumanController.move_mouse(page, target_x, target_y)

        # 1. Curte 1 publicação visível no feed
        if liked_count == 0 and random.random() < 0.45:
            try:
                like_locators = page.locator("svg[aria-label='Curtir' i], svg[aria-label='Like' i]")
                count = await like_locators.count()
                target_like = None
                for idx in range(count):
                    loc = like_locators.nth(idx)
                    if await loc.is_visible():
                        box = await loc.bounding_box()
                        if box and 100 < box["y"] < 750:
                            target_like = (loc, box)
                            break
                if target_like:
                    l_loc, l_box = target_like
                    btn_x = l_box["x"] + l_box["width"] / 2
                    btn_y = l_box["y"] + l_box["height"] / 2
                    await HumanController.move_mouse(page, btn_x, btn_y)
                    await asyncio.sleep(random.uniform(0.3, 0.6))
                    await l_loc.click()
                    liked_count += 1
                    add_log(f"Instagram: Post #{posts_viewed} curtido no feed com sucesso!", "SUCCESS", "instagram")
                    await HumanController.sleep(1.0, 1.8)
            except Exception:
                pass

        # 2. Expande o texto da legenda de um post para leitura
        if not expanded_caption and random.random() < 0.35:
            try:
                more_btn = page.locator("span:text-is('mais'), span:text-is('more')").first
                if await more_btn.count() > 0 and await more_btn.is_visible():
                    box = await more_btn.bounding_box()
                    if box and 100 < box["y"] < 750:
                        await HumanController.move_mouse(page, box["x"] + box["width"]/2, box["y"] + box["height"]/2)
                        await asyncio.sleep(0.4)
                        await more_btn.click()
                        expanded_caption = True
                        add_log("Instagram: Legenda longa expandida ('... mais'), simulando leitura detalhada!", "INFO", "instagram")
                        # Pausa maior simulando leitura atenta do texto
                        await asyncio.sleep(random.uniform(4.5, 7.5))
            except Exception:
                pass

        remaining = target_sec - (asyncio.get_event_loop().time() - start_t)
        await asyncio.sleep(min(dwell, max(1.5, remaining)))

        if (asyncio.get_event_loop().time() - start_t) >= target_sec:
            break

        scroll_dist = random.randint(450, 750)
        await HumanController.smooth_scroll(page, distance=scroll_dist, steps=random.randint(14, 22))
        elapsed_now = int(asyncio.get_event_loop().time() - start_t)
        add_log(f"Instagram: [Engajador Social] {elapsed_now}s / ~60s - Post #{posts_viewed} visualizado...", "INFO", "instagram")

    summary_str = f"{liked_count} curtida" + (" + legenda lida" if expanded_caption else "")
    return posts_viewed, summary_str

async def execute_warmup_explore_wanderer(page: Page, target_sec: float) -> Tuple[int, str]:
    """Arquétipo C: Navega pela aba Explorar, inspeciona miniaturas e assiste a um post."""
    start_t = asyncio.get_event_loop().time()
    opened_modal = False
    hovers = 0

    try:
        # 1. Clica na aba Explorar na barra lateral ou navega
        explore_btn = page.locator("a[href*='/explore/'], svg[aria-label*='Explorar' i], svg[aria-label*='Explore' i]").first
        if await explore_btn.count() > 0 and await explore_btn.is_visible():
            await HumanController.click(page, explore_btn, hover_time=0.4)
        else:
            await page.goto("https://www.instagram.com/explore/", wait_until="domcontentloaded", timeout=30000)
        add_log("Instagram: Navegando na aba Explorar (/explore/)...", "INFO", "instagram")
        await HumanController.sleep(2.5, 4.0)

        # 2. Rola a grade e faz hover sobre miniaturas
        while (asyncio.get_event_loop().time() - start_t) < target_sec:
            await HumanController.smooth_scroll(page, distance=random.randint(350, 550), steps=12)
            hovers += 1

            # Move o cursor sobre uma imagem da grade (gerando efeito hover de contador)
            vp_w = page.viewport_size["width"] if page.viewport_size else 1280
            await HumanController.move_mouse(page, random.uniform(vp_w * 0.3, vp_w * 0.7), random.uniform(300, 600))
            await asyncio.sleep(random.uniform(2.0, 3.5))

            # 3. Abre uma miniatura da grade em modal ampliado UMA vez
            if not opened_modal and (asyncio.get_event_loop().time() - start_t) > 15:
                try:
                    thumbs = page.locator("article a[href*='/p/'], article a[href*='/reel/'], div a[href*='/p/'], div a[href*='/reel/']")
                    count = await thumbs.count()
                    if count > 0:
                        pick_idx = min(random.randint(0, 3), count - 1)
                        target_thumb = thumbs.nth(pick_idx)
                        if await target_thumb.is_visible():
                            await HumanController.click(page, target_thumb, hover_time=0.5)
                            opened_modal = True
                            add_log("Instagram: Publicação do Explorar aberta em modal ampliado!", "INFO", "instagram")
                            # Assiste ao post/vídeo por 6 a 9s
                            await asyncio.sleep(random.uniform(6.0, 9.0))
                            # Fecha o modal suavemente com tecla Escape
                            await page.keyboard.press("Escape")
                            await HumanController.sleep(1.0, 2.0)
                except Exception:
                    pass

            elapsed_now = int(asyncio.get_event_loop().time() - start_t)
            add_log(f"Instagram: [Explorador de Tendências] {elapsed_now}s / ~60s - Inspecionando grade...", "INFO", "instagram")

    except Exception as e:
        add_log(f"Instagram: Fallback no Explorar ({str(e)}), concluindo pré-aquecimento...", "WARNING", "instagram")

    return hovers, "Grade do Explorar inspecionada" + (" + modal ampliado" if opened_modal else "")

async def execute_warmup_reels_viewer(page: Page, target_sec: float) -> Tuple[int, str]:
    """Arquétipo D: Abre a aba Reels e assiste a vídeos imersivos no player vertical."""
    start_t = asyncio.get_event_loop().time()
    reels_watched = 0

    try:
        # 1. Clica na aba Reels na barra lateral ou navega
        reels_btn = page.locator("a[href*='/reels/'], svg[aria-label*='Reels' i]").first
        if await reels_btn.count() > 0 and await reels_btn.is_visible():
            await HumanController.click(page, reels_btn, hover_time=0.4)
        else:
            await page.goto("https://www.instagram.com/reels/", wait_until="domcontentloaded", timeout=30000)
        add_log("Instagram: Acessando o feed imersivo de Reels (/reels/)...", "INFO", "instagram")
        await HumanController.sleep(3.0, 4.5)

        while (asyncio.get_event_loop().time() - start_t) < target_sec:
            reels_watched += 1
            # Assiste ao Reel atual por 8 a 13 segundos
            watch_time = random.uniform(7.5, 12.5)

            # Move o cursor suavemente sobre o player de vídeo
            vp_w = page.viewport_size["width"] if page.viewport_size else 1280
            await HumanController.move_mouse(page, random.uniform(vp_w * 0.45, vp_w * 0.55), random.uniform(300, 600))

            remaining = target_sec - (asyncio.get_event_loop().time() - start_t)
            await asyncio.sleep(min(watch_time, max(2.0, remaining)))

            if (asyncio.get_event_loop().time() - start_t) >= target_sec:
                break

            # Passa para o próximo Reel usando ArrowDown (comportamento nativo de desktop)
            add_log(f"Instagram: [Espectador de Reels] Assistiu Reel #{reels_watched} ({watch_time:.1f}s). Avançando...", "INFO", "instagram")
            await page.keyboard.press("ArrowDown")
            await HumanController.sleep(1.0, 2.0)

    except Exception as e:
        add_log(f"Instagram: Fallback no player de Reels ({str(e)}), concluindo pré-aquecimento...", "WARNING", "instagram")

    return reels_watched, f"{reels_watched} Reel(s) assistido(s)"

# --------------------------------------------------------
# Executores das 4 Pós-Ações de Esfriamento (Cooldown)
# --------------------------------------------------------
async def click_instagram_profile(page: Page, clean_acc: str = "") -> bool:
    """
    Navega para o perfil do Instagram clicando no item nativo '(PERFIL)' na barra lateral.
    Isso garante que o Instagram vá diretamente para o perfil/página inicial da conta
    sem jamais gerar URLs com espaços ou nomes de exibição (que causam 'Página não encontrada').
    """
    clean_handle = clean_acc.replace("@", "").strip() if clean_acc else ""
    
    # Seletores universais do botão (Perfil) na barra lateral do Instagram (Desktop e Web)
    profile_selectors = [
        # Item com avatar e texto Perfil (como no print da interface do usuário)
        "a[role='link']:has-text('Perfil')",
        "a:has(span:text-is('Perfil'))",
        "div[role='button']:has-text('Perfil')",
        "span:text-is('Perfil')",
        "span:has-text('Perfil')",
        # Seletor pelo avatar circular do perfil no menu lateral
        "a[role='link']:has(img[alt*='perfil' i])",
        "a[role='link']:has(img[alt*='profile' i])",
        "img[alt*='foto do perfil' i]",
        "img[alt*='profile picture' i]",
        # Fallbacks em inglês
        "a[role='link']:has-text('Profile')",
        "span:text-is('Profile')",
        "svg[aria-label*='Perfil' i]",
        "svg[aria-label*='Profile' i]"
    ]

    # Se houver um handle estritamente sem espaços, adiciona como alternativa prioritária
    if clean_handle and " " not in clean_handle:
        profile_selectors.insert(0, f"a[href='/{clean_handle}/']")
        profile_selectors.insert(1, f"a[href*='/{clean_handle}']")

    clicked = False
    for sel in profile_selectors:
        try:
            loc = page.locator(sel).first
            if await loc.count() > 0 and await loc.is_visible():
                await HumanController.click(page, loc, hover_time=0.4)
                add_log("Instagram: Clique realizado no ícone do menu nativo: (PERFIL)", "SUCCESS", "instagram")
                clicked = True
                break
        except Exception:
            continue

    if not clicked:
        # Se nenhum botão foi clicável e o handle for estritamente válido (sem espaços)
        if clean_handle and " " not in clean_handle:
            try:
                add_log(f"Instagram: Acessando perfil diretamente (@{clean_handle})...", "INFO", "instagram")
                await page.goto(f"https://www.instagram.com/{clean_handle}/", wait_until="domcontentloaded", timeout=30000)
                clicked = True
            except Exception:
                pass

    if not clicked:
        # Fallback seguro absoluto: clica na Página Inicial do Instagram
        try:
            home_btn = page.locator("svg[aria-label*='Página inicial' i], svg[aria-label*='Home' i], a[href='/']").first
            if await home_btn.count() > 0 and await home_btn.is_visible():
                await HumanController.click(page, home_btn, hover_time=0.3)
            else:
                await page.goto("https://www.instagram.com/", wait_until="domcontentloaded", timeout=30000)
            clicked = True
        except Exception:
            pass

    return clicked

async def execute_cooldown_profile_grid(page: Page, clean_acc: str) -> str:
    """Pós-Ação A: Conferência de grade do perfil + rolagem."""
    add_log(f"Instagram: [Pós-Ação: Conferência de Grade] Acessando perfil via ícone (PERFIL)...", "INFO", "instagram")
    try:
        await click_instagram_profile(page, clean_acc)
        await HumanController.sleep(2.5, 3.8)
        await HumanController.smooth_scroll(page, distance=300, steps=5)
        await HumanController.sleep(1.0, 1.8)
        await HumanController.smooth_scroll(page, distance=-300, steps=5)
        await HumanController.sleep(1.5, 2.5)
    except Exception:
        pass
    return await capture_latest_reel_url(page, clean_acc)

async def execute_cooldown_feed_relaxation(page: Page, clean_acc: str) -> str:
    """Pós-Ação B: Descompressão no feed inicial, rolagem lenta de 3 posts."""
    add_log("Instagram: [Pós-Ação: Descompressão no Feed] Navegando no feed principal...", "INFO", "instagram")
    try:
        home_btn = page.locator("svg[aria-label*='Página inicial' i], svg[aria-label*='Home' i], a[href='/']").first
        if await home_btn.count() > 0 and await home_btn.is_visible():
            await HumanController.click(page, home_btn, hover_time=0.3)
            await HumanController.sleep(1.5, 2.5)

        for i in range(1, 4):
            await HumanController.smooth_scroll(page, distance=random.randint(480, 700), steps=8)
            await HumanController.move_mouse(page, random.randint(350, 750), random.randint(250, 580))
            await asyncio.sleep(random.uniform(2.5, 4.0))
            add_log(f"Instagram: Post #{i} do feed visualizado na descompressão...", "INFO", "instagram")
    except Exception:
        pass
    return await execute_cooldown_profile_grid(page, clean_acc)

async def execute_cooldown_reels_afterparty(page: Page, clean_acc: str) -> str:
    """Pós-Ação C: Consumo rápido de 1 a 2 Reels no player vertical."""
    add_log("Instagram: [Pós-Ação: Consumo de Reels] Assistindo Reels rápidos pós-envio...", "INFO", "instagram")
    try:
        reels_btn = page.locator("a[href*='/reels/'], svg[aria-label*='Reels' i]").first
        if await reels_btn.count() > 0 and await reels_btn.is_visible():
            await HumanController.click(page, reels_btn, hover_time=0.4)
        else:
            await page.goto("https://www.instagram.com/reels/", wait_until="domcontentloaded", timeout=30000)
        await HumanController.sleep(2.5, 3.5)
        await asyncio.sleep(random.uniform(7.0, 10.0))
        await page.keyboard.press("ArrowDown")
        await asyncio.sleep(random.uniform(4.0, 6.0))
    except Exception:
        pass
    return await execute_cooldown_profile_grid(page, clean_acc)

async def execute_cooldown_explore_scan(page: Page, clean_acc: str) -> str:
    """Pós-Ação D: Olhada no Explorar com hover sobre miniaturas."""
    add_log("Instagram: [Pós-Ação: Olhada no Explorar] Inspecionando tendências no Explorar...", "INFO", "instagram")
    try:
        explore_btn = page.locator("a[href*='/explore/'], svg[aria-label*='Explorar' i]").first
        if await explore_btn.count() > 0 and await explore_btn.is_visible():
            await HumanController.click(page, explore_btn, hover_time=0.4)
        else:
            await page.goto("https://www.instagram.com/explore/", wait_until="domcontentloaded", timeout=30000)
        await HumanController.sleep(2.5, 3.5)
        await HumanController.smooth_scroll(page, distance=400, steps=8)
        vp_w = page.viewport_size["width"] if page.viewport_size else 1280
        await HumanController.move_mouse(page, random.uniform(vp_w * 0.35, vp_w * 0.65), random.uniform(300, 600))
        await asyncio.sleep(random.uniform(4.0, 7.0))
    except Exception:
        pass
    return await execute_cooldown_profile_grid(page, clean_acc)

async def capture_latest_reel_url(page: Page, clean_acc: str) -> str:
    """Captura com segurança o link do Reel recém-publicado na grade do perfil."""
    post_url = ""
    try:
        first_media = page.locator("article a[href*='/reel/'], article a[href*='/p/'], div a[href*='/reel/'], div a[href*='/p/']").first
        if await first_media.count() > 0:
            href = await first_media.get_attribute("href")
            if href:
                post_url = f"https://www.instagram.com{href}" if href.startswith('/') else href
    except Exception:
        pass

    if not post_url:
        clean_handle = clean_acc.replace("@", "").strip() if clean_acc else ""
        if clean_handle and " " not in clean_handle:
            post_url = f"https://www.instagram.com/{clean_handle}/"
        else:
            post_url = "https://www.instagram.com/"
    return post_url
