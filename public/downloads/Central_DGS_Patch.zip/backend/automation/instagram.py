import os
import random
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable
from playwright.async_api import async_playwright
from backend.automation.browser_manager import BrowserManager, HumanController, STEALTH_INIT_SCRIPT, is_cdp_alive
from backend.database import add_log
from backend.automation.instagram_engine_helpers import (
    select_unique_archetypes,
    save_account_behavior_history,
    execute_warmup_feed_curator,
    execute_warmup_social_engager,
    execute_warmup_explore_wanderer,
    execute_warmup_reels_viewer,
    execute_cooldown_profile_grid,
    execute_cooldown_feed_relaxation,
    execute_cooldown_reels_afterparty,
    execute_cooldown_explore_scan
)

def format_caption_paragraphs(text: str) -> str:
    """
    Garante que os parágrafos do texto fiquem perfeitamente espaçados
    com linha em branco dupla (\n\n), idêntico à formatação original do Canva.
    """
    if not text:
        return ""
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    blocks = [b.strip() for b in normalized.split("\n") if b.strip()]
    return "\n\n".join(blocks)

# ========================================================
# FUNÇÕES MODULARES DE ETAPA DO INSTAGRAM
# ========================================================
async def apply_original_crop(page) -> bool:
    """Ajusta o corte para 'Original' (proporção 9:16 vertical)."""
    try:
        add_log("Instagram: Localizando botão 'Selecionar corte'...", "INFO", "instagram")
        corte_svg = page.locator("svg[aria-label*='corte' i], svg[aria-label*='crop' i]").first
        if await corte_svg.count() > 0 and await corte_svg.is_visible():
            await HumanController.click(page, corte_svg, hover_time=0.3)
            add_log("Instagram: Menu de proporção aberto via ícone SVG.", "INFO", "instagram")
            await HumanController.sleep(0.8, 1.4)

            orig_btn = page.locator("div[role='button']:has-text('Original'), span:text-is('Original')").first
            if await orig_btn.count() > 0 and await orig_btn.is_visible():
                await HumanController.click(page, orig_btn, hover_time=0.3)
                add_log("Instagram: Proporção 'Original' (9:16 vertical) aplicada com sucesso!", "SUCCESS", "instagram")
                await HumanController.sleep(1.0, 1.8)
                return True
            else:
                add_log("Instagram: Opção 'Original' não encontrada no menu aberto.", "WARNING", "instagram")
        else:
            add_log("Instagram: Ícone de corte não exibido no momento.", "WARNING", "instagram")
    except Exception as e:
        add_log(f"Instagram: Erro ao ajustar corte original: {str(e)}", "WARNING", "instagram")
    return False

async def click_next_button(page, step_name: str = "") -> bool:
    """Clica no botão 'Avançar' do cabeçalho do diálogo e aguarda a transição."""
    for attempt in range(3):
        next_btn = page.locator(
            "div[role='dialog'] div[role='button']:has-text('Avançar'), "
            "div[role='dialog'] button:has-text('Avançar'), "
            "div[role='dialog'] div[role='button']:has-text('Next'), "
            "div[role='dialog'] button:has-text('Next'), "
            "div[role='button']:has-text('Avançar'), "
            "button:has-text('Avançar')"
        ).first
        if await next_btn.count() > 0 and await next_btn.is_visible():
            await HumanController.click(page, next_btn, hover_time=0.4)
            add_log(f"Instagram: Avançar ({step_name}) clicado (tentativa {attempt + 1}).", "INFO", "instagram")
            await HumanController.sleep(1.5, 2.5)
            return True
        await asyncio.sleep(1.0)
    return False

async def apply_smart_cover(page) -> bool:
    """Analisa os frames candidatos e seleciona o melhor frame para a capa (Anti-duplicidade)."""
    add_log("Instagram: Analisando frames para escolha da melhor capa do vídeo...", "INFO", "instagram")
    try:
        cover_selection = await page.evaluate("""async () => {
            const dialog = document.querySelector("div[role='dialog']") || document.body;
            const elCover = Array.from(dialog.querySelectorAll('*')).find(el => {
                const t = (el.innerText || '').trim();
                return t === 'Foto da capa' || t === 'Cover photo';
            });
            if (!elCover) return { success: false, error: "Seção 'Foto da capa' não encontrada" };

            const slider = dialog.querySelector("div[role='slider']");
            const sRect = slider ? slider.getBoundingClientRect() : null;

            const allDivs = Array.from(dialog.querySelectorAll('div'));
            const frameDivs = allDivs.filter(d => {
                const bg = window.getComputedStyle(d).backgroundImage || '';
                const r = d.getBoundingClientRect();
                return bg.includes('blob:') && r.height > 60 && r.height < 150 && r.y < 350;
            });

            if (frameDivs.length === 0) {
                return { success: false, error: "Nenhum frame candidato encontrado" };
            }

            const scores = [];
            for (let i = 0; i < frameDivs.length; i++) {
                const div = frameDivs[i];
                const bg = window.getComputedStyle(div).backgroundImage || '';
                const match = bg.match(/url\\(["']?(blob:[^"']+)["']?\\)/);
                if (!match) continue;
                const blobUrl = match[1];

                try {
                    const img = new Image();
                    img.crossOrigin = "anonymous";
                    await new Promise((res, rej) => {
                        img.onload = res;
                        img.onerror = rej;
                        img.src = blobUrl;
                        setTimeout(() => rej(new Error("Timeout cover blob")), 1500);
                    });

                    const canvas = document.createElement('canvas');
                    canvas.width = 64;
                    canvas.height = 64;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, 64, 64);
                    const data = ctx.getImageData(0, 0, 64, 64).data;

                    let sumLum = 0;
                    let lumValues = [];
                    let satSum = 0;

                    for (let p = 0; p < data.length; p += 4) {
                        const r = data[p];
                        const g = data[p+1];
                        const b = data[p+2];
                        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
                        sumLum += lum;
                        lumValues.push(lum);

                        const max = Math.max(r, g, b);
                        const min = Math.min(r, g, b);
                        const sat = max === 0 ? 0 : (max - min) / max;
                        satSum += sat;
                    }

                    const meanLum = sumLum / lumValues.length;
                    let variance = 0;
                    for (let val of lumValues) {
                        variance += Math.pow(val - meanLum, 2);
                    }
                    const stdDev = Math.sqrt(variance / lumValues.length);
                    const meanSat = satSum / lumValues.length;

                    let edgeEnergy = 0;
                    for (let y = 0; y < 63; y++) {
                        for (let x = 0; x < 63; x++) {
                            const idx1 = (y * 64 + x) * 4;
                            const idx2 = (y * 64 + (x + 1)) * 4;
                            const idx3 = ((y + 1) * 64 + x) * 4;
                            edgeEnergy += Math.abs(data[idx1] - data[idx2]) + Math.abs(data[idx1] - data[idx3]);
                        }
                    }

                    const lumScore = 1.0 - Math.min(1.0, Math.abs(meanLum - 130) / 130);
                    const contrastScore = Math.min(1.0, stdDev / 60.0);
                    const satScore = Math.min(1.0, meanSat / 0.4);
                    const edgeScore = Math.min(1.0, edgeEnergy / 45000.0);

                    const totalScore = (edgeScore * 0.40) + (contrastScore * 0.25) + (lumScore * 0.20) + (satScore * 0.15);
                    scores.push({ index: i, score: totalScore, div: div, rect: div.getBoundingClientRect() });
                } catch (e) {
                    scores.push({ index: i, score: 0, div: div, rect: div.getBoundingClientRect() });
                }
            }

            if (scores.length === 0) return { success: false, error: "Falha na análise dos frames" };
            scores.sort((a, b) => b.score - a.score);
            const best = scores[0];

            return {
                success: true,
                bestIndex: best.index,
                totalFrames: frameDivs.length,
                targetRect: {
                    x: best.rect.x,
                    y: best.rect.y,
                    w: best.rect.width,
                    h: best.rect.height
                },
                sliderRect: sRect ? {
                    x: sRect.x,
                    y: sRect.y,
                    w: sRect.width,
                    h: sRect.height
                } : null
            };
        }""")

        if cover_selection and cover_selection.get("success"):
            t_rect = cover_selection["targetRect"]
            s_rect = cover_selection.get("sliderRect")
            target_x = t_rect["x"] + t_rect["w"] / 2
            target_y = t_rect["y"] + t_rect["h"] / 2

            if s_rect:
                start_x = s_rect["x"] + s_rect["w"] / 2
                start_y = s_rect["y"] + s_rect["h"] / 2
                await HumanController.drag(page, start_x, start_y, target_x, target_y)
            else:
                await HumanController.move_mouse(page, target_x, target_y)
                await page.mouse.click(target_x, target_y)

            best_idx = cover_selection.get("bestIndex", 0) + 1
            total = cover_selection.get("totalFrames", 5)
            add_log(f"Instagram: Capa alterada com sucesso! Frame {best_idx}/{total} selecionado (alta retenção/anti-duplicidade).", "SUCCESS", "instagram")
            await HumanController.sleep(1.8, 2.8)
            return True
    except Exception as e_cover:
        add_log(f"Instagram: Erro ao selecionar frame de capa: {str(e_cover)}", "WARNING", "instagram")
    return False

async def paste_formatted_caption(page, caption: str, hashtags: str = "") -> bool:
    """Insere a legenda com espaçamento autêntico de parágrafos e fecha autocompletes."""
    clean_caption = format_caption_paragraphs(caption)
    clean_hashtags = hashtags.strip() if hashtags else ""
    full_caption = f"{clean_caption}\n\n{clean_hashtags}" if clean_caption and clean_hashtags else (clean_caption or clean_hashtags)

    add_log("Instagram: Colando legenda com parágrafos separados...", "INFO", "instagram")
    caption_area = page.locator("div[role='dialog'] div[aria-label*='legenda' i], div[role='dialog'] div[aria-label*='caption' i], div[role='dialog'] div[contenteditable='true']").first

    if await caption_area.count() > 0:
        await HumanController.click(page, caption_area, hover_time=0.3)
        await HumanController.sleep(0.8, 1.4)
        try:
            await page.evaluate("""async (text) => {
                await navigator.clipboard.writeText(text);
            }""", full_caption)
            await page.keyboard.press("Control+V")
            add_log("Instagram: Legenda colada com sucesso em menos de 1 segundo!", "SUCCESS", "instagram")
        except Exception as e_paste:
            add_log(f"Instagram: Fallback ao colar legenda ({str(e_paste)}), inserindo via script...", "WARNING", "instagram")
            await page.evaluate("""(text) => {
                const el = document.activeElement;
                if (el) document.execCommand('insertText', false, text);
            }""", full_caption)

        await HumanController.sleep(1.2, 2.0)
        await page.keyboard.press("Escape")
        await HumanController.sleep(0.3, 0.6)
        await page.keyboard.press("Escape")
        await HumanController.sleep(0.3, 0.6)
        await page.evaluate("""() => {
            if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
        }""")
        return True
    return False

async def ensure_schedule_toggle_on(page) -> bool:
    """Verifica e ativa a chave seletora 'Programar conteúdo'."""
    try:
        is_on = await page.evaluate("""() => {
            const dialog = document.querySelector("div[role='dialog']") || document.body;
            const allEls = Array.from(dialog.querySelectorAll('*'));
            const lbl = allEls.find(e => (e.innerText || '').trim() === 'Programar conteúdo');
            if (!lbl) return null;
            
            const parent = lbl.closest('div');
            const sw = parent ? (parent.querySelector("[role='switch'], input[type='checkbox']") || parent.parentElement.querySelector("[role='switch'], input[type='checkbox']")) : null;
            if (!sw) return null;
            
            const checked = sw.getAttribute('aria-checked') === 'true' || sw.checked || sw.getAttribute('value') === 'true';
            return { checked, rect: sw.getBoundingClientRect() };
        }""")
        
        if is_on is not None:
            if not is_on["checked"]:
                r = is_on["rect"]
                await HumanController.move_mouse(page, r["x"] + r["width"] / 2, r["y"] + r["height"] / 2)
                await page.mouse.click(r["x"] + r["width"] / 2, r["y"] + r["height"] / 2)
                await HumanController.sleep(1.0, 1.8)
                add_log("Instagram: Chave 'Programar conteúdo' ativada com sucesso!", "INFO", "instagram")
            else:
                add_log("Instagram: Chave 'Programar conteúdo' já estava ativada.", "INFO", "instagram")
            return True
    except Exception as e:
        add_log(f"Instagram: Aviso ao verificar chave de programação: {str(e)}", "WARNING", "instagram")
    return False

async def set_meta_schedule_datetime(page, target_dt: datetime) -> bool:
    """Define a Data e a Hora nos campos da Meta."""
    now = datetime.now()
    # Regra da Meta: mínimo 20 minutos à frente. Usamos 25 min por segurança absoluta.
    if target_dt < now + timedelta(minutes=25):
        target_dt = now + timedelta(minutes=25)
        add_log(f"Instagram: Horário ajustado para {target_dt.strftime('%H:%M')} (mínimo de 20min exigido pela Meta).", "INFO", "instagram")

    # 1. Ajustar DATA se for diferente de hoje
    try:
        if target_dt.date() != now.date():
            add_log(f"Instagram: Selecionando data no calendário ({target_dt.strftime('%d/%m/%Y')})...", "INFO", "instagram")
            date_click = await page.evaluate("""() => {
                const dialog = document.querySelector("div[role='dialog']") || document.body;
                const lbl = Array.from(dialog.querySelectorAll('*')).find(e => (e.innerText || '').trim() === 'Data');
                if (!lbl) return null;
                const parent = lbl.closest('div');
                const trigger = parent ? (parent.querySelector("div[role='button'], div[tabindex='0'], span") || parent.nextElementSibling) : null;
                if (trigger) {
                    const r = trigger.getBoundingClientRect();
                    return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
                }
                return null;
            }""")
            if date_click:
                await HumanController.move_mouse(page, date_click["x"], date_click["y"])
                await page.mouse.click(date_click["x"], date_click["y"])
                await HumanController.sleep(1.0, 1.8)
                
                day_num = target_dt.day
                day_clicked = await page.evaluate("""(d) => {
                    const dialog = document.querySelector("div[role='dialog']") || document.body;
                    const candidates = Array.from(dialog.querySelectorAll('div, button, span')).filter(e => (e.innerText || '').trim() === String(d));
                    const cell = candidates.find(c => {
                        const r = c.getBoundingClientRect();
                        return r.width >= 20 && r.width <= 50 && r.height >= 20 && r.height <= 50;
                    });
                    if (cell) {
                        const r = cell.getBoundingClientRect();
                        return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
                    }
                    return null;
                }""", day_num)
                if day_clicked:
                    await HumanController.move_mouse(page, day_clicked["x"], day_clicked["y"])
                    await page.mouse.click(day_clicked["x"], day_clicked["y"])
                    await HumanController.sleep(0.8, 1.4)
                    add_log(f"Instagram: Dia {day_num} selecionado no calendário!", "SUCCESS", "instagram")
    except Exception as e_date:
        add_log(f"Instagram: Aviso ao ajustar data: {str(e_date)}", "WARNING", "instagram")

    # 2. Ajustar HORA
    # Regra da Meta: O horário precisa ser no mínimo 20 minutos à frente. Usamos 25 min como margem segura.
    min_allowed = datetime.now() + timedelta(minutes=25)
    if target_dt < min_allowed:
        target_dt = min_allowed
    time_str = target_dt.strftime("%H:%M")
    add_log(f"Instagram: Definindo horário programado para {time_str}...", "INFO", "instagram")
    try:
        hour_input_coords = await page.evaluate("""() => {
            const dialog = document.querySelector("div[role='dialog']") || document.body;
            const lbl = Array.from(dialog.querySelectorAll('*')).find(e => (e.innerText || '').trim() === 'Hora');
            if (!lbl) return null;
            const parent = lbl.closest('div');
            const inp = parent ? (parent.querySelector('input') || parent.parentElement.querySelector('input')) : null;
            if (inp) {
                const r = inp.getBoundingClientRect();
                return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
            }
            return null;
        }""")
        
        if hour_input_coords:
            await HumanController.move_mouse(page, hour_input_coords["x"], hour_input_coords["y"])
            await page.mouse.click(hour_input_coords["x"], hour_input_coords["y"])
            await asyncio.sleep(0.3)
            await page.keyboard.press("Control+A")
            await asyncio.sleep(0.1)
            await page.keyboard.press("Backspace")
            await asyncio.sleep(0.1)
            for char in time_str:
                await page.keyboard.press(char)
                await asyncio.sleep(random.uniform(0.08, 0.16))
            
            await HumanController.sleep(0.5, 1.0)
            # Clica fora ou dá Tab para disparar eventos de validação do React
            try:
                title_lbl = page.locator("div[role='dialog'] span:has-text('Novo reel'), div[role='dialog'] h1").first
                if await title_lbl.count() > 0:
                    await HumanController.click(page, title_lbl, hover_time=0.2)
                else:
                    await page.keyboard.press("Tab")
            except Exception:
                await page.keyboard.press("Tab")

            await HumanController.sleep(0.5, 1.0)

            # Verifica se apareceu aviso vermelho de horário inferior a 20 minutos
            has_warning = await page.evaluate("""() => {
                const dialog = document.querySelector("div[role='dialog']");
                if (!dialog) return false;
                const t = (dialog.innerText || '').toLowerCase();
                return t.includes('no mínimo daqui a 20 minutos') || t.includes('pelo menos 20 minutos') || t.includes('no mínimo 20 minutos');
            }""")

            if has_warning:
                target_dt = target_dt + timedelta(minutes=30)
                time_str = target_dt.strftime("%H:%M")
                add_log(f"Instagram: Ajustando horário para {time_str} para liberar o botão Programar...", "INFO", "instagram")
                await page.mouse.click(hour_input_coords["x"], hour_input_coords["y"])
                await asyncio.sleep(0.2)
                await page.keyboard.press("Control+A")
                await asyncio.sleep(0.1)
                await page.keyboard.press("Backspace")
                for char in time_str:
                    await page.keyboard.press(char)
                    await asyncio.sleep(0.1)
                await page.keyboard.press("Tab")
                await HumanController.sleep(0.5, 1.0)

            add_log(f"Instagram: Horário {time_str} validado com sucesso!", "SUCCESS", "instagram")
            return True
    except Exception as e_hour:
        add_log(f"Instagram: Aviso ao definir hora: {str(e_hour)}", "WARNING", "instagram")
    return False

async def click_schedule_button(page) -> bool:
    """Clica exclusivamente no botão 'Programar' no cabeçalho do diálogo (ignora 'Programar conteúdo')."""
    # 1. Procura exclusivamente no cabeçalho do diálogo (y < 220) onde o texto exato é 'Programar' ou 'Schedule'
    coords = await page.evaluate("""() => {
        const dialog = document.querySelector("div[role='dialog']");
        if (!dialog) return null;
        
        // Elementos clicáveis no cabeçalho superior (y < 220)
        const candidates = Array.from(dialog.querySelectorAll("div[role='button'], button, span, a"));
        const target = candidates.find(b => {
            const t = (b.innerText || '').trim();
            const r = b.getBoundingClientRect();
            // Apenas no cabeçalho superior (y < 220) e com texto EXATO 'Programar' ou 'Schedule' (nunca 'Programar conteúdo')
            return (t === 'Programar' || t === 'Schedule') && r.y < 220 && r.width > 20 && r.height > 10;
        });
        
        if (target) {
            const r = target.getBoundingClientRect();
            return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
        }
        return null;
    }""")
    if coords:
        await HumanController.move_mouse(page, coords["x"], coords["y"])
        await page.mouse.click(coords["x"], coords["y"])
        add_log("Instagram: Botão 'Programar' do cabeçalho clicado com sucesso!", "INFO", "instagram")
        return True

    # 2. Fallback de seletores com text-is exato no cabeçalho
    exact_selectors = [
        "div[role='dialog'] div[role='button']:text-is('Programar')",
        "div[role='dialog'] button:text-is('Programar')",
        "div[role='dialog'] span:text-is('Programar')",
        "div[role='dialog'] div[role='button']:text-is('Schedule')",
        "div[role='dialog'] button:text-is('Schedule')"
    ]
    for sel in exact_selectors:
        try:
            btn = page.locator(sel).first
            if await btn.count() > 0 and await btn.is_visible():
                box = await btn.bounding_box()
                if box and box["y"] < 220:
                    await HumanController.click(page, btn, hover_time=random.uniform(0.4, 0.7))
                    add_log("Instagram: Botão 'Programar' clicado!", "INFO", "instagram")
                    return True
        except Exception:
            continue
    return False

async def wait_for_schedule_confirmation(page) -> bool:
    """Aguarda o término do upload e a confirmação de agendamento na Meta."""
    add_log("Instagram: Aguardando processamento e confirmação de agendamento na Meta...", "INFO", "instagram")
    seen_scheduling = False

    for second in range(90):
        await asyncio.sleep(2)
        try:
            res = await page.evaluate("""() => {
                const dialog = document.querySelector("div[role='dialog']");
                const text = ((dialog ? dialog.innerText : '') + ' ' + (document.body.innerText || '')).toLowerCase();
                
                const isScheduling = text.includes('programando') || text.includes('scheduling');
                const hasConcluir = !!dialog && Array.from(dialog.querySelectorAll("div[role='button'], button, span")).some(b => {
                    const t = (b.innerText || '').trim();
                    return t === 'Concluir' || t === 'Done';
                });
                const isSuccessText = text.includes('reel foi programado') || text.includes('reel programado') || 
                                      text.includes('sua publicação foi programada') || text.includes('your reel has been scheduled');
                
                const dialogOrToast = dialog ? dialog.innerText.toLowerCase() : '';
                const explicitErrorKeys = [
                    'não foi possível programar', 
                    'não foi possível compartilhar',
                    'could not schedule', 
                    'could not share',
                    'user restricted from uploading',
                    'sua conta está temporariamente',
                    'bloqueado para compartilhar',
                    'action blocked'
                ];
                const matchedErrors = explicitErrorKeys.filter(k => dialogOrToast.includes(k));
                const isError = matchedErrors.length > 0;
                
                return { 
                    isScheduling, 
                    hasConcluir,
                    isSuccessText, 
                    isError, 
                    matchedErrors,
                    dialogText: (dialog ? dialog.innerText : '').slice(0, 400),
                    dialogOpen: !!dialog 
                };
            }""")
            
            if res.get("isScheduling"):
                seen_scheduling = True
                if second % 5 == 0:
                    add_log(f"Instagram: Programando na Meta ({second * 2}s)...", "INFO", "instagram")

            if res.get("hasConcluir") or res.get("isSuccessText"):
                add_log("Instagram: Confirmação recebida: 'Seu reel foi programado'!", "SUCCESS", "instagram")
                return True
                
            if seen_scheduling and not res.get("dialogOpen"):
                add_log("Instagram: Diálogo finalizado com sucesso pela Meta!", "SUCCESS", "instagram")
                return True

            if res.get("isError"):
                err_info = ", ".join(res.get("matchedErrors", []))
                diag_txt = res.get("dialogText", "").replace("\n", " ").strip()
                add_log(f"Instagram: Erro da Meta detectado [{err_info}]: {diag_txt[:200]}", "ERROR", "instagram")
                try:
                    await page.screenshot(path="C:/Users/PC GAMER/.gemini/antigravity/brain/bb6dfddb-ea07-4d84-adaa-13bfbc790ae1/meta_error_screen.png")
                except Exception:
                    pass
                return False
                
            if not res.get("dialogOpen") and second >= 4:
                return True
        except Exception:
            pass
    return False

async def click_concluir_button(page):
    """Clica no botão 'Concluir' da tela de sucesso."""
    try:
        btn = page.locator("div[role='dialog'] button:has-text('Concluir'), div[role='dialog'] div[role='button']:has-text('Concluir'), button:has-text('Concluir'), div[role='button']:has-text('Concluir'), button:has-text('Done')").first
        if await btn.count() > 0 and await btn.is_visible():
            await HumanController.click(page, btn, hover_time=0.3)
            await HumanController.sleep(1.0, 1.8)
    except Exception:
        pass

async def schedule_single_instagram_reel(
    page,
    video_path: str,
    caption: str,
    hashtags: str,
    target_dt: datetime,
    clean_acc: str = "",
    step_callback: Optional[Callable] = None
) -> Dict[str, Any]:
    """
    Agenda um único Reel na Central de Conteúdo Programado do Instagram (/scheduled_content/).
    """
    async def _notify_step(fraction: float, msg: str):
        if step_callback:
            try:
                res = step_callback(fraction, msg)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo não encontrado: {video_path}"}

    target_url = "https://www.instagram.com/scheduled_content/"
    if "scheduled_content" not in page.url or await page.locator("div[role='dialog']").count() > 0:
        add_log("Instagram: Acessando Central de Conteúdo Programado da Meta...", "INFO", "instagram")
        await page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
        await HumanController.sleep(2.0, 3.5)

    await _notify_step(0.1, "Abrindo formulário de programação da Meta...")

    # 1. Abre modal se não estiver aberto
    file_input = page.locator("div[role='dialog'] input[type='file'], input[type='file']").first
    if await file_input.count() == 0 or not await file_input.is_visible():
        sched_btn = page.locator(
            "button:has-text('Programar conteúdo'), "
            "div[role='button']:has-text('Programar conteúdo'), "
            "a:has-text('Programar conteúdo'), "
            "button:has-text('Schedule content'), "
            "div[role='button']:has-text('Schedule content')"
        ).first
        if await sched_btn.count() > 0 and await sched_btn.is_visible():
            await HumanController.click(page, sched_btn, hover_time=0.4)
            await HumanController.sleep(1.5, 2.5)

    # 2. Upload de Arquivo
    file_input = page.locator("div[role='dialog'] input[type='file'], input[type='file']").first
    if await file_input.count() > 0:
        await file_input.set_input_files(video_path)
    else:
        select_pc = page.locator("button:has-text('Selecionar do computador'), div[role='button']:has-text('Selecionar do computador')").first
        if await select_pc.count() > 0:
            async with page.expect_file_chooser() as fc_info:
                await HumanController.click(page, select_pc, hover_time=0.3)
            fc = await fc_info.value
            await fc.set_files(video_path)
        else:
            return {"success": False, "error": "Botão de upload de vídeo não encontrado."}

    add_log(f"Instagram: Vídeo carregado: {os.path.basename(video_path)}", "INFO", "instagram")
    await _notify_step(0.25, f"Vídeo carregado ({os.path.basename(video_path)}). Ajustando corte...")
    await HumanController.sleep(3.5, 5.5)

    # 3. Corte Original 9:16
    await apply_original_crop(page)
    await click_next_button(page, "Corte")
    await HumanController.sleep(1.5, 2.5)

    # 4. Capa Inteligente
    await _notify_step(0.45, "Ajustando capa inteligente e avançando...")
    await apply_smart_cover(page)
    await click_next_button(page, "Capa")
    await HumanController.sleep(1.5, 2.5)

    # 5. Legenda
    await _notify_step(0.6, "Inserindo legenda e hashtags...")
    await paste_formatted_caption(page, caption, hashtags)
    await HumanController.sleep(1.0, 1.8)

    # 6. Chave Programar Conteúdo
    await ensure_schedule_toggle_on(page)
    await HumanController.sleep(0.8, 1.5)

    # 7. Data e Hora
    sched_str = target_dt.strftime("%d/%m às %H:%M")
    await _notify_step(0.75, f"Definindo agendamento para {sched_str}...")
    await set_meta_schedule_datetime(page, target_dt)
    await HumanController.sleep(1.2, 2.0)

    # 8. Clicar em Programar
    await _notify_step(0.85, "Confirmando agendamento na Meta...")
    clicked = await click_schedule_button(page)
    if not clicked:
        return {"success": False, "error": "Botão 'Programar' não encontrado."}

    # 9. Aguardar confirmação de agendamento na rede
    await _notify_step(0.92, "Aguardando confirmação dos servidores da Meta...")
    confirmed = await wait_for_schedule_confirmation(page)
    if not confirmed:
        return {"success": False, "error": "Tempo limite de confirmação de agendamento na Meta esgotado."}

    # 10. Clicar em 'Concluir'
    await click_concluir_button(page)
    await HumanController.sleep(1.5, 2.5)

    add_log(f"Instagram: Reel programado na Meta com sucesso para {sched_str}!", "SUCCESS", "instagram")
    await _notify_step(1.0, f"Reel programado com sucesso para {sched_str}!")
    return {
        "success": True,
        "detail": f"Programado na Meta ({sched_str})",
        "url": "https://www.instagram.com/scheduled_content/"
    }

async def schedule_instagram_batch(
    profile_dir: str, 
    items: List[Dict[str, Any]], 
    headless: bool = False,
    account_name: str = "",
    progress_callback: Optional[Callable] = None
) -> Dict[str, Any]:
    """
    Agenda múltiplos vídeos em lote dentro do Instagram em uma única sessão.
    Após cada agendamento, executa o ciclo humano completo:
      1. Entra no perfil (execute_cooldown_profile_grid)
      2. Rola o feed (execute_cooldown_feed_relaxation)
      3. Entra no Reels e assiste alguns vídeos (execute_cooldown_reels_afterparty)
    E depois retorna para a Central de Conteúdo Programado para agendar o próximo.
    """
    total = len(items)
    results = []

    async def _notify(idx: int, tot: int, pct: int, msg: str):
        if progress_callback:
            try:
                res = progress_callback(idx, tot, pct, msg)
                if asyncio.iscoroutine(res):
                    await res
            except Exception:
                pass

    async with async_playwright() as p:
        # Silencia áudio mesmo em modo visível para não atrapalhar o usuário com reprodução de reels
        args = BrowserManager.get_context_args(profile_dir, headless=headless, mute_audio=True)
        context = await p.chromium.launch_persistent_context(**args)

        json_cookies_path = os.path.join(profile_dir, "cookies.json")
        if os.path.exists(json_cookies_path):
            try:
                import json
                with open(json_cookies_path, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
                await context.add_cookies(c_data)
            except Exception:
                pass

        page = context.pages[0] if context.pages else await context.new_page()
        if not headless:
            try:
                await page.bring_to_front()
                BrowserManager.bring_window_to_front("instagram")
            except Exception:
                pass

        if STEALTH_INIT_SCRIPT:
            await page.add_init_script(STEALTH_INIT_SCRIPT)
        if headless:
            await page.add_init_script("window.__mute_audio_force = true;")

        try:
            for idx, item in enumerate(items, 1):
                raw_sched = item.get("scheduled_datetime") or item.get("scheduled_time")
                if isinstance(raw_sched, str):
                    try:
                        target_dt = datetime.fromisoformat(raw_sched)
                    except Exception:
                        target_dt = datetime.now() + timedelta(minutes=25 * idx)
                elif isinstance(raw_sched, datetime):
                    target_dt = raw_sched
                else:
                    target_dt = datetime.now() + timedelta(minutes=25 * idx)

                # Callback granular de cada etapa dentro do vídeo
                base_pct = ((idx - 1) / total) * 100
                slice_pct = (1.0 / total) * 100

                async def on_single_step(fraction: float, step_msg: str):
                    cur_pct = max(1, min(99, round(base_pct + (fraction * 0.7 * slice_pct))))
                    await _notify(idx, total, cur_pct, step_msg)

                await _notify(
                    idx, total, max(5, round(base_pct + 2)),
                    f"Iniciando agendamento {idx}/{total}: preparando {os.path.basename(item['filepath'])}..."
                )

                # Agenda o vídeo no Instagram
                res = await schedule_single_instagram_reel(
                    page=page,
                    video_path=item["filepath"],
                    caption=item.get("display_caption") or item.get("custom_caption") or item.get("caption") or "",
                    hashtags=item.get("display_hashtags") or item.get("custom_hashtags") or item.get("hashtags") or "",
                    target_dt=target_dt,
                    clean_acc=account_name,
                    step_callback=on_single_step
                )

                results.append({"queue_id": item["id"], "result": res})

                if not res.get("success"):
                    add_log(f"Instagram Lote [{idx}/{total}]: Falha ao agendar: {res.get('error')}", "WARNING", "instagram")
                    if "restricted" in str(res.get("error", "")).lower():
                        break

                pct_done = round(base_pct + (0.7 * slice_pct))
                await _notify(
                    idx, total, pct_done,
                    f"Vídeo {idx}/{total} programado com sucesso na Meta!"
                )

                # ========================================================
                # INTERVALO HUMANO APÓS A POSTAGEM (Ordem Exata Solicitada):
                # 1. Entra no perfil (conferência da grade)
                # 2. Rola o feed principal
                # 3. Entra no Reels e assiste alguns reels com áudio mutado
                # E depois retorna para a Central e agenda mais um vídeo
                # ========================================================
                if idx < total:
                    # 1. Perfil
                    pct_prof = round(base_pct + (0.80 * slice_pct))
                    await _notify(
                        idx, total, pct_prof,
                        f"Intervalo humano ({idx}/{total}): acessando perfil e conferindo grade..."
                    )
                    add_log(f"Instagram Lote [{idx}/{total}]: Intervalo humano - acessando perfil...", "INFO", "instagram")
                    try:
                        await execute_cooldown_profile_grid(page, account_name)
                    except Exception as e_prof:
                        add_log(f"Instagram Lote: Aviso ao visitar perfil ({str(e_prof)}), prosseguindo...", "WARNING", "instagram")

                    # 2. Feed
                    pct_feed = round(base_pct + (0.90 * slice_pct))
                    await _notify(
                        idx, total, pct_feed,
                        f"Intervalo humano ({idx}/{total}): navegando no feed principal..."
                    )
                    add_log(f"Instagram Lote [{idx}/{total}]: Intervalo humano - navegando no feed...", "INFO", "instagram")
                    try:
                        await execute_cooldown_feed_relaxation(page, account_name)
                    except Exception as e_feed:
                        add_log(f"Instagram Lote: Aviso ao rolar feed ({str(e_feed)}), prosseguindo...", "WARNING", "instagram")

                    # 3. Reels
                    pct_reels = round(base_pct + (0.98 * slice_pct))
                    await _notify(
                        idx, total, pct_reels,
                        f"Intervalo humano ({idx}/{total}): assistindo Reels com áudio mutado..."
                    )
                    add_log(f"Instagram Lote [{idx}/{total}]: Intervalo humano - assistindo Reels...", "INFO", "instagram")
                    try:
                        await execute_cooldown_reels_afterparty(page, account_name)
                    except Exception as e_reels:
                        add_log(f"Instagram Lote: Aviso ao assistir Reels ({str(e_reels)}), prosseguindo...", "WARNING", "instagram")

                    add_log(f"Instagram Lote [{idx}/{total}]: Intervalo humano 100% concluído! Retornando ao agendador...", "SUCCESS", "instagram")

            await _notify(total, total, 100, f"Lote concluído na Meta ({total} vídeos)!")
            await HumanController.sleep(1.5, 2.5)
            try:
                await asyncio.wait_for(context.close(), timeout=5.0)
            except Exception:
                pass
            return {"success": True, "results": results}

        except Exception as e:
            add_log(f"Erro no processamento em lote do Instagram: {str(e)}", "ERROR", "instagram")
            try:
                await asyncio.wait_for(context.close(), timeout=5.0)
            except Exception:
                pass
            return {"success": False, "error": str(e), "results": results}

async def post_instagram_reel(
    profile_dir: str, 
    video_path: str, 
    caption: str, 
    hashtags: str = "", 
    headless: bool = False,
    account_name: str = ""
) -> Dict[str, Any]:
    """
    Publica um Reel no Instagram usando Playwright com perfil persistente e motor de comportamento humano.
    Suporta os dois layouts do Instagram:
      - Versão nova: Barra lateral com 'Criar novo' -> link 'Postar'
      - Versão clássica: Botão (+) 'Criar' / 'Nova publicação'
    Executa cliques 100% confiáveis (isTrusted = True) com movimentos Bézier e cadência humana autêntica.
    Ajusta a proporção para 'Original' (9:16 vertical), seleciona o melhor frame de capa,
    insere a legenda e aguarda pacientemente a confirmação real da rede sem fechamento prematuro.
    Após a publicação, executa navegação orgânica (assiste 3 a 5 posts por 12-15s), retorna ao perfil
    para atualizar a grade do feed e finaliza suavemente de forma silenciosa (--mute-audio).
    """
    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo de vídeo não encontrado: {video_path}"}

    clean_caption = format_caption_paragraphs(caption)
    clean_hashtags = hashtags.strip() if hashtags else ""
    if clean_hashtags:
        full_caption = f"{clean_caption}\n\n{clean_hashtags}" if clean_caption else clean_hashtags
    else:
        full_caption = clean_caption

    mode_label = "oculto (background, silencioso)" if headless else "visível na tela"
    add_log(f"Iniciando postagem no Instagram ({mode_label}): {os.path.basename(video_path)}", "INFO", "instagram")

    async with async_playwright() as p:
        # Silencia áudio mesmo em modo visível para não atrapalhar o usuário com reprodução de reels
        args = BrowserManager.get_context_args(profile_dir, headless=headless, mute_audio=True)
        context = await p.chromium.launch_persistent_context(**args)
        
        # Injeta cookies exportados caso existam
        json_cookies_path = os.path.join(profile_dir, "cookies.json")
        if os.path.exists(json_cookies_path):
            try:
                import json
                with open(json_cookies_path, "r", encoding="utf-8") as f:
                    c_data = json.load(f)
                await context.add_cookies(c_data)
            except Exception:
                pass

        page = context.pages[0] if context.pages else await context.new_page()

        if not headless:
            try:
                await page.bring_to_front()
                BrowserManager.bring_window_to_front("instagram")
            except Exception:
                pass

        try:
            # Script anti-detecção stealth avançado (mantido limpo sem poluição de protótipos)
            if STEALTH_INIT_SCRIPT:
                await page.add_init_script(STEALTH_INIT_SCRIPT)
            if headless:
                await page.add_init_script("window.__mute_audio_force = true;")

            await page.goto("https://www.instagram.com/", wait_until="networkidle", timeout=60000)
            await HumanController.sleep(2.5, 4.0)

            # Verificação prévia: Se a conta estiver em checkpoint/desafio humano
            page_url = page.url
            if "/challenge/" in page_url:
                err_msg = "Instagram exibiu tela de verificação humana (checkpoint de segurança). Abra a conta manualmente para liberar o acesso."
                add_log(f"Instagram: {err_msg}", "ERROR", "instagram")
                await context.close()
                return {"success": False, "error": err_msg}

            # Fecha eventuais diálogos de notificação / cookies
            for btn_text in ["Agora não", "Not Now", "Recusar", "Decline"]:
                try:
                    btn = page.locator(f"button:has-text('{btn_text}')")
                    if await btn.count() > 0 and await btn.first.is_visible():
                        await HumanController.click(page, btn.first, hover_time=0.3)
                        await HumanController.sleep(0.8, 1.4)
                except Exception:
                    pass

            # Procura o botão de criação compatível com as duas versões do Instagram:
            # 1. Nova versão: Seção "Criar novo" -> Link "Postar" (a:has-text('Postar'))
            # 2. Versão clássica: Botão (+) "Criar" / "Nova publicação" (svg, span, a)
            create_selectors = [
                # Nova versão (sidebar "Criar novo" -> "Postar")
                "a:has-text('Postar')",
                "div[role='button']:has-text('Postar')",
                "span:text-is('Postar')",
                "svg[aria-label*='Postar' i]",
                # Versão clássica ("Criar" / "Nova publicação")
                "svg[aria-label*='Nova publicação' i]",
                "svg[aria-label*='Criar' i]",
                "a:has-text('Criar')",
                "div[role='button']:has-text('Criar')",
                "span:text-is('Criar')",
                # Fallbacks em inglês
                "svg[aria-label*='New post' i]",
                "svg[aria-label*='Create' i]",
                "a:has-text('Create')",
                "div[role='button']:has-text('Create')"
            ]
            create_query = ", ".join(create_selectors)
            create_btn = page.locator(create_query).first

            if await create_btn.count() == 0:
                # Checa se foi para checkpoint de segurança antes de dizer não autenticado
                body_text = await page.evaluate("() => document.body.innerText || ''")
                b_low = body_text.lower()
                if "confirme que você é humano" in b_low or "ajude-nos a confirmar" in b_low or "confirm you're human" in b_low or "/challenge/" in page.url:
                    err_msg = "Instagram solicitou verificação de humano/segurança. Necessário acesso manual prévio no navegador para resolver o desafio."
                    add_log(f"Instagram: {err_msg}", "ERROR", "instagram")
                    await context.close()
                    return {"success": False, "error": err_msg}

                add_log("Instagram: Sessão não encontrada ou botão Criar/Postar indisponível. Login necessário.", "ERROR", "instagram")
                await context.close()
                return {"success": False, "error": "Sessão não autenticada no Instagram. Faça login primeiro."}

            # ========================================================
            # ETAPA 0: Motor de Entropia Comportamental (Pré-Aquecimento Não-Repetitivo)
            # Sorteia um padrão comportamental EXCLUSIVO para esta postagem,
            # garantindo que NUNCA repita a ação da postagem anterior da conta.
            # ========================================================
            clean_acc = account_name.replace("@", "").strip() if account_name else ""
            sel_warmup, sel_cooldown, beh_history = select_unique_archetypes(profile_dir)
            w_code, w_desc, w_short = sel_warmup
            c_code, c_desc, c_short = sel_cooldown

            last_w = beh_history.get("last_warmup") or "Nenhum (1º disparo)"
            last_c = beh_history.get("last_cooldown") or "Nenhum (1º disparo)"
            add_log(f"Instagram: 🎲 Motor de Entropia Ativado para @{clean_acc or 'Conta'}", "INFO", "instagram")
            add_log(f"Instagram: ↳ Histórico anterior: [Pré: {last_w}] | [Pós: {last_c}]", "INFO", "instagram")
            add_log(f"Instagram: ↳ Novo padrão sorteado (DIFERENTE DO ANTERIOR):", "INFO", "instagram")
            add_log(f"Instagram:   • PRÉ: {w_desc}", "INFO", "instagram")
            add_log(f"Instagram:   • PÓS: {c_desc}", "INFO", "instagram")

            warmup_start = asyncio.get_event_loop().time()
            target_warmup_sec = random.uniform(52.0, 68.0) # ~1 minuto

            if w_code == "feed_curator":
                _, w_summary = await execute_warmup_feed_curator(page, target_warmup_sec)
            elif w_code == "social_engager":
                _, w_summary = await execute_warmup_social_engager(page, target_warmup_sec)
            elif w_code == "explore_wanderer":
                _, w_summary = await execute_warmup_explore_wanderer(page, target_warmup_sec)
            elif w_code == "reels_viewer":
                _, w_summary = await execute_warmup_reels_viewer(page, target_warmup_sec)
            else:
                _, w_summary = await execute_warmup_feed_curator(page, target_warmup_sec)

            warmup_elapsed = int(asyncio.get_event_loop().time() - warmup_start)
            add_log(f"Instagram: Pré-aquecimento concluído ({warmup_elapsed}s) [{w_summary}]! Abrindo menu de publicação...", "SUCCESS", "instagram")
            await HumanController.sleep(1.5, 2.5)

            # Re-localiza o botão de publicação na barra lateral e clica suavemente
            create_btn = page.locator(create_query).first
            add_log("Instagram: Botão de publicação (Criar/Postar) localizado.", "INFO", "instagram")
            await HumanController.click(page, create_btn, hover_time=0.4)
            await HumanController.sleep(1.8, 2.8)

            # Upload do arquivo de vídeo no input file
            file_input = page.locator("input[type='file']")
            await file_input.wait_for(state="attached", timeout=15000)
            await file_input.set_input_files(os.path.abspath(video_path))
            add_log("Instagram: Arquivo carregado, aguardando processamento...", "INFO", "instagram")
            await HumanController.sleep(3.5, 5.5)

            # Caso apareça popup "Os vídeos agora são compartilhados como reels"
            ok_modal = page.locator("div[role='dialog'] button:has-text('OK'), div[role='dialog'] button:has-text('Entendi')")
            if await ok_modal.count() > 0 and await ok_modal.first.is_visible():
                await HumanController.click(page, ok_modal.first, hover_time=0.3)
                await HumanController.sleep(1.0, 1.8)

            # ========================================================
            # ETAPA 1: Selecionar o corte 'Original' (proporção 9:16)
            # Regra de Ouro: Sempre 'Original'. Ignorar estritamente 1:1, 9:16, 16:9.
            # NUNCA re-clicar no botão de corte após selecionar Original para não ciclar de volta para 1:1.
            # ========================================================
            try:
                add_log("Instagram: Localizando botão 'Selecionar corte'...", "INFO", "instagram")
                corte_svg = page.locator("svg[aria-label*='corte' i], svg[aria-label*='crop' i]").first
                
                if await corte_svg.count() > 0 and await corte_svg.is_visible():
                    await HumanController.click(page, corte_svg, hover_time=0.3)
                    add_log("Instagram: Menu de proporção aberto via ícone SVG.", "INFO", "instagram")
                    await HumanController.sleep(0.8, 1.4)

                    orig_btn = page.locator("div[role='button']:has-text('Original'), span:text-is('Original')").first
                    if await orig_btn.count() > 0 and await orig_btn.is_visible():
                        await HumanController.click(page, orig_btn, hover_time=0.3)
                        add_log("Instagram: Proporção 'Original' (9:16 vertical) aplicada com sucesso! (1:1, 9:16 e 16:9 ignorados)", "SUCCESS", "instagram")
                        await HumanController.sleep(1.0, 1.8)
                    else:
                        add_log("Instagram: Opção 'Original' não encontrada no menu aberto.", "WARNING", "instagram")
                    await HumanController.sleep(0.5, 1.0)
                else:
                    add_log("Instagram: Ícone de corte não exibido no momento.", "WARNING", "instagram")
            except Exception as e:
                add_log(f"Instagram: Erro ao ajustar corte original: {str(e)}", "WARNING", "instagram")

            # ========================================================
            # ETAPA 2: Avançar para tela de Edição (Capa e Filtros) com Confirmação Real de Estado
            # ========================================================
            step2_ready = False
            for attempt_adv in range(3):
                next_btn = page.locator("div[role='dialog'] div[role='button']:has-text('Avançar'), div[role='dialog'] button:has-text('Avançar'), div[role='dialog'] div[role='button']:has-text('Next'), div[role='dialog'] button:has-text('Next')").first
                if await next_btn.count() > 0 and await next_btn.is_visible():
                    await HumanController.click(page, next_btn, hover_time=0.4)
                    add_log(f"Instagram: Avançar (etapa 1 - Corte) clicado (tentativa {attempt_adv + 1}).", "INFO", "instagram")
                else:
                    alt_next = page.locator("div[role='button']:has-text('Avançar'), button:has-text('Avançar')").first
                    if await alt_next.count() > 0 and await alt_next.is_visible():
                        await HumanController.click(page, alt_next, hover_time=0.4)
                        add_log(f"Instagram: Avançar (etapa 1 - Corte) clicado via fallback (tentativa {attempt_adv + 1}).", "INFO", "instagram")

                # Aguarda até 8 segundos pela transição real para a etapa de Capa/Edição
                for _ in range(8):
                    await asyncio.sleep(1.0)
                    is_cover_screen = await page.evaluate("""() => {
                        const dialog = document.querySelector("div[role='dialog']") || document.body;
                        const text = (dialog.innerText || '').toLowerCase();
                        const hasCoverText = text.includes('foto da capa') || text.includes('cover photo') || text.includes('editar');
                        const hasSlider = !!dialog.querySelector("div[role='slider']");
                        return hasCoverText || hasSlider;
                    }""")
                    if is_cover_screen:
                        step2_ready = True
                        break
                if step2_ready:
                    break

            await HumanController.sleep(1.5, 2.5)

            # ========================================================
            # ETAPA 2.1: Seleção Inteligente do Melhor Frame para Capa (Anti-duplicidade)
            # ========================================================
            add_log("Instagram: Analisando frames para escolha da melhor capa do vídeo...", "INFO", "instagram")
            try:
                cover_selection = await page.evaluate("""async () => {
                    const dialog = document.querySelector("div[role='dialog']") || document.body;
                    
                    // Localiza o texto Foto da capa ou Cover photo
                    const elCover = Array.from(dialog.querySelectorAll('*')).find(el => {
                        const t = (el.innerText || '').trim();
                        return t === 'Foto da capa' || t === 'Cover photo';
                    });
                    if (!elCover) return { success: false, error: "Seção 'Foto da capa' não encontrada" };

                    // Encontra o handle de slider
                    const slider = dialog.querySelector("div[role='slider']");
                    const sRect = slider ? slider.getBoundingClientRect() : null;

                    // Encontra as miniaturas candidatas geradas pelo Instagram (DIVs com blob bg)
                    const allDivs = Array.from(dialog.querySelectorAll('div'));
                    const frameDivs = allDivs.filter(d => {
                        const bg = window.getComputedStyle(d).backgroundImage || '';
                        const r = d.getBoundingClientRect();
                        return bg.includes('blob:') && r.height > 60 && r.height < 150 && r.y < 350;
                    });

                    if (frameDivs.length === 0) {
                        return { success: false, error: "Nenhum frame candidato encontrado" };
                    }

                    // Análise de contraste, energia de borda, saturação e relevância visual
                    const scores = [];
                    for (let i = 0; i < frameDivs.length; i++) {
                        const div = frameDivs[i];
                        const bg = window.getComputedStyle(div).backgroundImage || '';
                        const match = bg.match(/url\\(["']?(blob:[^"']+)["']?\\)/);
                        if (!match) continue;
                        const blobUrl = match[1];

                        try {
                            const img = new Image();
                            img.crossOrigin = "anonymous";
                            await new Promise((res, rej) => {
                                img.onload = res;
                                img.onerror = rej;
                                img.src = blobUrl;
                                setTimeout(() => rej(new Error("Timeout cover blob")), 1500);
                            });

                            const canvas = document.createElement('canvas');
                            canvas.width = 64;
                            canvas.height = 64;
                            const ctx = canvas.getContext('2d');
                            ctx.drawImage(img, 0, 0, 64, 64);
                            const data = ctx.getImageData(0, 0, 64, 64).data;

                            let sumLum = 0;
                            let lumValues = [];
                            let satSum = 0;

                            for (let p = 0; p < data.length; p += 4) {
                                const r = data[p];
                                const g = data[p+1];
                                const b = data[p+2];
                                const lum = 0.299 * r + 0.587 * g + 0.114 * b;
                                sumLum += lum;
                                lumValues.push(lum);

                                const max = Math.max(r, g, b);
                                const min = Math.min(r, g, b);
                                const sat = max === 0 ? 0 : (max - min) / max;
                                satSum += sat;
                            }

                            const meanLum = sumLum / lumValues.length;
                            let variance = 0;
                            for (let val of lumValues) {
                                variance += Math.pow(val - meanLum, 2);
                            }
                            const stdDev = Math.sqrt(variance / lumValues.length);
                            const meanSat = satSum / lumValues.length;

                            // Energia de borda (riqueza de detalhes, objetos e movimento)
                            let edgeEnergy = 0;
                            for (let y = 0; y < 63; y++) {
                                for (let x = 0; x < 63; x++) {
                                    const idx1 = (y * 64 + x) * 4;
                                    const idx2 = (y * 64 + (x + 1)) * 4;
                                    const idx3 = ((y + 1) * 64 + x) * 4;
                                    edgeEnergy += Math.abs(data[idx1] - data[idx2]) + Math.abs(data[idx1] - data[idx3]);
                                }
                            }
                            edgeEnergy = edgeEnergy / (63 * 63);

                            // Bônus de posição: evita frame 0 e favorece o clímax central (20% a 70%)
                            const isCenter = (i === Math.floor(frameDivs.length / 2));
                            const posBonus = (i === 0) ? -25 : (isCenter ? 15 : 5);

                            const finalScore = (stdDev * 0.4) + (edgeEnergy * 0.4) + (meanSat * 30) + posBonus;

                            scores.push({
                                index: i,
                                score: finalScore,
                                rect: frameDivs[i].getBoundingClientRect()
                            });
                        } catch (e) {
                            scores.push({ index: i, score: 0, rect: frameDivs[i].getBoundingClientRect() });
                        }
                    }

                    scores.sort((a, b) => b.score - a.score);
                    const best = scores[0];

                    return {
                        success: true,
                        totalFrames: frameDivs.length,
                        bestIndex: best.index,
                        bestScore: best.score,
                        targetRect: {
                            x: best.rect.x,
                            y: best.rect.y,
                            w: best.rect.width,
                            h: best.rect.height
                        },
                        sliderRect: sRect ? {
                            x: sRect.x,
                            y: sRect.y,
                            w: sRect.width,
                            h: sRect.height
                        } : null
                    };
                }""")

                if cover_selection and cover_selection.get("success"):
                    t_rect = cover_selection["targetRect"]
                    s_rect = cover_selection.get("sliderRect")
                    target_x = t_rect["x"] + t_rect["w"] / 2
                    target_y = t_rect["y"] + t_rect["h"] / 2

                    if s_rect:
                        start_x = s_rect["x"] + s_rect["w"] / 2
                        start_y = s_rect["y"] + s_rect["h"] / 2

                        # Arrasta o slider suavemente com física e jitter humano
                        await HumanController.drag(page, start_x, start_y, target_x, target_y)
                    else:
                        await HumanController.move_mouse(page, target_x, target_y)
                        await page.mouse.click(target_x, target_y)

                    best_idx = cover_selection.get("bestIndex", 0) + 1
                    total = cover_selection.get("totalFrames", 5)
                    add_log(f"Instagram: Capa alterada com sucesso! Frame {best_idx}/{total} selecionado (alta retenção/anti-duplicidade).", "SUCCESS", "instagram")
                    await HumanController.sleep(1.8, 2.8)
                else:
                    err = cover_selection.get("error", "Não detectado") if cover_selection else "Resposta nula"
                    add_log(f"Instagram: Não foi possível alternar a capa ({err}), mantendo frame padrão.", "WARNING", "instagram")
            except Exception as e_cover:
                add_log(f"Instagram: Erro ao selecionar frame de capa: {str(e_cover)}", "WARNING", "instagram")

            # ========================================================
            # ETAPA 2.2: Avançar para tela de Legenda e Compartilhar com Confirmação Real
            # ========================================================
            step3_ready = False
            for attempt_adv2 in range(3):
                next_btn2 = page.locator("div[role='dialog'] div[role='button']:has-text('Avançar'), div[role='dialog'] button:has-text('Avançar'), div[role='dialog'] div[role='button']:has-text('Next'), div[role='dialog'] button:has-text('Next')").first
                if await next_btn2.count() > 0 and await next_btn2.is_visible():
                    await HumanController.click(page, next_btn2, hover_time=0.4)
                    add_log(f"Instagram: Avançar (etapa 2 - Legenda) clicado (tentativa {attempt_adv2 + 1}).", "INFO", "instagram")
                else:
                    alt_next2 = page.locator("div[role='button']:has-text('Avançar'), button:has-text('Avançar')").first
                    if await alt_next2.count() > 0 and await alt_next2.is_visible():
                        await HumanController.click(page, alt_next2, hover_time=0.4)
                        add_log(f"Instagram: Avançar (etapa 2 - Legenda) clicado via fallback (tentativa {attempt_adv2 + 1}).", "INFO", "instagram")

                # Aguarda até 8 segundos pela transição real para a etapa de Legenda / Compartilhar
                for _ in range(8):
                    await asyncio.sleep(1.0)
                    caption_exists = await page.evaluate("""() => {
                        const dialog = document.querySelector("div[role='dialog']") || document.body;
                        const hasCaption = !!dialog.querySelector("div[contenteditable='true'], div[aria-label*='legenda' i], div[aria-label*='caption' i]");
                        const hasShare = Array.from(dialog.querySelectorAll("div[role='button'], button")).some(b => {
                            const t = (b.innerText || '').trim();
                            return t === 'Compartilhar' || t === 'Share';
                        });
                        return hasCaption || hasShare;
                    }""")
                    if caption_exists:
                        step3_ready = True
                        break
                if step3_ready:
                    break

            await HumanController.sleep(1.5, 2.5)

            # ========================================================
            # ETAPA 3: Legenda e Fechamento de Autocomplete (Instantâneo via Copiar e Colar)
            # ========================================================
            add_log("Instagram: Colando legenda com parágrafos separados...", "INFO", "instagram")
            caption_area = page.locator("div[role='dialog'] div[aria-label*='legenda' i], div[role='dialog'] div[aria-label*='caption' i], div[role='dialog'] div[contenteditable='true']").first

            if await caption_area.count() > 0:
                await HumanController.click(page, caption_area, hover_time=0.3)
                await HumanController.sleep(0.8, 1.4)

                # Copia para a área de transferência e cola via Ctrl+V instantaneamente
                try:
                    await page.evaluate("""async (text) => {
                        await navigator.clipboard.writeText(text);
                    }""", full_caption)
                    await page.keyboard.press("Control+V")
                    add_log("Instagram: Legenda colada com sucesso em menos de 1 segundo!", "SUCCESS", "instagram")
                except Exception as e_paste:
                    add_log(f"Instagram: Fallback ao colar legenda ({str(e_paste)}), inserindo via script...", "WARNING", "instagram")
                    await page.evaluate("""(text) => {
                        const el = document.activeElement;
                        if (el) {
                            document.execCommand('insertText', false, text);
                        }
                    }""", full_caption)

                # Pausa natural simulando conferência da legenda pelo usuário
                await HumanController.sleep(1.5, 2.5)

                # Fecha o popover de menção (@) e hashtag (#)
                await page.keyboard.press("Escape")
                await HumanController.sleep(0.4, 0.8)
                await page.keyboard.press("Escape")
                await HumanController.sleep(0.4, 0.8)

                # Desfoca o campo de texto
                await page.evaluate("""() => {
                    if (document.activeElement && document.activeElement.blur) {
                        document.activeElement.blur();
                    }
                }""")
                await HumanController.sleep(0.8, 1.4)

                try:
                    neutral_header = page.locator("div[role='dialog'] h1, div[role='dialog'] span:has-text('Novo reel'), div[role='dialog'] div:has-text('Novo reel')").first
                    if await neutral_header.count() > 0:
                        await HumanController.click(page, neutral_header, hover_time=0.2)
                        await HumanController.sleep(0.5, 1.0)
                except Exception:
                    pass
            else:
                add_log("Instagram: Campo de legenda não encontrado, tentando prosseguir...", "WARNING", "instagram")

            # ========================================================
            # ETAPA 4: Clicar no Compartilhar do Cabeçalho do Modal
            # ========================================================
            # CRÍTICO: Não utilizar target.click() via page.evaluate() pois gera isTrusted = false.
            # O clique DEVE ser realizado com coordenadas e eventos de mouse reais do Playwright / HumanController.
            add_log("Instagram: Localizando botão 'Compartilhar' do cabeçalho...", "INFO", "instagram")
            
            # Pausa natural antes de compartilhar (revisão final humana)
            await HumanController.sleep(2.0, 3.5)

            share_btn = page.locator(
                "div[role='dialog'] div[role='button']:has-text('Compartilhar'), "
                "div[role='dialog'] button:has-text('Compartilhar'), "
                "div[role='dialog'] div[role='button']:has-text('Share'), "
                "div[role='dialog'] button:has-text('Share'), "
                "div._ac7b div[role='button']:has-text('Compartilhar')"
            ).last

            clicked_share = False
            if await share_btn.count() > 0 and await share_btn.is_visible():
                await HumanController.click(page, share_btn, hover_time=random.uniform(0.5, 0.9))
                clicked_share = True
                add_log("Instagram: Botão 'Compartilhar' clicado via evento humano autêntico (isTrusted = True)!", "INFO", "instagram")
            else:
                # Fallback: obtém coordenadas do botão no cabeçalho e clica via ponteiro real
                coords = await page.evaluate("""() => {
                    const btns = Array.from(document.querySelectorAll("div[role='dialog'] div[role='button'], div[role='dialog'] button, div._ac7b div[role='button']"));
                    const target = btns.find(b => {
                        const text = (b.innerText || '').trim();
                        const rect = b.getBoundingClientRect();
                        const hasSvg = b.querySelector('svg') !== null;
                        return (text === 'Compartilhar' || text === 'Share') && !hasSvg && rect.y < 250 && rect.width > 30;
                    });
                    if (target) {
                        const r = target.getBoundingClientRect();
                        return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
                    }
                    return null;
                }""")
                if coords:
                    await HumanController.move_mouse(page, coords["x"], coords["y"])
                    await asyncio.sleep(random.uniform(0.3, 0.6))
                    await page.mouse.down()
                    await asyncio.sleep(random.uniform(0.08, 0.15))
                    await page.mouse.up()
                    clicked_share = True
                    add_log("Instagram: Botão 'Compartilhar' acionado via coordenadas de ponteiro real!", "INFO", "instagram")

            if not clicked_share:
                await context.close()
                return {"success": False, "error": "Botão Compartilhar do modal não encontrado."}

            # ========================================================
            # ETAPA 5: Aguardar upload e confirmação REAL da rede
            # ========================================================
            confirmado = False
            add_log("Instagram: Vídeo sendo enviado e processado pela rede...", "INFO", "instagram")

            # Monitora pacientemente por até 180 segundos (90 iterações de 2s)
            for second in range(90):
                await asyncio.sleep(2)
                try:
                    res = await page.evaluate("""() => {
                        const dialog = document.querySelector("div[role='dialog']");
                        const bodyText = document.body.innerText || '';

                        let isSharing = false;
                        let hasSharedSuccess = false;
                        let isRestricted = false;
                        let hasChallenge = window.location.href.includes('/challenge/');

                        if (dialog) {
                            const dText = dialog.innerText || '';
                            // Modal de 'Compartilhando' ativo com o spinner colorido
                            isSharing = dText.includes('Compartilhando') || dText.includes('Sharing');

                            // Sucesso explícito dentro do modal
                            hasSharedSuccess = dText.includes('Seu reel foi compartilhado') || 
                                               dText.includes('Sua publicação foi compartilhada') || 
                                               dText.includes('Your reel has been shared') ||
                                               dText.includes('Your post has been shared');

                            // Restrição só é válida se NÃO estiver no estado ativo de Compartilhando
                            if (!isSharing) {
                                isRestricted = dText.includes('User restricted from uploading') ||
                                               (dText.includes('Não foi possível compartilhar') && dialog.querySelector("button"));
                                if (dText.includes('confirme que você é humano') || dText.includes('Ajude-nos a confirmar')) {
                                    hasChallenge = true;
                                }
                            }
                        } else {
                            // Se o diálogo de upload fechou completamente e sumiu da tela
                            hasSharedSuccess = bodyText.includes('Seu reel foi compartilhado') || 
                                               bodyText.includes('Sua publicação foi compartilhada') || 
                                               bodyText.includes('Your reel has been shared') ||
                                               bodyText.includes('Your post has been shared');
                        }

                        return { 
                            dialogOpen: !!dialog, 
                            isSharing, 
                            hasSharedSuccess, 
                            isRestricted, 
                            hasChallenge 
                        };
                    }""")

                    # Se o modal de upload estiver ativamente em "Compartilhando", AGUARDA sem fechar
                    if res.get("isSharing"):
                        if second % 5 == 0 and second > 0:
                            add_log(f"Instagram: Envio em andamento ({second * 2}s)... Vídeo sendo processado na nuvem da Meta.", "INFO", "instagram")
                        continue

                    # Se a Meta exibir modal de erro com restrição temporária real
                    if res.get("isRestricted"):
                        err_msg = "Instagram bloqueou temporariamente o upload desta conta ('User restricted from uploading, please try later'). Trata-se de um bloqueio temporário da Meta. Aguarde o prazo expirar ou confirme manualmente no navegador."
                        add_log(f"Instagram: {err_msg}", "ERROR", "instagram")
                        await context.close()
                        return {"success": False, "error": err_msg}

                    # Se for redirecionado para checkpoint de verificação humana
                    if res.get("hasChallenge"):
                        err_msg = "Instagram solicitou verificação humana ('Confirme que você é humano'). Acesse a conta manualmente no navegador para resolver o desafio."
                        add_log(f"Instagram: {err_msg}", "ERROR", "instagram")
                        await context.close()
                        return {"success": False, "error": err_msg}

                    # Se a confirmação explícita de sucesso aparecer
                    if res.get("hasSharedSuccess"):
                        confirmado = True
                        add_log("Instagram: Confirmação recebida: 'Seu reel foi compartilhado'!", "SUCCESS", "instagram")
                        break

                    # Se o modal de compartilhamento sumiu da tela sem erros (upload concluído)
                    if not res.get("dialogOpen") and second >= 4:
                        confirmado = True
                        add_log("Instagram: Modal de envio concluído e encerrado pela rede!", "SUCCESS", "instagram")
                        break
                except Exception:
                    pass

            if not confirmado:
                add_log("Instagram: Tempo de envio esgotado ou resposta pendente na rede.", "WARNING", "instagram")
                await HumanController.sleep(3.0, 5.0)
                await context.close()
                return {"success": False, "error": "Tempo limite de upload esgotado."}

            # ========================================================
            # ETAPA 6: Pós-Postagem Orgânica (Esfriamento Não-Repetitivo)
            # Executa a pós-ação sorteada pelo Motor de Entropia para este post
            # ========================================================
            # 1. Fecha o diálogo de sucesso se ainda estiver aberto na tela
            try:
                close_btn = page.locator("div[role='dialog'] svg[aria-label='Fechar'], div[role='dialog'] button:has-text('Fechar'), div[role='dialog'] svg[aria-label='Close'], div[role='dialog'] button:has-text('OK')").first
                if await close_btn.count() > 0 and await close_btn.is_visible():
                    await HumanController.click(page, close_btn, hover_time=0.3)
                    await HumanController.sleep(1.0, 1.8)
                else:
                    await page.keyboard.press("Escape")
                    await HumanController.sleep(0.8, 1.4)
            except Exception:
                pass

            add_log(f"Instagram: Reel publicado! Iniciando {c_desc}...", "INFO", "instagram")
            cooldown_start = asyncio.get_event_loop().time()

            if c_code == "profile_grid_refresh":
                post_url = await execute_cooldown_profile_grid(page, clean_acc)
            elif c_code == "feed_relaxation":
                post_url = await execute_cooldown_feed_relaxation(page, clean_acc)
            elif c_code == "reels_afterparty":
                post_url = await execute_cooldown_reels_afterparty(page, clean_acc)
            elif c_code == "explore_scan":
                post_url = await execute_cooldown_explore_scan(page, clean_acc)
            else:
                post_url = await execute_cooldown_profile_grid(page, clean_acc)

            cooldown_elapsed = int(asyncio.get_event_loop().time() - cooldown_start)
            add_log(f"Instagram: Esfriamento orgânico concluído ({cooldown_elapsed}s)! Reel confirmado na grade: {post_url}", "SUCCESS", "instagram")

            # Salva o histórico desta conta para que a próxima postagem NUNCA repita o padrão
            beh_history["last_warmup"] = w_code
            beh_history["last_cooldown"] = c_code
            beh_history["total_runs"] = beh_history.get("total_runs", 0) + 1
            save_account_behavior_history(profile_dir, beh_history)

            status_detail = f"Publicado | Pré: {w_short} (~{warmup_elapsed}s) | Pós: {c_short} (~{cooldown_elapsed}s)"
            add_log(f"Instagram: Post finalizado com sucesso! Detalhe registrado: {status_detail}", "SUCCESS", "instagram")

            await HumanController.sleep(2.0, 3.5)
            await context.close()
            return {"success": True, "detail": status_detail, "url": post_url}

        except Exception as e:
            add_log(f"Erro na postagem do Instagram: {str(e)}", "ERROR", "instagram")
            await context.close()
            return {"success": False, "error": str(e)}
