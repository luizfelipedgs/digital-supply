import os
import json
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List

from backend.database import get_setting, set_setting, add_log

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILES_DIR = os.path.join(BASE_DIR, "storage", "profiles")
os.makedirs(PROFILES_DIR, exist_ok=True)

SUPABASE_URL = os.environ.get("NEXT_PUBLIC_SUPABASE_URL", "https://oipbnfcahgmqiwpqhnvt.supabase.co").rstrip("/")
SUPABASE_ANON_KEY = os.environ.get(
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pcGJuZmNhaGdtcWl3cHFobnZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NjcxODMsImV4cCI6MjEwMzU0MzE4M30.bU2yDCbWICGcoxDucNOzjBi8H1iOUNPdCxeD-5BEWQs"
)

def _http_request(url: str, method: str = "GET", headers: Optional[Dict[str, str]] = None, data: Optional[Dict[str, Any]] = None, raw_body: Optional[bytes] = None, content_type: str = "application/json") -> Any:
    req_headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": content_type
    }
    if headers:
        req_headers.update(headers)

    if raw_body is not None:
        body = raw_body
    elif data is not None:
        body = json.dumps(data).encode("utf-8")
    else:
        body = None

    req = urllib.request.Request(url, data=body, headers=req_headers, method=method)

    try:
        with urllib.request.urlopen(req, timeout=12.0) as resp:
            content = resp.read().decode("utf-8")
            return json.loads(content) if content else {}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="ignore")
        try:
            err_json = json.loads(error_body)
            err_msg = err_json.get("error_description") or err_json.get("message") or err_json.get("msg") or error_body
        except Exception:
            err_msg = error_body
        raise Exception(f"HTTP {e.code}: {err_msg}")
    except Exception as e:
        raise Exception(f"Falha na conexão com Supabase: {str(e)}")

def refresh_session_tokens() -> str:
    """Renova o token JWT do Supabase usando o refresh_token salvo."""
    rf = get_setting("auth_refresh_token", "")
    if not rf:
        raise Exception("Nenhum token de atualização disponível.")

    url = f"{SUPABASE_URL}/auth/v1/token?grant_type=refresh_token"
    req_headers = {"apikey": SUPABASE_ANON_KEY, "Content-Type": "application/json"}
    body = json.dumps({"refresh_token": rf}).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=req_headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10.0) as resp:
            res = json.loads(resp.read().decode("utf-8"))
            new_token = res.get("access_token")
            new_rf = res.get("refresh_token")
            if new_token:
                set_setting("auth_access_token", new_token)
            if new_rf:
                set_setting("auth_refresh_token", new_rf)
            return new_token
    except Exception as e:
        add_log(f"Falha ao renovar token com Supabase: {str(e)}", "WARNING")
        raise

def login(email: str, password: str) -> Dict[str, Any]:
    """
    Autentica o aluno ou admin via Supabase Auth e valida os dados de perfil e assinatura.
    """
    auth_url = f"{SUPABASE_URL}/auth/v1/token?grant_type=password"
    auth_resp = _http_request(auth_url, method="POST", data={"email": email.strip(), "password": password})

    access_token = auth_resp.get("access_token")
    refresh_token = auth_resp.get("refresh_token")
    user = auth_resp.get("user", {})
    user_id = user.get("id")

    if not access_token or not user_id:
        raise Exception("Token de autenticação não retornado pelo Supabase.")

    # Busca o perfil na tabela profiles
    profile_url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}&select=*"
    profile_headers = {"Authorization": f"Bearer {access_token}"}
    profiles = _http_request(profile_url, method="GET", headers=profile_headers)

    profile = profiles[0] if isinstance(profiles, list) and len(profiles) > 0 else {}
    is_admin = bool(profile.get("is_admin", False))
    status = profile.get("status", "pending")
    plan = profile.get("plan", "mensal")
    plan_expires_at = profile.get("plan_expires_at")
    nickname = profile.get("nickname") or email.split("@")[0]
    avatar_path = profile.get("avatar_path")

    # Verifica validade da assinatura
    is_expired = False
    if plan_expires_at:
        try:
            clean_expires = plan_expires_at.replace("Z", "+00:00")
            exp_dt = datetime.fromisoformat(clean_expires)
            is_expired = datetime.now(timezone.utc) > exp_dt
        except Exception:
            pass

    has_access = is_admin or (status == "active" and not is_expired)

    # Persiste a sessão no banco local SQLite
    set_setting("auth_logged_in", "true")
    set_setting("auth_user_id", user_id)
    set_setting("auth_email", email.strip())
    set_setting("auth_nickname", nickname)
    set_setting("auth_status", status)
    set_setting("auth_is_admin", "true" if is_admin else "false")
    set_setting("auth_plan", plan or "")
    set_setting("auth_plan_expires_at", plan_expires_at or "")
    set_setting("auth_avatar_path", avatar_path or "")
    set_setting("auth_access_token", access_token)
    set_setting("auth_refresh_token", refresh_token or "")
    set_setting("auth_last_check", datetime.now().isoformat())

    add_log(f"Login efetuado na Central DGS: {email} (Admin: {is_admin}, Status: {status})", "INFO")

    avatar_url = f"{SUPABASE_URL}/storage/v1/object/public/avatars/{avatar_path}" if avatar_path else ""

    return {
        "success": True,
        "authenticated": True,
        "has_access": has_access,
        "is_admin": is_admin,
        "status": status,
        "is_expired": is_expired,
        "plan": plan,
        "plan_expires_at": plan_expires_at,
        "user": {
            "id": user_id,
            "email": email,
            "nickname": nickname,
            "avatar_path": avatar_path,
            "avatar_url": avatar_url
        }
    }

def logout() -> Dict[str, Any]:
    """Desconecta a conta e limpa as credenciais locais."""
    user_email = get_setting("auth_email", "")
    set_setting("auth_logged_in", "false")
    set_setting("auth_user_id", "")
    set_setting("auth_email", "")
    set_setting("auth_nickname", "")
    set_setting("auth_status", "")
    set_setting("auth_is_admin", "false")
    set_setting("auth_plan", "")
    set_setting("auth_plan_expires_at", "")
    set_setting("auth_avatar_path", "")
    set_setting("auth_access_token", "")
    set_setting("auth_refresh_token", "")
    set_setting("auth_last_check", "")

    add_log(f"Logout efetuado na Central DGS ({user_email})", "INFO")
    return {"success": True, "authenticated": False}

def get_current_session(validate_remote: bool = False) -> Dict[str, Any]:
    """
    Retorna o estado da sessão atual salva localmente.
    Se validate_remote for True, consulta o Supabase para renovar o status.
    """
    is_logged = get_setting("auth_logged_in", "false") == "true"
    if not is_logged:
        return {
            "authenticated": False,
            "has_access": False,
            "is_admin": False,
            "status": "unauthenticated",
            "message": "Nenhum usuário conectado à Central DGS."
        }

    user_id = get_setting("auth_user_id", "")
    email = get_setting("auth_email", "")
    nickname = get_setting("auth_nickname", "")
    status = get_setting("auth_status", "pending")
    is_admin = get_setting("auth_is_admin", "false") == "true"
    plan = get_setting("auth_plan", "")
    plan_expires_at = get_setting("auth_plan_expires_at", "")
    avatar_path = get_setting("auth_avatar_path", "")
    access_token = get_setting("auth_access_token", "")

    if validate_remote and user_id:
        try:
            # Tenta consulta normal, se der 401 renova o token automaticamente
            try:
                profile_url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}&select=*"
                profile_headers = {"Authorization": f"Bearer {access_token}"}
                profiles = _http_request(profile_url, method="GET", headers=profile_headers)
            except Exception as http_err:
                if "401" in str(http_err) or "Unauthorized" in str(http_err):
                    access_token = refresh_session_tokens()
                    profile_headers = {"Authorization": f"Bearer {access_token}"}
                    profiles = _http_request(profile_url, method="GET", headers=profile_headers)
                else:
                    raise

            if isinstance(profiles, list) and len(profiles) > 0:
                p = profiles[0]
                status = p.get("status", status)
                is_admin = bool(p.get("is_admin", is_admin))
                plan = p.get("plan", plan)
                plan_expires_at = p.get("plan_expires_at", plan_expires_at)
                nickname = p.get("nickname", nickname)
                avatar_path = p.get("avatar_path", avatar_path)

                set_setting("auth_status", status)
                set_setting("auth_is_admin", "true" if is_admin else "false")
                set_setting("auth_plan", plan or "")
                set_setting("auth_plan_expires_at", plan_expires_at or "")
                set_setting("auth_nickname", nickname or "")
                set_setting("auth_avatar_path", avatar_path or "")
                set_setting("auth_last_check", datetime.now().isoformat())

                # Sincroniza também a capa/banner oficial do dashboard DGS
                try:
                    settings_url = f"{SUPABASE_URL}/rest/v1/site_settings?id=eq.main&select=cover_path"
                    settings_data = _http_request(settings_url, method="GET", headers={"Authorization": f"Bearer {access_token}"})
                    if isinstance(settings_data, list) and len(settings_data) > 0 and settings_data[0].get("cover_path"):
                        set_setting("site_cover_path", settings_data[0]["cover_path"])
                except Exception:
                    pass
        except Exception as e:
            add_log(f"Aviso de validação remota (usando cache local): {str(e)}", "WARNING")

    is_expired = False
    expires_formatted = ""
    if plan_expires_at:
        try:
            clean_expires = plan_expires_at.replace("Z", "+00:00")
            exp_dt = datetime.fromisoformat(clean_expires)
            is_expired = datetime.now(timezone.utc) > exp_dt
            expires_formatted = exp_dt.strftime("%d/%m/%Y")
        except Exception:
            expires_formatted = str(plan_expires_at)[:10]

    has_access = is_admin or (status == "active" and not is_expired)

    # Período e rótulo legíveis de assinatura para exibição no topo
    if is_admin:
        sub_label = "Administrador DGS"
        sub_period = "Acesso Vitalício ADM"
    elif status == "active":
        plan_name = (plan or "PRO").upper()
        sub_label = f"Assinatura {plan_name}"
        if expires_formatted:
            sub_period = f"Ativa até {expires_formatted}"
        else:
            sub_period = "Assinatura Ativa"
    else:
        sub_label = "Assinatura Pendente"
        sub_period = "Regularização Necessária"

    avatar_url = f"{SUPABASE_URL}/storage/v1/object/public/avatars/{avatar_path}" if avatar_path else ""

    # Verifica se há avatar local em cache
    local_avatar = os.path.join(PROFILES_DIR, f"avatar_{user_id}.jpg")
    local_fallback = os.path.join(PROFILES_DIR, "avatar.jpg")
    if not avatar_url and (os.path.exists(local_avatar) or os.path.exists(local_fallback)):
        avatar_url = "/api/auth/profile/avatar"

    cover_path = get_setting("site_cover_path", "dashboard-cover/cover-1788051649238.png")
    cover_url = f"{SUPABASE_URL}/storage/v1/object/public/content-covers/{cover_path}" if cover_path else "/static/dashboard-cover.png"

    return {
        "authenticated": True,
        "has_access": has_access,
        "is_admin": is_admin,
        "status": status,
        "is_expired": is_expired,
        "plan": plan,
        "plan_expires_at": plan_expires_at,
        "cover_url": cover_url,
        "user": {
            "id": user_id,
            "email": email,
            "nickname": nickname,
            "avatar_path": avatar_path,
            "avatar_url": avatar_url,
            "subscription_label": sub_label,
            "subscription_period": sub_period
        }
    }

def update_user_avatar(file_bytes: bytes, filename: str, content_type: str = "image/jpeg") -> Dict[str, Any]:
    """
    Atualiza a foto de perfil do aluno. Salva localmente e sincroniza com o Supabase Storage.
    """
    sess = get_current_session()
    if not sess.get("authenticated", False):
        raise Exception("Usuário não autenticado.")

    user_id = sess["user"]["id"]
    token = get_setting("auth_access_token", "")

    # Salva cache local
    local_avatar = os.path.join(PROFILES_DIR, f"avatar_{user_id}.jpg")
    with open(local_avatar, "wb") as f:
        f.write(file_bytes)

    # Tenta subir pro Supabase Storage
    ext = os.path.splitext(filename)[1].lower() or ".jpg"
    remote_filename = f"avatar-{int(datetime.now().timestamp())}{ext}"
    storage_path = f"{user_id}/{remote_filename}"
    upload_url = f"{SUPABASE_URL}/storage/v1/object/avatars/{storage_path}"

    try:
        req = urllib.request.Request(
            upload_url,
            data=file_bytes,
            headers={
                "apikey": SUPABASE_ANON_KEY,
                "Authorization": f"Bearer {token}",
                "Content-Type": content_type,
                "x-upsert": "true"
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=15.0) as resp:
                pass
        except urllib.error.HTTPError as he:
            if he.code == 401:
                token = refresh_session_tokens()
                req.headers["Authorization"] = f"Bearer {token}"
                with urllib.request.urlopen(req, timeout=15.0) as resp:
                    pass
            else:
                raise

        # Atualiza a tabela profiles com o novo avatar_path
        patch_url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}"
        patch_data = json.dumps({"avatar_path": storage_path}).encode("utf-8")
        patch_req = urllib.request.Request(
            patch_url,
            data=patch_data,
            headers={
                "apikey": SUPABASE_ANON_KEY,
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            method="PATCH"
        )
        with urllib.request.urlopen(patch_req, timeout=10.0) as patch_resp:
            pass

        set_setting("auth_avatar_path", storage_path)
        add_log(f"Foto de perfil atualizada no Supabase: {storage_path}", "SUCCESS")
        avatar_url = f"{SUPABASE_URL}/storage/v1/object/public/avatars/{storage_path}"
        return {
            "success": True,
            "avatar_path": storage_path,
            "avatar_url": avatar_url
        }

    except Exception as e:
        # Se estiver offline ou der erro de rede, salva localmente
        set_setting("auth_avatar_path", "")
        add_log(f"Foto salva localmente (aviso de sincronização: {str(e)})", "WARNING")
        return {
            "success": True,
            "avatar_path": "",
            "avatar_url": "/api/auth/profile/avatar"
        }

def update_user_nickname(new_nickname: str) -> Dict[str, Any]:
    """Atualiza o apelido / nome de exibição do usuário."""
    sess = get_current_session()
    if not sess.get("authenticated", False):
        raise Exception("Usuário não autenticado.")

    name = new_nickname.strip()
    if not name:
        raise Exception("O nome não pode estar vazio.")

    user_id = sess["user"]["id"]
    token = get_setting("auth_access_token", "")

    try:
        patch_url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}"
        patch_data = json.dumps({"nickname": name}).encode("utf-8")
        patch_req = urllib.request.Request(
            patch_url,
            data=patch_data,
            headers={
                "apikey": SUPABASE_ANON_KEY,
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            method="PATCH"
        )
        try:
            with urllib.request.urlopen(patch_req, timeout=10.0) as patch_resp:
                pass
        except urllib.error.HTTPError as he:
            if he.code == 401:
                token = refresh_session_tokens()
                patch_req.headers["Authorization"] = f"Bearer {token}"
                with urllib.request.urlopen(patch_req, timeout=10.0) as patch_resp:
                    pass
            else:
                raise

        set_setting("auth_nickname", name)
        add_log(f"Nome do perfil atualizado para: {name}", "INFO")
        return {"success": True, "nickname": name}
    except Exception as e:
        set_setting("auth_nickname", name)
        add_log(f"Nome salvo localmente (aviso: {str(e)})", "WARNING")
        return {"success": True, "nickname": name}

def admin_get_alunos() -> Dict[str, Any]:
    """Retorna listagem de alunos e estatísticas para o painel admin da Central DGS."""
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise Exception("Acesso restrito: apenas administradores podem visualizar estes dados.")

    token = get_setting("auth_access_token", "")
    url = f"{SUPABASE_URL}/rest/v1/profiles?select=*&order=created_at.desc"
    try:
        profiles = _http_request(url, headers={"Authorization": f"Bearer {token}"})
    except Exception as e:
        if "401" in str(e):
            token = refresh_session_tokens()
            profiles = _http_request(url, headers={"Authorization": f"Bearer {token}"})
        else:
            raise

    if not isinstance(profiles, list):
        profiles = []

    total = len(profiles)
    active = sum(1 for p in profiles if p.get("status") == "active")
    pending = sum(1 for p in profiles if p.get("status") == "pending")

    mrr = 0.0
    for p in profiles:
        if p.get("status") == "active":
            pl = p.get("plan")
            if pl == "mensal":
                mrr += 97.0
            elif pl == "trimestral":
                mrr += 89.0
            elif pl == "anual":
                mrr += 67.0
            elif pl == "vitalicio":
                pass
            else:
                mrr += 97.0

    return {
        "total": total,
        "active": active,
        "pending": pending,
        "mrr": mrr,
        "alunos": profiles
    }

def admin_update_aluno_status(user_id: str, new_status: str, plan: Optional[str] = None) -> Dict[str, Any]:
    """Permite ao administrador ativar, suspender ou alterar plano de um aluno diretamente pela Central DGS."""
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise Exception("Acesso restrito: apenas administradores podem executar esta ação.")

    token = get_setting("auth_access_token", "")
    url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}"
    update_data: Dict[str, Any] = {"status": new_status}

    if new_status == "active":
        if plan:
            update_data["plan"] = plan
        days = 30
        if plan == "trimestral":
            days = 90
        elif plan == "anual":
            days = 365
        elif plan == "vitalicio":
            days = 3650
        new_exp = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()
        update_data["plan_expires_at"] = new_exp
        update_data["plan_activated_at"] = datetime.now(timezone.utc).isoformat()
    elif new_status == "suspended":
        # Se suspender, expira o plano imediatamente
        update_data["plan_expires_at"] = datetime.now(timezone.utc).isoformat()

    try:
        res = _http_request(url, method="PATCH", headers={"Authorization": f"Bearer {token}"}, data=update_data)
    except Exception as e:
        if "401" in str(e):
            token = refresh_session_tokens()
            res = _http_request(url, method="PATCH", headers={"Authorization": f"Bearer {token}"}, data=update_data)
        else:
            raise

    add_log(f"Admin alterou status do aluno {user_id} para '{new_status}' (Plano: {plan})", "INFO")
    return {"success": True, "user_id": user_id, "new_status": new_status}

def admin_delete_aluno(user_id: str) -> Dict[str, Any]:
    """Remove completamente o perfil do aluno no Supabase."""
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise Exception("Acesso restrito: apenas administradores podem executar esta ação.")

    token = get_setting("auth_access_token", "")
    url = f"{SUPABASE_URL}/rest/v1/profiles?id=eq.{user_id}"
    try:
        _http_request(url, method="DELETE", headers={"Authorization": f"Bearer {token}"})
    except Exception as e:
        if "401" in str(e):
            token = refresh_session_tokens()
            _http_request(url, method="DELETE", headers={"Authorization": f"Bearer {token}"})
        else:
            raise

    add_log(f"Admin removeu perfil de aluno: {user_id}", "WARNING", "admin")
    return {"success": True, "user_id": user_id}
