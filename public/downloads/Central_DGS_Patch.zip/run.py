import os
import sys

# 1. Garante imediatamente que o diretório raiz da Central DGS está no sys.path e no os.getcwd()
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
try:
    os.chdir(BASE_DIR)
except Exception:
    pass

import webbrowser
import threading
import time
import socket
import urllib.request
import urllib.error
import subprocess

def show_native_error(title: str, message: str):
    """Exibe um diálogo nativo do Windows em caso de erro crítico para não fechar em silêncio."""
    try:
        log_path = os.path.join(BASE_DIR, "storage", "startup_error.log")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {title}: {message}\n")
    except Exception:
        pass

    if sys.platform == "win32":
        try:
            import ctypes
            # MB_OK | MB_ICONERROR | MB_SYSTEMMODAL = 0x0 | 0x10 | 0x1000 = 0x1010
            ctypes.windll.user32.MessageBoxW(0, str(message), str(title), 0x1010)
        except Exception:
            print(f"[ERRO CRÍTICO] {title}: {message}")

def ensure_dependencies():
    """Garante que bibliotecas essenciais novas estejam instaladas."""
    try:
        import httpx
    except ImportError:
        try:
            print("[Central DGS] Instalando bibliotecas complementares...")
            subprocess.run([sys.executable, "-m", "pip", "install", "httpx>=0.27.0", "--quiet"], check=False)
        except Exception:
            pass

def check_http_health(port: int = 8787, timeout: float = 1.0) -> bool:
    """Verifica se o servidor da Central está ativo e respondendo na porta."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/stats", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False

def clean_zombie_port(port: int = 8787):
    """
    Se a porta 8787 estiver ocupada por um processo fantasma que não responde a requisições,
    encerra o processo travado para permitir a inicialização limpa da Central.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            if s.connect_ex(('127.0.0.1', port)) != 0:
                return  # Porta livre

        # Porta tem conexão: testa se está saudável
        if check_http_health(port, timeout=1.0):
            return  # Está saudável, reutiliza

        # Processo travado (zombie): mata
        print(f"[Central DGS] Detectado processo travado na porta {port}. Liberando porta...")
        out = subprocess.check_output(f'netstat -ano | findstr :{port}', shell=True).decode(errors="ignore")
        current_pid = str(os.getpid())
        for line in out.strip().splitlines():
            if "LISTENING" in line:
                pid = line.strip().split()[-1]
                if pid and pid.isdigit() and pid != current_pid:
                    print(f"[Central DGS] Encerrando processo órfão (PID {pid})...")
                    subprocess.call(f'taskkill /F /PID {pid}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1.0)
    except Exception as e:
        print("[Central DGS] Aviso ao verificar porta:", e)

def wait_for_server_ready(port: int = 8787, max_wait: float = 15.0) -> bool:
    """Aguarda ativamente até que o servidor HTTP esteja 100% pronto e respondendo 200 OK."""
    start_time = time.time()
    url = f"http://127.0.0.1:{port}/api/stats"
    while time.time() - start_time < max_wait:
        try:
            with urllib.request.urlopen(url, timeout=0.6) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(0.15)
    return False

def open_browser():
    print("[Central DGS] Aguardando inicialização completa do motor e servidor...")
    ready = wait_for_server_ready(8787, max_wait=15.0)
    if ready:
        print("[Central DGS] Servidor 100% pronto! Abrindo painel visual...")
    else:
        print("[Central DGS] Aviso: Servidor demorou para responder, abrindo navegador...")

    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        os.path.expanduser(r"~\AppData\Local\Microsoft\Edge\Application\msedge.exe"),
    ]
    chrome_exe = None
    for cp in chrome_paths:
        if os.path.exists(cp):
            chrome_exe = cp
            break

    shared_profile = os.path.join(BASE_DIR, "storage", "profiles", "app_browser")
    try:
        os.makedirs(shared_profile, exist_ok=True)
    except Exception:
        pass

    if chrome_exe:
        print("\n[Central DGS] Abrindo aplicativo em tela cheia: http://127.0.0.1:8787\n")
        try:
            subprocess.Popen([
                chrome_exe,
                "--app=http://127.0.0.1:8787",
                "--start-maximized",
                f"--user-data-dir={shared_profile}",
                "--no-first-run",
                "--no-default-browser-check"
            ])
            return
        except Exception as e:
            print("[Central DGS] Falha ao iniciar aplicativo em modo janela:", e)

    print("\n[Central DGS] Abrindo painel no navegador padrão: http://127.0.0.1:8787\n")
    try:
        webbrowser.open("http://127.0.0.1:8787")
    except Exception as e:
        print("[Central DGS] Erro ao abrir navegador padrão:", e)

def main():
    print("=" * 60)
    print("   DIGITAL SUPPLY — Central DGS   ")
    print("=" * 60)

    # 1. Verifica dependências necessárias
    ensure_dependencies()

    # 2. Libera a porta se houver processo zumbi travado
    clean_zombie_port(8787)

    # 3. Se já houver uma instância saudável da Central rodando, reutiliza e abre o navegador
    if check_http_health(8787, timeout=1.0):
        print("[Central DGS] Servidor da Central já está rodando ativo e saudável na porta 8787!")
        print("[Central DGS] Abrindo interface no navegador...")
        open_browser()
        time.sleep(1.0)
        sys.exit(0)

    print("Iniciando motor e servidor local na porta 8787...")

    # 4. Abre o navegador automaticamente quando o servidor responder 200 OK
    threading.Thread(target=open_browser, daemon=True).start()

    # 5. Inicia o servidor FastAPI com Uvicorn
    try:
        import uvicorn
        from backend.app import app
        uvicorn.run(app, host="127.0.0.1", port=8787, log_level="info", reload=False)
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        show_native_error("Central DGS - Erro ao Iniciar Servidor", f"Ocorreu um erro ao iniciar a Central DGS:\n\n{e}\n\nDetalhes:\n{tb}")
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception as err:
        import traceback
        tb = traceback.format_exc()
        show_native_error("Central DGS - Falha Inesperada", f"Não foi possível iniciar a Central DGS:\n\n{err}\n\n{tb}")
        sys.exit(1)
