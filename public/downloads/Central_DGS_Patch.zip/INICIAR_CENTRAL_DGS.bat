@echo off
chcp 65001 >nul
title Central DGS
color 0E

cd /d "%~dp0"

echo ========================================================
echo         CENTRAL DGS - STUDIO DE AGENDAMENTO
echo        Instagram Reels - TikTok - YouTube Shorts
echo ========================================================
echo.
echo Iniciando servidor e painel visual...
echo O painel abrira automaticamente em: http://127.0.0.1:8787
echo.

if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" run.py
) else (
    python run.py
)

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERRO] A Central DGS encerrou com erro (%ERRORLEVEL%).
    echo Pressione qualquer tecla para fechar esta janela...
    pause >nul
)
