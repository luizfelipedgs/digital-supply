import os
import sys
import shutil
import zipfile
import sqlite3
import hashlib

def make_clean_database(target_db_path: str):
    """Cria uma base SQLite limpa com o esquema completo da Central, pronta para novo aluno."""
    os.makedirs(os.path.dirname(target_db_path), exist_ok=True)
    if os.path.exists(target_db_path):
        os.remove(target_db_path)

    conn = sqlite3.connect(target_db_path)
    cur = conn.cursor()

    # Esquema oficial
    cur.execute("""
    CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        platform TEXT NOT NULL,
        username TEXT,
        avatar TEXT,
        status TEXT DEFAULT 'active',
        profile_dir TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_check TEXT
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS videos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        filepath TEXT NOT NULL,
        title TEXT,
        caption TEXT,
        hashtags TEXT,
        filesize INTEGER DEFAULT 0,
        duration REAL DEFAULT 0,
        thumbnail_path TEXT,
        filter_status TEXT DEFAULT 'original',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        video_id INTEGER NOT NULL,
        account_id INTEGER NOT NULL,
        platform TEXT NOT NULL,
        scheduled_time TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        status_detail TEXT DEFAULT 'Pendente',
        attempts INTEGER DEFAULT 0,
        published_url TEXT,
        error_message TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        published_at TEXT,
        custom_title TEXT DEFAULT '',
        custom_caption TEXT DEFAULT '',
        custom_hashtags TEXT DEFAULT '',
        views_count INTEGER DEFAULT 0,
        likes_count INTEGER DEFAULT 0,
        comments_count INTEGER DEFAULT 0,
        shares_count INTEGER DEFAULT 0,
        custom_sound TEXT DEFAULT '',
        FOREIGN KEY (video_id) REFERENCES videos (id),
        FOREIGN KEY (account_id) REFERENCES accounts (id)
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        level TEXT DEFAULT 'INFO',
        message TEXT NOT NULL,
        platform TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )""")

    # Configurações padrão seguras para alunos
    default_settings = [
        ("engine_running", "false"),
        ("test_mode", "false"),
        ("visible_browser", "false"),
        ("min_delay_between_posts_minutes", "45"),
        ("auto_verify_post", "true"),
        ("auth_logged_in", "false"),
        ("auth_email", ""),
        ("auth_nickname", ""),
        ("auth_status", "pending"),
        ("auth_is_admin", "false")
    ]
    cur.executemany("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", default_settings)

    conn.commit()
    conn.close()
    print("[+] Banco de dados zerado (central.db) configurado com sucesso!")

def build_installer_package():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dist_dir = os.path.join(base_dir, "dist")
    stage_dir = os.path.join(dist_dir, "Central_DGS")
    zip_output_path = os.path.join(dist_dir, "Central_DGS_Instalador_Windows.zip")
    site_downloads_dir = os.path.join("D:\\Site DGS", "digital-supply", "public", "downloads")

    print("=======================================================================")
    print("      GERADOR DE PACOTE DE INSTALAÇÃO DO ALUNO - CENTRAL DGS")
    print("=======================================================================\n")
    print(f"Diretório base: {base_dir}")
    print(f"Diretório dist: {dist_dir}\n")

    # Limpa diretório de build
    if os.path.exists(stage_dir):
        shutil.rmtree(stage_dir)
    os.makedirs(stage_dir, exist_ok=True)

    # 1. Copia Backend (sem __pycache__)
    print("[1/6] Copiando módulos backend...")
    shutil.copytree(
        os.path.join(base_dir, "backend"),
        os.path.join(stage_dir, "backend"),
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo")
    )

    # 2. Copia Frontend
    print("[2/6] Copiando arquivos frontend...")
    shutil.copytree(
        os.path.join(base_dir, "frontend"),
        os.path.join(stage_dir, "frontend")
    )

    # 2.1. Copia e empacota Extensão Google Chrome (Download em Massa)
    print("[2.1/6] Copiando e empacotando extensão oficial Google Chrome (Download em Massa)...")
    ext_src = os.path.join(base_dir, "extension-download-massa")
    if os.path.exists(ext_src):
        shutil.copytree(
            ext_src,
            os.path.join(stage_dir, "extension-download-massa"),
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".git*")
        )
        # Gera o pacote ZIP da extensão em frontend/static tanto no stage quanto no base
        stage_static_dir = os.path.join(stage_dir, "frontend", "static")
        base_static_dir = os.path.join(base_dir, "frontend", "static")
        os.makedirs(stage_static_dir, exist_ok=True)
        os.makedirs(base_static_dir, exist_ok=True)
        for sdir in [stage_static_dir, base_static_dir]:
            ext_zip = os.path.join(sdir, "DGS_Download_em_Massa_Extensao.zip")
            with zipfile.ZipFile(ext_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as ezp:
                for root, _, files in os.walk(ext_src):
                    for file in files:
                        abs_p = os.path.join(root, file)
                        rel_p = os.path.relpath(abs_p, ext_src)
                        ezp.write(abs_p, rel_p)

    # 3. Cria pasta Storage limpa com banco zerado
    print("[3/6] Preparando storage seguro e banco de dados limpo...")
    clean_storage_dir = os.path.join(stage_dir, "storage")
    os.makedirs(os.path.join(clean_storage_dir, "profiles"), exist_ok=True)
    os.makedirs(os.path.join(clean_storage_dir, "videos"), exist_ok=True)
    os.makedirs(os.path.join(clean_storage_dir, "thumbnails"), exist_ok=True)
    make_clean_database(os.path.join(clean_storage_dir, "central.db"))

    # 4. Copia arquivos raiz essenciais
    print("[4/6] Copiando scripts de instalação, Launcher oficial e inicializadores...")
    root_files = [
        "requirements.txt",
        "run.py",
        "validate_integrity.py",
        "Launcher_Central_DGS.exe",
        "INSTALAR_CENTRAL_DGS.bat",
        "INICIAR_CENTRAL_DGS.bat",
        "INICIAR_CENTRAL_DGS.vbs",
        "ATUALIZAR_CENTRAL_DGS.bat",
        "PARAR_CENTRAL_DGS.bat",
        "LEIA_ME_PRIMEIROS_PASSOS.txt"
    ]
    for rf in root_files:
        src = os.path.join(base_dir, rf)
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(stage_dir, rf))

    # Garante compatibilidade 100% nativa com o Windows (converte scripts para CRLF \r\n)
    print("[4.1/6] Garantindo quebras de linha Windows (CRLF) para scripts e lotes...")
    for root, dirs, files in os.walk(stage_dir):
        for f in files:
            if f.endswith(('.bat', '.cmd', '.vbs', '.txt')):
                fpath = os.path.join(root, f)
                with open(fpath, "rb") as fp:
                    content = fp.read()
                crlf_content = content.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
                if crlf_content != content:
                    with open(fpath, "wb") as fp:
                        fp.write(crlf_content)

    # 5. Compacta pacote completo do instalador em ZIP
    print(f"[5/7] Compactando instalador completo: {zip_output_path}...")
    if os.path.exists(zip_output_path):
        os.remove(zip_output_path)

    with zipfile.ZipFile(zip_output_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for root, dirs, files in os.walk(stage_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, dist_dir)
                zipf.write(abs_path, rel_path)

    # 6. Compacta pacote de atualização (Patch) - Sem storage, sem banco
    patch_output_path = os.path.join(dist_dir, "Central_DGS_Patch.zip")
    print(f"[6/7] Compactando pacote de atualização leve (Patch): {patch_output_path}...")
    if os.path.exists(patch_output_path):
        os.remove(patch_output_path)

    with zipfile.ZipFile(patch_output_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as pzip:
        for root, dirs, files in os.walk(stage_dir):
            rel_from_stage = os.path.relpath(root, stage_dir)
            if rel_from_stage == "storage" or rel_from_stage.startswith("storage" + os.sep):
                continue  # Nunca inclui storage no patch!
            for file in files:
                abs_path = os.path.join(root, file)
                rel_in_dist = os.path.relpath(abs_path, dist_dir)
                pzip.write(abs_path, rel_in_dist)

    # 6.1. Compacta Central_DGS_Core.zip (usado pelo Launcher Oficial do Aluno)
    core_output_path = os.path.join(dist_dir, "Central_DGS_Core.zip")
    print(f"[6.1/7] Compactando Central_DGS_Core.zip (para Launcher Oficial): {core_output_path}...")
    if os.path.exists(core_output_path):
        os.remove(core_output_path)

    with zipfile.ZipFile(core_output_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as czip:
        for root, dirs, files in os.walk(stage_dir):
            for file in files:
                abs_path = os.path.join(root, file)
                rel_in_stage = os.path.relpath(abs_path, stage_dir)
                czip.write(abs_path, rel_in_stage)

    # 7. Copia para a pasta pública de downloads do Site DGS
    print(f"[7/7] Publicando pacotes no Hub de Download do Site DGS...")
    try:
        os.makedirs(site_downloads_dir, exist_ok=True)
        dest_site_zip = os.path.join(site_downloads_dir, "Central_DGS_Instalador_Windows.zip")
        shutil.copy2(zip_output_path, dest_site_zip)
        dest_patch_zip = os.path.join(site_downloads_dir, "Central_DGS_Patch.zip")
        shutil.copy2(patch_output_path, dest_patch_zip)
        dest_core_zip = os.path.join(site_downloads_dir, "Central_DGS_Core.zip")
        shutil.copy2(core_output_path, dest_core_zip)
        print(f"[+] Instalador copiado para: {dest_site_zip}")
        print(f"[+] Patch copiado para: {dest_patch_zip}")
        print(f"[+] Core (Launcher) copiado para: {dest_core_zip}")
    except Exception as e:
        print(f"[!] Aviso ao copiar para pasta pública do site: {e}")

    # Estatísticas
    size_mb = os.path.getsize(zip_output_path) / (1024 * 1024)
    sha256 = hashlib.sha256()
    with open(zip_output_path, "rb") as f:
        while chunk := f.read(65536):
            sha256.update(chunk)

    print("\n=======================================================================")
    print("             PACOTE DE INSTALAÇÃO GERADO COM SUCESSO!")
    print("=======================================================================")
    print(f"Arquivo gerado: {zip_output_path}")
    print(f"Tamanho total:  {size_mb:.2f} MB")
    print(f"SHA-256:        {sha256.hexdigest()}")
    print("=======================================================================\n")

if __name__ == "__main__":
    build_installer_package()
