using System;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

[assembly: System.Reflection.AssemblyTitle("Central DGS Launcher")]
[assembly: System.Reflection.AssemblyDescription("Launcher e Instalador Oficial da Central DGS")]
[assembly: System.Reflection.AssemblyCompany("Digital Supply")]
[assembly: System.Reflection.AssemblyProduct("Central DGS")]
[assembly: System.Reflection.AssemblyVersion("2.3.5.0")]
[assembly: System.Reflection.AssemblyFileVersion("2.3.5.0")]

namespace CentralDGSLauncher
{
    public class App : Application
    {
        [STAThread]
        public static void Main()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var app = new App();
            app.Run(new MainWindow());
        }
    }

    public class MainWindow : Window
    {
        private ProgressBar progressBar;
        private TextBlock statusText;
        private TextBox logBox;
        private Button btnAction;
        private Button btnSecondary;
        private Button btnCopyLog;
        private string installDir;
        private bool isInstalling = false;

        private const string CORE_DOWNLOAD_URL = "https://digitalsupply.pro/downloads/Central_DGS_Core.zip";
        private const string LOCAL_FALLBACK_URL = "http://127.0.0.1:3000/downloads/Central_DGS_Core.zip";

        public MainWindow()
        {
            installDir = DetermineInstallDirectory();

            Title = "Digital Supply — Central DGS • Instalador Oficial v2.3.4";
            Width = 740;
            Height = 560;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(8, 8, 6));
            Foreground = Brushes.White;
            ResizeMode = ResizeMode.CanMinimize;

            BuildUI();
            CheckInitialState();
        }

        private string DetermineInstallDirectory()
        {
            // Preferência 1: C:\Central_DGS
            string defaultPath = @"C:\Central_DGS";
            try
            {
                if (!Directory.Exists(defaultPath))
                {
                    Directory.CreateDirectory(defaultPath);
                }
                string testFile = Path.Combine(defaultPath, ".write_test");
                File.WriteAllText(testFile, "ok");
                File.Delete(testFile);
                return defaultPath;
            }
            catch
            {
                // Fallback 2: %LOCALAPPDATA%\Central_DGS (caso C:\ precise de privilégios elevados)
                string localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string fallback = Path.Combine(localApp, "Central_DGS");
                if (!Directory.Exists(fallback))
                {
                    Directory.CreateDirectory(fallback);
                }
                return fallback;
            }
        }

        private void BuildUI()
        {
            var grid = new Grid();
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(80) }); // Header
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // Content
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(70) }); // Footer

            // 1. Header
            var header = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(12, 14, 9)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(30, 36, 20)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding = new Thickness(20, 14, 20, 14)
            };
            var headerPanel = new StackPanel { Orientation = Orientation.Horizontal };
            var titlePanel = new StackPanel();
            var brandLabel = new TextBlock
            {
                Text = "DIGITAL SUPPLY • COMUNIDADE OFICIAL DGS",
                Foreground = new SolidColorBrush(Color.FromRgb(154, 205, 50)),
                FontSize = 10,
                FontWeight = FontWeights.Bold
            };
            var titleLabel = new TextBlock
            {
                Text = "Central DGS — Launcher & Instalador Oficial v2.2.0",
                Foreground = Brushes.White,
                FontSize = 17,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 3, 0, 0)
            };
            titlePanel.Children.Add(brandLabel);
            titlePanel.Children.Add(titleLabel);
            headerPanel.Children.Add(titlePanel);
            header.Child = headerPanel;
            Grid.SetRow(header, 0);
            grid.Children.Add(header);

            // 2. Content
            var content = new Grid { Margin = new Thickness(20, 15, 20, 10) };
            content.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            content.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            content.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            statusText = new TextBlock
            {
                Text = "Verificando instalação da Central DGS no seu computador...",
                FontSize = 13,
                Foreground = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
                Margin = new Thickness(0, 0, 0, 8)
            };
            Grid.SetRow(statusText, 0);
            content.Children.Add(statusText);

            progressBar = new ProgressBar
            {
                Height = 8,
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                Foreground = new SolidColorBrush(Color.FromRgb(154, 205, 50)),
                Background = new SolidColorBrush(Color.FromRgb(25, 25, 25)),
                BorderThickness = new Thickness(0),
                Margin = new Thickness(0, 0, 0, 12)
            };
            Grid.SetRow(progressBar, 1);
            content.Children.Add(progressBar);

            logBox = new TextBox
            {
                Background = new SolidColorBrush(Color.FromRgb(2, 2, 1)),
                Foreground = new SolidColorBrush(Color.FromRgb(154, 205, 50)),
                FontFamily = new FontFamily("Consolas, Courier New, monospace"),
                FontSize = 11,
                BorderBrush = new SolidColorBrush(Color.FromRgb(30, 36, 20)),
                BorderThickness = new Thickness(1),
                Padding = new Thickness(10),
                IsReadOnly = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                TextWrapping = TextWrapping.Wrap
            };
            Grid.SetRow(logBox, 2);
            content.Children.Add(logBox);

            Grid.SetRow(content, 1);
            grid.Children.Add(content);

            // 3. Footer
            var footer = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(12, 14, 9)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(30, 36, 20)),
                BorderThickness = new Thickness(0, 1, 0, 0),
                Padding = new Thickness(20, 14, 20, 14)
            };
            var footerPanel = new DockPanel();

            btnCopyLog = new Button
            {
                Content = "📋 Copiar Logs",
                Height = 36,
                Padding = new Thickness(12, 0, 12, 0),
                Background = new SolidColorBrush(Color.FromRgb(25, 25, 25)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
                FontSize = 12,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            btnCopyLog.Click += (s, e) =>
            {
                try
                {
                    Clipboard.SetText(logBox.Text);
                    MessageBox.Show("Logs copiados para a área de transferência!", "Central DGS", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Aviso: " + ex.Message, "Central DGS", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };
            DockPanel.SetDock(btnCopyLog, Dock.Left);
            footerPanel.Children.Add(btnCopyLog);

            var rightButtons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };

            btnSecondary = new Button
            {
                Content = "🔄 Reinstalar / Reparar",
                Height = 36,
                Padding = new Thickness(14, 0, 14, 0),
                Background = new SolidColorBrush(Color.FromRgb(25, 25, 25)),
                Foreground = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
                FontSize = 12,
                Margin = new Thickness(0, 0, 10, 0),
                Cursor = System.Windows.Input.Cursors.Hand,
                Visibility = Visibility.Collapsed
            };
            btnSecondary.Click += (s, e) => StartInstallation();
            rightButtons.Children.Add(btnSecondary);

            btnAction = new Button
            {
                Content = "⚡ Instalar Central DGS",
                Height = 36,
                Padding = new Thickness(20, 0, 20, 0),
                Background = new SolidColorBrush(Color.FromRgb(154, 205, 50)),
                Foreground = new SolidColorBrush(Color.FromRgb(8, 8, 6)),
                FontWeight = FontWeights.Bold,
                FontSize = 13,
                BorderThickness = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand
            };
            btnAction.Click += (s, e) =>
            {
                if (btnAction.Content.ToString().Contains("Iniciar"))
                {
                    LaunchCentral();
                }
                else
                {
                    StartInstallation();
                }
            };
            rightButtons.Children.Add(btnAction);

            footerPanel.Children.Add(rightButtons);
            footer.Child = footerPanel;
            Grid.SetRow(footer, 2);
            grid.Children.Add(footer);

            Content = grid;
        }

        private void AppendLog(string message)
        {
            Dispatcher.Invoke(new Action(() =>
            {
                logBox.AppendText(string.Format("[{0:HH:mm:ss}] {1}\n", DateTime.Now, message));
                logBox.ScrollToEnd();
            }));
        }

        private void SetStatus(string message, double progress)
        {
            Dispatcher.Invoke(new Action(() =>
            {
                statusText.Text = message;
                if (progress >= 0)
                {
                    progressBar.Value = progress;
                }
            }));
        }

        private bool IsInstalled()
        {
            string venvPython = Path.Combine(installDir, ".venv", "Scripts", "python.exe");
            string runPy = Path.Combine(installDir, "run.py");
            return File.Exists(venvPython) && File.Exists(runPy);
        }

        private void CheckInitialState()
        {
            AppendLog("Launcher oficial iniciado com sucesso.");
            AppendLog("Pasta oficial da Central DGS: " + installDir);

            if (IsInstalled())
            {
                SetStatus("Central DGS pronta para uso! (" + installDir + ")", 100);
                AppendLog("Instalação existente detectada com sucesso.");
                btnAction.Content = "🚀 Iniciar Central DGS";
                btnSecondary.Visibility = Visibility.Visible;
            }
            else
            {
                SetStatus("Pronto para instalar a Central DGS v2.2.0 no seu computador.", 0);
                AppendLog("Clique no botão 'Instalar Central DGS' abaixo. Tudo será configurado de forma 100% automática.");
                btnAction.Content = "⚡ Instalar Central DGS";
                btnSecondary.Visibility = Visibility.Collapsed;
            }
        }

        private async void StartInstallation()
        {
            if (isInstalling) return;
            isInstalling = true;
            btnAction.IsEnabled = false;
            btnSecondary.IsEnabled = false;

            logBox.Clear();
            AppendLog("=======================================================================");
            AppendLog("           INSTALADOR OFICIAL DA CENTRAL DGS - VERSÃO 2.2.0");
            AppendLog("=======================================================================");
            AppendLog("Pasta de instalação no seu disco: " + installDir);

            await Task.Run(() =>
            {
                try
                {
                    Directory.CreateDirectory(installDir);

                    // 1. Download do Pacote Core Oficial
                    SetStatus("1/6: Baixando arquivos essenciais da Central DGS v2.2.0...", 5);
                    string localZip = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Central_DGS_Core.zip");
                    string targetZip = Path.Combine(installDir, "temp_core.zip");

                    if (File.Exists(localZip))
                    {
                        AppendLog("Pacote Core local encontrado. Utilizando arquivo local...");
                        File.Copy(localZip, targetZip, true);
                    }
                    else
                    {
                        AppendLog("Baixando pacote oficial mais recente do servidor...");
                        DownloadCorePackage(targetZip);
                    }

                    // 2. Extração dos arquivos para a pasta C:\Central_DGS
                    SetStatus("2/6: Extraindo arquivos da aplicação...", 25);
                    AppendLog("Extraindo arquivos da aplicação em " + installDir + "...");
                    ExtractZipSafe(targetZip, installDir);
                    if (File.Exists(targetZip))
                    {
                        try { File.Delete(targetZip); } catch { }
                    }
                    AppendLog("[+] Arquivos da Central DGS extraídos com sucesso!");

                    // Copia o próprio Launcher para dentro da pasta instalada
                    try
                    {
                        string currentExe = Process.GetCurrentProcess().MainModule.FileName;
                        string destExe = Path.Combine(installDir, "Launcher_Central_DGS.exe");
                        if (!currentExe.Equals(destExe, StringComparison.OrdinalIgnoreCase))
                        {
                            File.Copy(currentExe, destExe, true);
                        }
                    }
                    catch { }

                    // 3. Detectar / Instalar Python
                    SetStatus("3/6: Verificando instalação do Python 3 no Windows...", 35);
                    string pythonCmd = DetectPython();
                    if (string.IsNullOrEmpty(pythonCmd))
                    {
                        AppendLog("[!] Python não detectado no sistema. Instalando automaticamente via Windows winget...");
                        SetStatus("Instalando Python 3.12 automaticamente pelo Windows...", 40);
                        RunCommand("winget", "install Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements");

                        pythonCmd = DetectPython();
                        if (string.IsNullOrEmpty(pythonCmd))
                        {
                            throw new Exception("Não foi possível instalar o Python automaticamente. Por favor instale o Python 3.12 em https://www.python.org/downloads/ marcando 'Add python.exe to PATH'.");
                        }
                    }

                    AppendLog("[+] Python detectado com sucesso: " + pythonCmd);

                    // 4. Criar .venv
                    SetStatus("4/6: Criando ambiente virtual isolado (.venv)...", 50);
                    string venvDir = Path.Combine(installDir, ".venv");
                    string venvPython = Path.Combine(venvDir, "Scripts", "python.exe");

                    if (!File.Exists(venvPython))
                    {
                        AppendLog("Criando pasta do ambiente isolado .venv...");
                        RunCommand(pythonCmd, "-m venv .venv");
                    }

                    if (!File.Exists(venvPython))
                    {
                        AppendLog("[!] Ambiente .venv não pôde ser criado isoladamente, usando Python do sistema.");
                        venvPython = pythonCmd;
                    }
                    else
                    {
                        AppendLog("[+] Ambiente isolado (.venv) pronto!");
                    }

                    // 5. Instalar Dependências
                    SetStatus("5/6: Instalando dependências e bibliotecas (FastAPI, SQLite, etc)...", 70);
                    AppendLog("Instalando bibliotecas do requirements.txt...");
                    RunCommand(venvPython, "-m pip install --upgrade pip --quiet");
                    RunCommand(venvPython, "-m pip install -r requirements.txt");
                    AppendLog("[+] Bibliotecas instaladas com sucesso!");

                    // 6. Playwright Chromium
                    SetStatus("Configurando navegador de automação (Playwright Chromium)...", 85);
                    string playwrightExe = Path.Combine(installDir, ".venv", "Scripts", "playwright.exe");
                    if (File.Exists(playwrightExe))
                    {
                        RunCommand(playwrightExe, "install chromium");
                    }
                    else
                    {
                        RunCommand(venvPython, "-m playwright install chromium");
                    }
                    AppendLog("[+] Navegador de automação configurado com sucesso!");

                    // 7. Criar Atalho na Área de Trabalho
                    SetStatus("6/6: Criando atalho oficial na Área de Trabalho...", 95);
                    CreateShortcuts();
                    AppendLog("[+] Atalho 'Central DGS' criado na Área de Trabalho!");

                    SetStatus("🎉 Instalação Concluída com Sucesso! Versão v2.2.0 pronta.", 100);
                    AppendLog("=======================================================================");
                    AppendLog("       PARABÉNS! A CENTRAL DGS ESTÁ 100% PRONTA PARA USO");
                    AppendLog("=======================================================================");

                    Dispatcher.Invoke(new Action(() =>
                    {
                        btnAction.Content = "🚀 Iniciar Central DGS";
                        btnAction.IsEnabled = true;
                        btnSecondary.Visibility = Visibility.Visible;
                        btnSecondary.IsEnabled = true;
                    }));

                    // Inicia automaticamente a Central DGS após conclusão
                    Task.Delay(1500).ContinueWith(_ =>
                    {
                        Dispatcher.Invoke(new Action(() => LaunchCentral()));
                    });
                }
                catch (Exception ex)
                {
                    AppendLog("[ERRO CRÍTICO] " + ex.Message);
                    SetStatus("❌ Erro durante a instalação. Veja o log acima.", 0);
                    Dispatcher.Invoke(new Action(() =>
                    {
                        btnAction.Content = "Tentar Novamente";
                        btnAction.IsEnabled = true;
                        btnSecondary.IsEnabled = true;
                    }));
                }
                finally
                {
                    isInstalling = false;
                }
            });
        }

        private void DownloadCorePackage(string targetZip)
        {
            string[] urls = new string[] { CORE_DOWNLOAD_URL, LOCAL_FALLBACK_URL };
            Exception lastEx = null;

            foreach (var url in urls)
            {
                try
                {
                    AppendLog("Conectando ao servidor: " + url + "...");
                    using (var client = new WebClient())
                    {
                        client.Headers.Add("User-Agent", "CentralDGS-Launcher/2.2.0 (Windows)");
                        client.DownloadProgressChanged += (s, e) =>
                        {
                            double p = 5 + (e.ProgressPercentage * 0.18);
                            SetStatus(string.Format("Baixando Central DGS: {0}% ({1:0.0} MB)", e.ProgressPercentage, e.BytesReceived / 1048576.0), p);
                        };
                        client.DownloadFileTaskAsync(new Uri(url), targetZip).Wait();
                    }

                    if (File.Exists(targetZip) && new FileInfo(targetZip).Length > 10000)
                    {
                        AppendLog("[+] Download concluído com sucesso!");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    lastEx = ex;
                    AppendLog("[!] Falha ao baixar de " + url + ": " + ex.Message);
                }
            }

            throw new Exception("Não foi possível baixar os arquivos da Central DGS. Verifique sua conexão com a internet. Detalhe: " + (lastEx != null ? lastEx.Message : "servidor inacessível"));
        }

        private void ExtractZipSafe(string zipPath, string targetDir)
        {
            using (var archive = ZipFile.OpenRead(zipPath))
            {
                foreach (var entry in archive.Entries)
                {
                    if (string.IsNullOrEmpty(entry.Name)) continue; // Diretório puro

                    string destFile = Path.Combine(targetDir, entry.FullName);
                    string destDir = Path.GetDirectoryName(destFile);
                    if (!Directory.Exists(destDir))
                    {
                        Directory.CreateDirectory(destDir);
                    }

                    // REGRA DE SEGURANÇA: Se já existir central.db (dados do aluno), NUNCA sobrescreve!
                    if (entry.FullName.ToLower().Contains("central.db") && File.Exists(destFile))
                    {
                        continue;
                    }

                    entry.ExtractToFile(destFile, true);
                }
            }
        }

        private string DetectPython()
        {
            string[] testCmds = new string[] { "python", "py -3", "py" };
            foreach (var cmd in testCmds)
            {
                try
                {
                    var p = new Process();
                    p.StartInfo.FileName = cmd.Contains(" ") ? cmd.Split(' ')[0] : cmd;
                    p.StartInfo.Arguments = cmd.Contains(" ") ? cmd.Split(' ')[1] + " --version" : "--version";
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.RedirectStandardError = true;
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.CreateNoWindow = true;
                    p.Start();
                    p.WaitForExit(3000);
                    if (p.ExitCode == 0) return cmd;
                }
                catch { }
            }

            string localApp = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string pyDir = Path.Combine(localApp, "Programs", "Python");
            if (Directory.Exists(pyDir))
            {
                foreach (var dir in Directory.GetDirectories(pyDir))
                {
                    string candidate = Path.Combine(dir, "python.exe");
                    if (File.Exists(candidate)) return candidate;
                }
            }

            return null;
        }

        private void RunCommand(string fileName, string args)
        {
            AppendLog("> " + fileName + " " + args);
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = args,
                WorkingDirectory = installDir,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (var p = new Process { StartInfo = psi })
            {
                p.OutputDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) AppendLog(e.Data); };
                p.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) AppendLog(e.Data); };
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                p.WaitForExit();
                if (p.ExitCode != 0)
                {
                    AppendLog(string.Format("[Aviso] Código de retorno: {0}", p.ExitCode));
                }
            }
        }

        private void CreateShortcuts()
        {
            try
            {
                string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string lnkPath = Path.Combine(desktop, "Central DGS.lnk");
                string vbsPath = Path.Combine(installDir, "INICIAR_CENTRAL_DGS.vbs");
                string iconPath = Path.Combine(installDir, "frontend", "static", "icon.ico");

                Type shellType = Type.GetTypeFromProgID("WScript.Shell");
                dynamic shell = Activator.CreateInstance(shellType);
                dynamic shortcut = shell.CreateShortcut(lnkPath);
                
                shortcut.TargetPath = "wscript.exe";
                shortcut.Arguments = string.Format("\"{0}\"", vbsPath);
                shortcut.WorkingDirectory = installDir;
                shortcut.Description = "Central DGS - Comunidade Digital Supply";
                if (File.Exists(iconPath))
                {
                    shortcut.IconLocation = iconPath + ",0";
                }
                shortcut.Save();
            }
            catch (Exception ex)
            {
                AppendLog("[Aviso ao criar atalho] " + ex.Message);
            }
        }

        private void LaunchCentral()
        {
            AppendLog("Iniciando Central DGS...");
            try
            {
                string vbs = Path.Combine(installDir, "INICIAR_CENTRAL_DGS.vbs");
                if (File.Exists(vbs))
                {
                    Process.Start("wscript.exe", string.Format("\"{0}\"", vbs));
                }
                else
                {
                    string venvPython = Path.Combine(installDir, ".venv", "Scripts", "python.exe");
                    string pyCmd = File.Exists(venvPython) ? venvPython : "python";
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = pyCmd,
                        Arguments = "run.py",
                        WorkingDirectory = installDir,
                        UseShellExecute = true
                    });
                }

                AppendLog("Central DGS iniciada! Abrindo painel visual no seu navegador...");
                WindowState = WindowState.Minimized;
                Task.Delay(2500).ContinueWith(_ =>
                {
                    Dispatcher.Invoke(new Action(() => Close()));
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao iniciar Central DGS: " + ex.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
