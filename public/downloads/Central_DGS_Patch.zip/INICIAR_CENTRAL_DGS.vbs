Option Explicit
On Error Resume Next

Dim WshShell, fso, currentDir, venvPython, sysPython, runPy, cmd, ret

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Diretório atual onde o script VBS reside
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = currentDir

venvPython = currentDir & "\.venv\Scripts\python.exe"
runPy = currentDir & "\run.py"

' 1. Verifica se run.py existe na pasta
If Not fso.FileExists(runPy) Then
    MsgBox "Arquivo principal 'run.py' não foi encontrado na pasta:" & vbCrLf & currentDir & vbCrLf & vbCrLf & "Por favor reinstale a Central DGS usando o Launcher_Central_DGS.exe.", 16, "Central DGS - Arquivo Ausente"
    WScript.Quit 1
End If

' 2. Determina o executável do Python (prioriza .venv local)
If fso.FileExists(venvPython) Then
    cmd = """" & venvPython & """ """ & runPy & """"
Else
    cmd = "python """ & runPy & """"
End If

' 3. Executa o comando em segundo plano (0 = oculto, False = não bloqueia)
ret = WshShell.Run(cmd, 0, False)

If Err.Number <> 0 Then
    MsgBox "Erro ao inicializar Central DGS: " & Err.Description & vbCrLf & vbCrLf & "Comando: " & cmd, 16, "Central DGS"
    Err.Clear
End If
