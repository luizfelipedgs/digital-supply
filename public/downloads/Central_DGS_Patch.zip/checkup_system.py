import requests, json

print("=== 1. CHECKUP DE ROTAS API ===")
base = "http://127.0.0.1:8787"

routes = [
    ("/api/stats", "GET"),
    ("/api/accounts", "GET"),
    ("/api/videos", "GET"),
    ("/api/queue", "GET"),
    ("/api/meta/oauth/login", "GET"),
    ("/api/tiktok/oauth/login", "GET"),
    ("/api/engine/status", "GET")
]

for r, method in routes:
    try:
        res = requests.request(method, base + r, timeout=5)
        print(f"{method} {r} -> Status {res.status_code}")
    except Exception as e:
        print(f"{method} {r} -> ERRO: {e}")

print("\n=== 2. CHECKUP DE CONTAS CONECTADAS ===")
accs = requests.get(base + "/api/accounts").json()
print(f"Total de contas cadastradas: {len(accs)}")
for a in accs:
    print(f"ID: {a['id']} | Plataforma: {a['platform']} | User: {a['username']} | Nome: {a['name']} | Tipo: {a.get('connection_type')}")

print("\n=== 3. CHECKUP DE ARQUIVOS ESTATICOS E FRONTEND ===")
home = requests.get(base + "/", timeout=5)
print(f"HTTP / -> {home.status_code} | Bytes: {len(home.text)}")
has_engine_card = 'id="btn-toggle-engine"' in home.text
has_shutdown_btn = 'Encerrar Central DGS' in home.text
has_tiktok_oauth = 'btn-tiktok-oauth-login' in home.text
has_meta_oauth = 'btn-meta-oauth' in home.text

print(f"Card do Motor retirado da tela: {not has_engine_card}")
print(f"Botao Encerrar Central DGS retirado: {not has_shutdown_btn}")
print(f"Botao TikTok API Oficial presente: {has_tiktok_oauth}")
print(f"Botao Meta API Oficial presente: {has_meta_oauth}")
