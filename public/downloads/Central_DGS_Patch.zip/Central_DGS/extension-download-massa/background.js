/**
 * DGS - Download em Massa
 * Background Service Worker (Manifest V3)
 * Gerencia a fila de downloads em .ZIP e downloads individuais na grade
 */

// Permite abrir o Side Panel com um clique no ícone da extensão
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error("Erro ao configurar comportamento do side panel:", error));

// Estado da Fila de Downloads
const queueState = {
  active: false,
  items: [],
  currentIndex: 0,
  total: 0,
  successCount: 0,
  failCount: 0,
  cancelled: false,
};

// --- GERADOR DE ARQUIVO .ZIP PADRÃO EM JS PURO (STORE METHOD - ZERO COMPRESSÃO / ALTA VELOCIDADE) ---
function createZipBlob(files) {
  // Tabela CRC32 padrão IEEE 802.3
  const crcTable = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[i] = c >>> 0;
  }

  function crc32(buf) {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  const now = new Date();
  const dosTime =
    ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xffff;
  const dosDate =
    (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xffff;

  const encoder = new TextEncoder();
  const fileRecords = [];
  const parts = [];
  let currentOffset = 0;

  for (const file of files) {
    const rawData = file.data instanceof Uint8Array ? file.data : new Uint8Array(file.data);
    const nameBytes = encoder.encode(file.name);
    const fileCrc = crc32(rawData);
    const size = rawData.length;

    // Cabeçalho de arquivo local (30 bytes + tamanho do nome)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // PK\x03\x04
    lv.setUint16(4, 20, true); // Versão necessária: 2.0
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // Compressão: STORE (0)
    lv.setUint16(10, dosTime, true);
    lv.setUint16(12, dosDate, true);
    lv.setUint32(14, fileCrc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true); // extra field length
    localHeader.set(nameBytes, 30);

    parts.push(localHeader);
    parts.push(rawData);

    fileRecords.push({
      nameBytes,
      crc: fileCrc,
      size,
      offset: currentOffset,
    });

    currentOffset += localHeader.length + rawData.length;
  }

  // Diretório Central
  const centralDirStart = currentOffset;
  let centralDirSize = 0;

  for (const rec of fileRecords) {
    const cdHeader = new Uint8Array(46 + rec.nameBytes.length);
    const cv = new DataView(cdHeader.buffer);
    cv.setUint32(0, 0x02014b50, true); // PK\x01\x02
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true); // UTF-8
    cv.setUint16(10, 0, true); // STORE
    cv.setUint16(12, dosTime, true);
    cv.setUint16(14, dosDate, true);
    cv.setUint32(16, rec.crc, true);
    cv.setUint32(20, rec.size, true);
    cv.setUint32(24, rec.size, true);
    cv.setUint16(28, rec.nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, rec.offset, true);
    cdHeader.set(rec.nameBytes, 46);

    parts.push(cdHeader);
    centralDirSize += cdHeader.length;
  }

  // End of Central Directory Record (22 bytes)
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true); // PK\x05\x06
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, fileRecords.length, true);
  ev.setUint16(10, fileRecords.length, true);
  ev.setUint32(12, centralDirSize, true);
  ev.setUint32(16, centralDirStart, true);
  ev.setUint16(20, 0, true);
  parts.push(eocd);

  return new Blob(parts, { type: "application/zip" });
}

// --- LISTENER DE MENSAGENS (SIDE PANEL E CONTENT SCRIPT) ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 1. Download em Lote (Gera arquivo .ZIP único)
  if (message.action === "START_BATCH_DOWNLOAD") {
    const rawItems = Array.isArray(message.items) ? message.items : [];
    const safeItems = rawItems.slice(0, 100);

    if (safeItems.length === 0) {
      sendResponse({ success: false, message: "Nenhum vídeo fornecido." });
      return true;
    }

    startZipDownloadQueue(safeItems);
    sendResponse({ success: true, count: safeItems.length });
    return true;
  }

  // 2. Download Individual (Direto no clique do botão da grade do perfil)
  if (message.action === "START_SINGLE_DOWNLOAD") {
    const item = message.video || message.item;
    if (!item) {
      sendResponse({ success: false, error: "Vídeo não informado." });
      return true;
    }

    (async () => {
      try {
        if (!item.videoUrl) {
          item.videoUrl = await resolveDirectVideoUrl(item);
        }
        if (!item.videoUrl) {
          throw new Error("Não foi possível obter o link do arquivo de vídeo.");
        }
        const downloadId = await executeSingleDownload(item);
        sendResponse({ success: true, downloadId });
      } catch (err) {
        console.error("Erro no download individual:", err);
        sendResponse({ success: false, error: err.message || "Erro no download." });
      }
    })();

    return true; // Mantém canal assíncrono aberto
  }

  // 3. Cancelamento do Lote
  if (message.action === "CANCEL_BATCH_DOWNLOAD") {
    queueState.cancelled = true;
    queueState.active = false;
    broadcastProgress({ status: "cancelled", message: "Download cancelado pelo usuário." });
    sendResponse({ success: true });
    return true;
  }

  // 4. Status atual da fila
  if (message.action === "GET_DOWNLOAD_STATUS") {
    sendResponse({
      active: queueState.active,
      currentIndex: queueState.currentIndex,
      total: queueState.total,
      successCount: queueState.successCount,
      failCount: queueState.failCount,
    });
    return true;
  }
});

// --- EXECUÇÃO DA FILA COM EMPACOTAMENTO FINAL EM .ZIP ---
async function startZipDownloadQueue(items) {
  if (queueState.active) {
    console.warn("Fila de download já em execução.");
    return;
  }

  queueState.active = true;
  queueState.cancelled = false;
  queueState.items = items;
  queueState.total = items.length;
  queueState.currentIndex = 0;
  queueState.successCount = 0;
  queueState.failCount = 0;

  broadcastProgress({
    status: "started",
    current: 0,
    total: queueState.total,
    percentage: 0,
  });

  const downloadedFiles = [];
  const DELAY_MS = 600; // Intervalo seguro entre requisições

  for (let i = 0; i < items.length; i++) {
    if (queueState.cancelled) {
      console.log("Download cancelado.");
      break;
    }

    queueState.currentIndex = i + 1;
    const item = items[i];

    // Se o item não tiver a URL direta de download (.mp4), tenta resolver
    if (!item.videoUrl) {
      broadcastProgress({
        status: "resolving",
        current: queueState.currentIndex,
        total: queueState.total,
        percentage: Math.round(((i + 0.3) / queueState.total) * 90),
        currentAuthor: item.author || "perfil",
        currentPlatform: item.platform || "video",
      });

      try {
        item.videoUrl = await resolveDirectVideoUrl(item);
      } catch (e) {
        console.warn(`Falha ao resolver URL do vídeo ${item.id}:`, e);
      }
    }

    broadcastProgress({
      status: "downloading",
      current: queueState.currentIndex,
      total: queueState.total,
      percentage: Math.round(((i + 0.8) / queueState.total) * 90),
      currentAuthor: item.author || "perfil",
      currentPlatform: item.platform || "video",
    });

    try {
      if (!item.videoUrl) throw new Error("Não foi possível obter o link do arquivo de vídeo.");

      // Baixa o binário do vídeo diretamente via fetch como ArrayBuffer
      const resp = await fetch(item.videoUrl);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const arrayBuf = await resp.arrayBuffer();

      const seq = String(queueState.successCount + 1).padStart(2, "0");
      const cleanAuthor = (item.author || "perfil").replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 25);
      const cleanId = (item.code || item.rawId || item.id || Date.now().toString()).replace(/[^a-zA-Z0-9_\-]/g, "_");
      const filenameInZip = `${seq}_${cleanAuthor}_${cleanId}.mp4`;

      downloadedFiles.push({
        name: filenameInZip,
        data: new Uint8Array(arrayBuf),
      });

      queueState.successCount++;
    } catch (err) {
      console.error(`Falha ao baixar vídeo ${item.id}:`, err);
      queueState.failCount++;
    }

    if (i < items.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, DELAY_MS));
    }
  }

  // SE NÃO HOUVER VÍDEOS BAIXADOS COM SUCESSO
  if (downloadedFiles.length === 0) {
    queueState.active = false;
    broadcastProgress({
      status: "completed",
      current: queueState.total,
      total: queueState.total,
      percentage: 100,
      successCount: 0,
      failCount: queueState.failCount,
    });
    return;
  }

  // ETAPA DE EMPACOTAMENTO NO ARQUIVO .ZIP
  broadcastProgress({
    status: "zipping",
    current: downloadedFiles.length,
    total: queueState.total,
    percentage: 95,
  });

  try {
    // Adiciona documento informativo dentro do ZIP
    const summaryText = [
      "==================================================",
      "   DGS - DOWNLOAD EM MASSA (LOTE OFICIAL)",
      "==================================================",
      `Data de Download: ${new Date().toLocaleString("pt-BR")}`,
      `Plataforma:       ${items[0]?.platform || "social"}`,
      `Perfil:           @${items[0]?.author || "perfil"}`,
      `Vídeos no Lote:   ${downloadedFiles.length}`,
      `Total Solicitado: ${queueState.total}`,
      `Falhas:           ${queueState.failCount}`,
      "==================================================",
      "Arquivos incluídos neste pacote:",
      ...downloadedFiles.map((f) => ` - ${f.name}`),
      "==================================================",
    ].join("\r\n");

    downloadedFiles.unshift({
      name: "00_LEIA-ME_LOTE_DGS.txt",
      data: new TextEncoder().encode(summaryText),
    });

    const zipBlob = createZipBlob(downloadedFiles);
    const blobUrl = URL.createObjectURL(zipBlob);

    const mainAuthor = (items[0]?.author || "perfil").replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 25);
    const platform = items[0]?.platform || "social";
    const zipFilename = `DGS_Downloads/DGS_${platform}_${mainAuthor}_lote_${downloadedFiles.length - 1}_videos.zip`;

    chrome.downloads.download(
      {
        url: blobUrl,
        filename: zipFilename,
        conflictAction: "uniquify",
        saveAs: false,
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          console.error("Erro ao salvar ZIP via Chrome:", chrome.runtime.lastError);
        }
        // Libera a URL do Blob após 2 minutos
        setTimeout(() => {
          try {
            URL.revokeObjectURL(blobUrl);
          } catch (e) {}
        }, 120000);
      }
    );
  } catch (err) {
    console.error("Erro ao gerar ZIP dos vídeos:", err);
  }

  queueState.active = false;
  broadcastProgress({
    status: "completed",
    current: queueState.total,
    total: queueState.total,
    percentage: 100,
    successCount: downloadedFiles.length - 1,
    failCount: queueState.failCount,
  });
}

// --- RESOLUÇÃO DINÂMICA DE LINKS HD PARA POSTS DO DOM ---
async function resolveDirectVideoUrl(item) {
  if (item.videoUrl) return item.videoUrl;

  // Instagram: Extrai link direto do Reel
  if (item.platform === "instagram" && item.code) {
    try {
      const pageUrl = `https://www.instagram.com/reel/${item.code}/`;
      const res = await fetch(pageUrl, {
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      });
      const html = await res.text();

      // Padrão 1: video_versions
      const matchVersions = html.match(/"video_versions":\s*(\[[^\]]+\])/);
      if (matchVersions) {
        try {
          const list = JSON.parse(matchVersions[1]);
          if (Array.isArray(list) && list.length > 0 && list[0].url) {
            return list[0].url;
          }
        } catch (e) {}
      }

      // Padrão 2: link mp4 do CDN fbcdn
      const matchMp4 = html.match(/(https:[^"'\s<>\\]+\.mp4[^"'\s<>\\]*)/);
      if (matchMp4) {
        return matchMp4[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
      }
    } catch (err) {
      console.error("Erro ao resolver vídeo no Instagram:", err);
    }
  }

  // TikTok: Extrai link direto do vídeo
  if (item.platform === "tiktok" && item.postUrl) {
    try {
      const res = await fetch(item.postUrl);
      const html = await res.text();
      const matchPlayAddr = html.match(/"playAddr":\s*"([^"]+)"/);
      if (matchPlayAddr) {
        return matchPlayAddr[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/");
      }
    } catch (e) {}
  }

  return null;
}

// --- DOWNLOAD INDIVIDUAL (SALVA COMO .MP4 SEPARADO) ---
function executeSingleDownload(item) {
  return new Promise((resolve, reject) => {
    if (!item.videoUrl) {
      return reject(new Error("URL do vídeo ausente."));
    }

    const cleanAuthor = (item.author || "perfil").replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 30);
    const cleanId = (item.code || item.rawId || item.id || Date.now().toString()).replace(/[^a-zA-Z0-9_\-]/g, "_");
    const platform = item.platform || "social";

    const filename = `DGS_Downloads/${platform}_${cleanAuthor}/${cleanId}.mp4`;

    chrome.downloads.download(
      {
        url: item.videoUrl,
        filename: filename,
        conflictAction: "uniquify",
        saveAs: false,
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!downloadId) {
          reject(new Error("ID de download não retornado pelo Chrome."));
        } else {
          resolve(downloadId);
        }
      }
    );
  });
}

function broadcastProgress(data) {
  chrome.runtime.sendMessage({
    action: "DOWNLOAD_PROGRESS_UPDATE",
    payload: data,
  }).catch(() => {
    // Side panel pode estar fechado
  });
}
