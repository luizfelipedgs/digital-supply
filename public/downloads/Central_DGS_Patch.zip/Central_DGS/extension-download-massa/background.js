/**
 * DGS - Download em Massa
 * Background Service Worker (Manifest V3)
 * Gerencia a fila de downloads com resolução dinâmica de URLs e delay seguro
 */

// Permite abrir o Side Panel com um clique no ícone da extensão
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error("Erro ao configurar comportamento do side panel:", error));

// Estado da Fila de Downloads
const queueState = {
  active: false,
  items: [],
  currentIndex: 0,
  total: 0,
  successCount: 0,
  failCount: 0,
  cancelled: false,
};

// Listener para mensagens de controle vindas do Side Panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "START_BATCH_DOWNLOAD") {
    const rawItems = Array.isArray(message.items) ? message.items : [];
    // Trava de segurança: limita estritamente em 100 itens
    const safeItems = rawItems.slice(0, 100);

    if (safeItems.length === 0) {
      sendResponse({ success: false, message: "Nenhum vídeo fornecido." });
      return true;
    }

    startDownloadQueue(safeItems);
    sendResponse({ success: true, count: safeItems.length });
    return true;
  }

  if (message.action === "CANCEL_BATCH_DOWNLOAD") {
    queueState.cancelled = true;
    queueState.active = false;
    broadcastProgress({ status: "cancelled", message: "Download cancelado pelo usuário." });
    sendResponse({ success: true });
    return true;
  }

  if (message.action === "GET_DOWNLOAD_STATUS") {
    sendResponse({
      active: queueState.active,
      currentIndex: queueState.currentIndex,
      total: queueState.total,
      successCount: queueState.successCount,
      failCount: queueState.failCount,
    });
    return true;
  }
});

async function startDownloadQueue(items) {
  if (queueState.active) {
    console.warn("Fila de download já em execução.");
    return;
  }

  queueState.active = true;
  queueState.cancelled = false;
  queueState.items = items;
  queueState.total = items.length;
  queueState.currentIndex = 0;
  queueState.successCount = 0;
  queueState.failCount = 0;

  broadcastProgress({
    status: "started",
    current: 0,
    total: queueState.total,
    percentage: 0,
  });

  const DELAY_MS = 1400; // Intervalo de 1.4s entre downloads

  for (let i = 0; i < items.length; i++) {
    if (queueState.cancelled) {
      console.log("Download cancelado.");
      break;
    }

    queueState.currentIndex = i + 1;
    const item = items[i];

    // Se o item não tiver a URL direta de download (.mp4), tenta resolver
    if (!item.videoUrl) {
      broadcastProgress({
        status: "resolving",
        current: queueState.currentIndex,
        total: queueState.total,
        percentage: Math.round(((i + 1) / queueState.total) * 100),
        currentAuthor: item.author || "perfil",
        currentPlatform: item.platform || "video",
      });

      try {
        item.videoUrl = await resolveDirectVideoUrl(item);
      } catch (e) {
        console.warn(`Falha ao resolver URL do vídeo ${item.id}:`, e);
      }
    }

    broadcastProgress({
      status: "downloading",
      current: queueState.currentIndex,
      total: queueState.total,
      percentage: Math.round(((i + 1) / queueState.total) * 100),
      currentAuthor: item.author || "perfil",
      currentPlatform: item.platform || "video",
    });

    try {
      if (!item.videoUrl) throw new Error("Não foi possível obter o link do arquivo de vídeo.");
      await executeSingleDownload(item);
      queueState.successCount++;
    } catch (err) {
      console.error(`Falha ao baixar item ${item.id}:`, err);
      queueState.failCount++;
    }

    // Intervalo de segurança anti-bloqueio entre requisições
    if (i < items.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, DELAY_MS));
    }
  }

  queueState.active = false;
  broadcastProgress({
    status: "completed",
    current: queueState.total,
    total: queueState.total,
    percentage: 100,
    successCount: queueState.successCount,
    failCount: queueState.failCount,
  });
}

// Resolução dinâmica de links de vídeo para itens capturados via DOM
async function resolveDirectVideoUrl(item) {
  if (item.videoUrl) return item.videoUrl;

  // Instagram: Busca a página do reel e extrai a URL de video_versions ou CDN
  if (item.platform === "instagram" && item.code) {
    try {
      const pageUrl = `https://www.instagram.com/reel/${item.code}/`;
      const res = await fetch(pageUrl, {
        headers: {
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
      });
      const html = await res.text();

      // Padrão 1: video_versions
      const matchVersions = html.match(/"video_versions":\s*(\[[^\]]+\])/);
      if (matchVersions) {
        try {
          const list = JSON.parse(matchVersions[1]);
          if (Array.isArray(list) && list.length > 0 && list[0].url) {
            return list[0].url;
          }
        } catch (e) {}
      }

      // Padrão 2: link mp4 do CDN fbcdn
      const matchMp4 = html.match(/(https:[^"'\s<>\\]+\.mp4[^"'\s<>\\]*)/);
      if (matchMp4) {
        return matchMp4[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/").replace(/&amp;/g, "&");
      }
    } catch (err) {
      console.error("Erro ao resolver vídeo no Instagram:", err);
    }
  }

  // TikTok: Busca a página do vídeo se necessário
  if (item.platform === "tiktok" && item.postUrl) {
    try {
      const res = await fetch(item.postUrl);
      const html = await res.text();
      const matchPlayAddr = html.match(/"playAddr":\s*"([^"]+)"/);
      if (matchPlayAddr) {
        return matchPlayAddr[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/");
      }
    } catch (e) {}
  }

  return null;
}

function executeSingleDownload(item) {
  return new Promise((resolve, reject) => {
    if (!item.videoUrl) {
      return reject(new Error("URL do vídeo ausente."));
    }

    const cleanAuthor = (item.author || "perfil").replace(/[^a-zA-Z0-9_\-]/g, "_").substring(0, 30);
    const cleanId = (item.code || item.rawId || item.id || Date.now().toString()).replace(/[^a-zA-Z0-9_\-]/g, "_");
    const platform = item.platform || "social";

    // Pasta organizada: DGS_Downloads/{plataforma}_{autor}/{id}.mp4
    const filename = `DGS_Downloads/${platform}_${cleanAuthor}/${cleanId}.mp4`;

    chrome.downloads.download(
      {
        url: item.videoUrl,
        filename: filename,
        conflictAction: "uniquify",
        saveAs: false,
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!downloadId) {
          reject(new Error("ID de download não retornado pelo Chrome."));
        } else {
          resolve(downloadId);
        }
      }
    );
  });
}

function broadcastProgress(data) {
  chrome.runtime.sendMessage({
    action: "DOWNLOAD_PROGRESS_UPDATE",
    payload: data,
  }).catch(() => {
    // Side panel pode estar fechado
  });
}
