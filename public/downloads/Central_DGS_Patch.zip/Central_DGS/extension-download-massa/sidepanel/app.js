/**
 * DGS - Download em Massa
 * Side Panel Controller (app.js)
 * Gerencia a interface, filtros manuais e envio da fila de downloads com limite rígido de 50 itens
 */

const MAX_BATCH_LIMIT = 100;

// Estado local da UI
let rawVideos = [];
let filteredVideos = [];
let selectedIds = new Set();
let activeTabId = null;
let currentPlatform = "unknown";

// Elementos da UI
const bufferCountEl = document.getElementById("buffer-count");
const platformLabelEl = document.getElementById("platform-label");
const tabStatusPillEl = document.getElementById("tab-status-pill");
const filteredCountEl = document.getElementById("filtered-count");
const videosGridEl = document.getElementById("videos-grid");
const btnStartDownload = document.getElementById("btn-start-download");
const btnDownloadLabel = document.getElementById("btn-download-label");

const progressBox = document.getElementById("progress-box");
const progressStatusText = document.getElementById("progress-status-text");
const progressPercentText = document.getElementById("progress-percent-text");
const progressBarFill = document.getElementById("progress-bar-fill");
const btnCancelDownload = document.getElementById("btn-cancel-download");

// Inputs de Filtro
const inputViews = document.getElementById("filter-views");
const inputLikes = document.getElementById("filter-likes");
const inputKeyword = document.getElementById("filter-keyword");
const selectSort = document.getElementById("filter-sort");

// --- INICIALIZAÇÃO ---
document.addEventListener("DOMContentLoaded", async () => {
  setupEventListeners();
  await detectActiveTab();
  checkOngoingDownloadStatus();

  // Escuta troca de abas no Chrome para sincronizar com a aba em foco
  chrome.tabs.onActivated.addListener(async () => {
    await detectActiveTab();
  });

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tabId === activeTabId && changeInfo.status === "complete") {
      detectActiveTab();
    }
  });
});

async function detectActiveTab() {
  try {
    // 1. Tenta pegar a aba ativa na janela
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const activeTab = tabs[0];

    if (
      activeTab &&
      activeTab.url &&
      (activeTab.url.includes("instagram.com") || activeTab.url.includes("tiktok.com"))
    ) {
      setTargetTab(activeTab);
      return;
    }

    // 2. Fallback inteligente: procura qualquer aba aberta com Instagram ou TikTok
    const socialTabs = await chrome.tabs.query({
      url: ["*://*.instagram.com/*", "*://*.tiktok.com/*"],
    });

    if (socialTabs && socialTabs.length > 0) {
      setTargetTab(socialTabs[0]);
      return;
    }

    currentPlatform = "other";
    platformLabelEl.innerText = "Navegue para TikTok/IG";
    tabStatusPillEl.classList.remove("active");
  } catch (err) {
    console.error("Erro ao detectar aba:", err);
  }
}

function setTargetTab(tab) {
  if (!tab || !tab.id || !tab.url) return;

  activeTabId = tab.id;
  const url = tab.url.toLowerCase();

  if (url.includes("tiktok.com")) {
    currentPlatform = "tiktok";
    platformLabelEl.innerText = "TikTok Conectado";
    tabStatusPillEl.classList.add("active");
  } else if (url.includes("instagram.com")) {
    currentPlatform = "instagram";
    platformLabelEl.innerText = "Instagram Conectado";
    tabStatusPillEl.classList.add("active");
  }

  // Solicita vídeos com auto-injeção de fallback se o content script ainda não estiver ativo
  requestVideosWithAutoInject();
}

function requestVideosWithAutoInject() {
  if (!activeTabId) return;

  chrome.tabs.sendMessage(activeTabId, { action: "GET_CACHED_VIDEOS" }, async (response) => {
    if (chrome.runtime.lastError || !response) {
      // Content script não respondeu (página já estava aberta antes da extensão ser instalada)
      console.log("Injetando content script na aba ativa...");
      try {
        await chrome.scripting.executeScript({
          target: { tabId: activeTabId },
          files: ["content.js"],
        });
        await chrome.scripting.executeScript({
          target: { tabId: activeTabId },
          world: "MAIN",
          files: ["injected.js"],
        });

        // Tenta novamente após injeção
        setTimeout(() => {
          chrome.tabs.sendMessage(activeTabId, { action: "GET_CACHED_VIDEOS" }, (res2) => {
            if (res2 && res2.videos) absorbVideos(res2.videos);
          });
        }, 500);
      } catch (e) {
        console.warn("Não foi possível injetar na aba:", e);
      }
      return;
    }

    if (response.videos) {
      absorbVideos(response.videos);
    }
  });
}

// Absorve novos vídeos garantindo unicidade por ID
function absorbVideos(videoList) {
  if (!Array.isArray(videoList) || videoList.length === 0) return;

  let added = 0;
  videoList.forEach((v) => {
    if (!v || !v.id) return;
    const existingIndex = rawVideos.findIndex((e) => e.id === v.id || (e.code && e.code === v.code));
    if (existingIndex >= 0) {
      // Atualiza métricas se as novas forem mais detalhadas
      const existing = rawVideos[existingIndex];
      if (v.metrics) {
        if (v.metrics.views && !existing.metrics.views) existing.metrics.views = v.metrics.views;
        if (v.metrics.likes && !existing.metrics.likes) existing.metrics.likes = v.metrics.likes;
      }
      if (v.videoUrl && !existing.videoUrl) existing.videoUrl = v.videoUrl;
      if (v.thumbnailUrl && !existing.thumbnailUrl) existing.thumbnailUrl = v.thumbnailUrl;
    } else {
      rawVideos.push(v);
      added++;
    }
  });

  bufferCountEl.innerText = rawVideos.length;

  // Aplica filtros automaticamente
  applyFilters();
}

// --- ESCUTA DE MENSAGENS EM TEMPO REAL ---
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "VIDEOS_CAPTURED") {
    if (message.allVideos) absorbVideos(message.allVideos);
    else if (message.newVideos) absorbVideos(message.newVideos);
  }

  if (message.action === "DOWNLOAD_PROGRESS_UPDATE") {
    handleProgressUpdate(message.payload);
  }
});

// --- LÓGICA DE FILTRAGEM ---
function applyFilters() {
  const minViews = parseInt(inputViews.value) || 0;
  const minLikes = parseInt(inputLikes.value) || 0;
  const keyword = inputKeyword.value.toLowerCase().trim();
  const sortBy = selectSort.value;

  filteredVideos = rawVideos.filter((v) => {
    const views = v.metrics?.views || 0;
    const likes = v.metrics?.likes || 0;

    // Se o usuário não definiu corte de views (valor 0), não filtra por views
    const matchViews = minViews === 0 || views >= minViews;
    const matchLikes = minLikes === 0 || likes >= minLikes;

    let matchText = true;
    if (keyword) {
      const caption = (v.caption || "").toLowerCase();
      const inCaption = caption.includes(keyword);
      const inHashtags = (v.hashtags || []).some((h) => h.includes(keyword));
      const inAuthor = (v.author || "").toLowerCase().includes(keyword);
      matchText = inCaption || inHashtags || inAuthor;
    }

    return matchViews && matchLikes && matchText;
  });

  // Ordenação
  filteredVideos.sort((a, b) => {
    if (sortBy === "views") {
      return (b.metrics?.views || 0) - (a.metrics?.views || 0);
    }
    if (sortBy === "likes") {
      return (b.metrics?.likes || 0) - (a.metrics?.likes || 0);
    }
    if (sortBy === "engagement") {
      const engA = (a.metrics?.likes || 0) / Math.max(a.metrics?.views || 1, 1);
      const engB = (b.metrics?.likes || 0) / Math.max(b.metrics?.views || 1, 1);
      return engB - engA;
    }
    return (b.createdAt || 0) - (a.createdAt || 0);
  });

  // TRAVA DE SEGURANÇA MÁXIMA: 50 itens
  filteredVideos = filteredVideos.slice(0, MAX_BATCH_LIMIT);

  // Seleciona todos os itens filtrados automaticamente (até 50)
  selectedIds.clear();
  filteredVideos.forEach((v) => selectedIds.add(v.id));

  renderVideoGrid();
  updateDownloadButton();
}

// --- RENDERIZAÇÃO DA GRADE ---
function renderVideoGrid() {
  filteredCountEl.innerText = filteredVideos.length;
  videosGridEl.innerHTML = "";

  if (filteredVideos.length === 0) {
    const isBufferEmpty = rawVideos.length === 0;
    videosGridEl.innerHTML = `
      <div class="empty-state">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
        <p class="empty-title">${isBufferEmpty ? "Nenhum vídeo detectado ainda" : "Nenhum vídeo com esses filtros"}</p>
        <p class="empty-desc">${
          isBufferEmpty
            ? "Clique em 'Escanear' acima ou role o perfil para baixo no navegador para carregar os vídeos."
            : "Tente reduzir o filtro de visualizações para 0 ou limpar a palavra-chave."
        }</p>
      </div>
    `;
    return;
  }

  filteredVideos.forEach((video) => {
    const isSelected = selectedIds.has(video.id);
    const card = document.createElement("div");
    card.className = `video-card ${isSelected ? "selected" : ""}`;
    card.dataset.id = video.id;

    const viewsFmt = video.metrics?.views ? formatMetric(video.metrics.views) : "—";
    const likesFmt = video.metrics?.likes ? formatMetric(video.metrics.likes) : "—";
    const fallbackThumb = "data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22200%22%20height%3D%22260%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20200%20260%22%20preserveAspectRatio%3D%22none%22%3E%3Crect%20width%3D%22200%22%20height%3D%22260%22%20fill%3D%22%23111%22%2F%3E%3Ctext%20x%3D%2270%22%20y%3D%22135%22%20fill%3D%22%23666%22%20font-family%3Asans-serif%20font-size%3D%2214%22%3EDGS%3C%2Ftext%3E%3C%2Fsvg%3E";

    card.innerHTML = `
      <div class="card-thumb-wrap">
        <input type="checkbox" class="card-checkbox" ${isSelected ? "checked" : ""}>
        <span class="platform-tag ${video.platform}">${video.platform}</span>
        <img class="card-thumb" src="${video.thumbnailUrl || fallbackThumb}" alt="Thumb" loading="lazy">
        <div class="metrics-overlay">
          <span class="metric-item views">👁️ ${viewsFmt}</span>
          <span class="metric-item likes">❤️ ${likesFmt}</span>
        </div>
      </div>
      <div class="card-body">
        <span class="card-author">@${escapeHtml(video.author || "perfil")}</span>
        <p class="card-caption">${escapeHtml(video.caption || "Reel / Vídeo")}</p>
      </div>
    `;

    // Tratamento de fallback seguro de thumbnail sem violar CSP
    const thumbImg = card.querySelector(".card-thumb");
    if (thumbImg) {
      thumbImg.addEventListener("error", () => {
        thumbImg.src = fallbackThumb;
      });
    }

    // Clique no card alterna seleção
    card.addEventListener("click", (e) => {
      if (e.target.tagName.toLowerCase() === "input") return;
      toggleCardSelection(video.id, card);
    });

    const checkbox = card.querySelector(".card-checkbox");
    checkbox.addEventListener("change", (e) => {
      e.stopPropagation();
      toggleCardSelection(video.id, card, checkbox.checked);
    });

    videosGridEl.appendChild(card);
  });
}

function toggleCardSelection(id, cardEl, forceState) {
  const currentState = selectedIds.has(id);
  const newState = typeof forceState === "boolean" ? forceState : !currentState;

  if (newState) {
    if (selectedIds.size >= MAX_BATCH_LIMIT) {
      alert(`O limite máximo de segurança por lote é de ${MAX_BATCH_LIMIT} vídeos.`);
      const cb = cardEl.querySelector(".card-checkbox");
      if (cb) cb.checked = false;
      return;
    }
    selectedIds.add(id);
    cardEl.classList.add("selected");
  } else {
    selectedIds.delete(id);
    cardEl.classList.remove("selected");
  }

  const cb = cardEl.querySelector(".card-checkbox");
  if (cb) cb.checked = newState;

  updateDownloadButton();
}

function updateDownloadButton() {
  const count = selectedIds.size;
  btnStartDownload.disabled = count === 0;
  btnDownloadLabel.innerText = `Baixar Selecionados (${count}/${MAX_BATCH_LIMIT})`;
}

// --- EVENT LISTENERS DA UI ---
function setupEventListeners() {
  document.getElementById("btn-apply-filters").addEventListener("click", () => {
    applyFilters();
  });

  document.getElementById("btn-reset-filters").addEventListener("click", () => {
    inputViews.value = "0";
    inputLikes.value = "0";
    inputKeyword.value = "";
    selectSort.value = "views";
    applyFilters();
  });

  document.getElementById("btn-select-all").addEventListener("click", () => {
    selectedIds.clear();
    const cards = document.querySelectorAll(".video-card");
    cards.forEach((card) => {
      const id = card.dataset.id;
      if (selectedIds.size < MAX_BATCH_LIMIT) {
        selectedIds.add(id);
        card.classList.add("selected");
        const cb = card.querySelector(".card-checkbox");
        if (cb) cb.checked = true;
      }
    });
    updateDownloadButton();
  });

  document.getElementById("btn-unselect-all").addEventListener("click", () => {
    selectedIds.clear();
    const cards = document.querySelectorAll(".video-card");
    cards.forEach((card) => {
      card.classList.remove("selected");
      const cb = card.querySelector(".card-checkbox");
      if (cb) cb.checked = false;
    });
    updateDownloadButton();
  });

  // BOTÃO ESCANEAR MANUAL
  const btnScan = document.getElementById("btn-force-scan");
  btnScan.addEventListener("click", async () => {
    btnScan.disabled = true;
    btnScan.innerText = "Escaneando...";

    try {
      if (!activeTabId) await detectActiveTab();

      chrome.tabs.sendMessage(activeTabId, { action: "FORCE_DOM_SCAN" }, async (response) => {
        if (chrome.runtime.lastError || !response) {
          // Se falhou, injeta scripts e tenta novamente
          await chrome.scripting.executeScript({
            target: { tabId: activeTabId },
            files: ["content.js"],
          });
          setTimeout(() => {
            chrome.tabs.sendMessage(activeTabId, { action: "FORCE_DOM_SCAN" }, (res2) => {
              if (res2 && res2.videos) absorbVideos(res2.videos);
              btnScan.disabled = false;
              btnScan.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg> Escanear`;
            });
          }, 400);
          return;
        }

        if (response && response.videos) {
          absorbVideos(response.videos);
        }
        btnScan.disabled = false;
        btnScan.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg> Escanear`;
      });
    } catch (e) {
      btnScan.disabled = false;
      btnScan.innerText = "Escanear";
    }
  });

  btnStartDownload.addEventListener("click", startBatchDownload);
  btnCancelDownload.addEventListener("click", cancelBatchDownload);
}

// --- COMUNICAÇÃO DE DOWNLOAD ---
function startBatchDownload() {
  const toDownload = filteredVideos.filter((v) => selectedIds.has(v.id));
  const batch = toDownload.slice(0, MAX_BATCH_LIMIT);

  if (batch.length === 0) return;

  progressBox.classList.remove("hidden");
  progressBarFill.style.width = "0%";
  progressStatusText.innerText = `Iniciando lote de ${batch.length} vídeos...`;
  progressPercentText.innerText = "0%";
  btnStartDownload.disabled = true;

  chrome.runtime.sendMessage(
    {
      action: "START_BATCH_DOWNLOAD",
      items: batch,
    },
    (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        progressStatusText.innerText = "Erro ao iniciar download.";
      }
    }
  );
}

function cancelBatchDownload() {
  chrome.runtime.sendMessage({ action: "CANCEL_BATCH_DOWNLOAD" });
}

function handleProgressUpdate(payload) {
  if (!payload) return;

  if (payload.status === "resolving") {
    progressBox.classList.remove("hidden");
    progressBarFill.style.width = `${payload.percentage}%`;
    progressStatusText.innerText = `Obtendo link HD do vídeo ${payload.current} de ${payload.total}...`;
    progressPercentText.innerText = `${payload.percentage}%`;
    btnStartDownload.disabled = true;
  } else if (payload.status === "downloading") {
    progressBox.classList.remove("hidden");
    progressBarFill.style.width = `${payload.percentage}%`;
    progressStatusText.innerText = `Baixando ${payload.current} de ${payload.total}... (@${payload.currentAuthor})`;
    progressPercentText.innerText = `${payload.percentage}%`;
    btnStartDownload.disabled = true;
  } else if (payload.status === "completed") {
    progressBarFill.style.width = "100%";
    progressStatusText.innerText = `Lote finalizado! (${payload.successCount} baixados, ${payload.failCount} falhas)`;
    progressPercentText.innerText = "100%";
    btnStartDownload.disabled = false;
    setTimeout(() => {
      progressBox.classList.add("hidden");
    }, 4500);
  } else if (payload.status === "cancelled") {
    progressStatusText.innerText = "Download cancelado.";
    btnStartDownload.disabled = false;
    setTimeout(() => {
      progressBox.classList.add("hidden");
    }, 2500);
  }
}

function checkOngoingDownloadStatus() {
  chrome.runtime.sendMessage({ action: "GET_DOWNLOAD_STATUS" }, (res) => {
    if (res && res.active) {
      progressBox.classList.remove("hidden");
      const pct = Math.round((res.currentIndex / res.total) * 100);
      progressBarFill.style.width = `${pct}%`;
      progressStatusText.innerText = `Baixando ${res.currentIndex} de ${res.total}...`;
      progressPercentText.innerText = `${pct}%`;
      btnStartDownload.disabled = true;
    }
  });
}

// Helpers
function formatMetric(num) {
  if (!num) return "0";
  if (num >= 1000000000) return (num / 1000000000).toFixed(1).replace(/\.0$/, "") + "B";
  if (num >= 1000000) return (num / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
  if (num >= 1000) return (num / 1000).toFixed(1).replace(/\.0$/, "") + "k";
  return num.toString();
}

function escapeHtml(str) {
  return (str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
