/**
 * DGS - Download em Massa
 * Content Script (Contexto ISOLATED)
 * Varre o DOM em tempo real e monitora novas mídias adicionadas durante o scroll
 */

(function () {
  const SCRIPT_NAME = "[DGS Content Script]";
  const tabVideosCache = new Map();

  // --- PARSERS DE NÚMEROS (Ex: "87,6 mil" -> 87600, "1.2M" -> 1200000, "1.190" -> 1190) ---
  function parseMetricString(str) {
    if (!str) return 0;
    const clean = str.toString().trim().toLowerCase().replace(/\s+/g, "");
    if (!clean) return 0;

    let multiplier = 1;
    let numPart = clean;

    // 1. Bilhões ("bi", "b")
    if (/bi$|b$/i.test(clean)) {
      multiplier = 1000000000;
      numPart = clean.replace(/bi$|b$/i, "");
    }
    // 2. Milhões ("mi", "m" sozinho - nunca "mil")
    else if (/mi$/i.test(clean) || (clean.endsWith("m") && !clean.endsWith("mil"))) {
      multiplier = 1000000;
      numPart = clean.replace(/mi$|m$/i, "");
    }
    // 3. Milhares ("mil", "k")
    else if (clean.endsWith("mil") || clean.endsWith("k")) {
      multiplier = 1000;
      numPart = clean.replace(/mil$|k$/i, "");
    }

    if (numPart.includes(",")) {
      numPart = numPart.replace(/\./g, "").replace(",", ".");
    } else if (numPart.includes(".")) {
      if (/^\d{1,3}\.\d{3}$/.test(numPart) && multiplier === 1) {
        numPart = numPart.replace(".", "");
      }
    }

    const val = parseFloat(numPart);
    return isNaN(val) ? 0 : Math.round(val * multiplier);
  }

  function getAuthorFromPage() {
    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");

    if (isTikTok) {
      const match = window.location.pathname.match(/@([a-zA-Z0-9_.-]+)/);
      if (match) return match[1];
    }

    if (isInstagram) {
      const pathParts = window.location.pathname.split("/").filter(Boolean);
      if (pathParts.length > 0 && !["explore", "direct", "stories", "reels"].includes(pathParts[0])) {
        return pathParts[0].replace("@", "");
      }
    }

    return "perfil";
  }

  // --- VARREDURA ROBUSTA DO DOM PARA INSTAGRAM & TIKTOK ---
  function scanCurrentPageDOM() {
    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");
    const defaultAuthor = getAuthorFromPage();
    let newItemsCount = 0;

    // 1. INSTAGRAM (Aba de Posts, Aba de Reels ou Feed)
    if (isInstagram) {
      const anchors = document.querySelectorAll('a[href*="/reel/"], a[href*="/p/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/(?:p|reel)\/([A-Za-z0-9_-]+)/);
          if (!match) return;
          const code = match[1];
          const id = `ig_${code}`;

          const isReelUrl = href.includes("/reel/");
          const svg = a.querySelector("svg");
          const svgLabel = (svg?.getAttribute("aria-label") || "").toLowerCase();
          const isVideoSvg =
            svgLabel.includes("clipe") ||
            svgLabel.includes("reel") ||
            svgLabel.includes("vídeo") ||
            svgLabel.includes("video");

          // Na aba /reels/ ou se tiver indicador de reel, é vídeo garantido
          const isReelsTab = window.location.pathname.includes("/reels");
          const isVideo = isReelsTab || isReelUrl || isVideoSvg || !!a.querySelector("video");

          if (!isVideo && !isReelUrl) return;

          const img = a.querySelector("img");
          const thumb = img ? (img.currentSrc || img.src) : "";
          const alt = img ? (img.alt || "") : "";

          // Extração de métricas de views (visíveis na aba /reels/ ou overlay)
          let detectedViews = 0;
          const textBlocks = Array.from(a.querySelectorAll("span, div"))
            .map((el) => el.innerText.trim())
            .filter(Boolean);

          for (const t of textBlocks) {
            // Padrões como: "1.190", "13,4 mil", "1.2M", "500k"
            if (/^[0-9]+([.,][0-9]+)?\s*(k|m|mil|mi)?$/i.test(t)) {
              detectedViews = parseMetricString(t);
              break;
            }
          }

          // Se o item já existe no cache, apenas atualiza métricas se detectadas
          if (tabVideosCache.has(id)) {
            const existing = tabVideosCache.get(id);
            if (detectedViews > 0 && (!existing.metrics.views || existing.metrics.views === 0)) {
              existing.metrics.views = detectedViews;
            }
            if (thumb && !existing.thumbnailUrl) existing.thumbnailUrl = thumb;
            return;
          }

          const videoItem = {
            id,
            rawId: code,
            code,
            platform: "instagram",
            author: defaultAuthor,
            caption: alt || `Reel Instagram @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views: detectedViews,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null, // Será resolvido no download se necessário
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          newItemsCount++;
        } catch (e) {}
      });
    }

    // 2. TIKTOK (Perfil ou Feed)
    if (isTikTok) {
      const anchors = document.querySelectorAll('a[href*="/video/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/video\/([0-9]+)/);
          if (!match) return;
          const videoId = match[1];
          const id = `tt_${videoId}`;

          if (tabVideosCache.has(id)) return;

          const img = a.querySelector("img");
          const thumb = img ? (img.currentSrc || img.src) : "";
          const alt = img ? (img.alt || "") : "";

          // Contagem de views no TikTok (strong com data-e2e="video-views")
          let views = 0;
          const viewsEl = a.querySelector('[data-e2e="video-views"]') || a.querySelector("strong");
          if (viewsEl && viewsEl.innerText) {
            views = parseMetricString(viewsEl.innerText);
          }

          const videoItem = {
            id,
            rawId: videoId,
            platform: "tiktok",
            author: defaultAuthor,
            caption: alt || `Vídeo TikTok @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null,
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          newItemsCount++;
        } catch (e) {}
      });
    }

    if (newItemsCount > 0) {
      broadcastCapturedVideos();
    }

    return newItemsCount;
  }

  function extractHashtags(text) {
    if (!text) return [];
    const matches = text.match(/#[a-zA-Z0-9_\u00C0-\u00FF]+/g);
    if (!matches) return [];
    return matches.map((m) => m.replace("#", "").toLowerCase());
  }

  function broadcastCapturedVideos() {
    chrome.runtime.sendMessage({
      action: "VIDEOS_CAPTURED",
      allVideos: Array.from(tabVideosCache.values()),
      totalInTab: tabVideosCache.size,
      url: window.location.href,
    }).catch(() => {
      // Ignora erro se o painel lateral estiver fechado
    });
  }

  // --- RECONCILIAÇÃO DE DADOS VINDO DO INJECTED.JS (APIs de Rede) ---
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.type !== "DGS_VIDEOS_DISCOVERED") {
      return;
    }

    const { videos } = event.data;
    if (!Array.isArray(videos)) return;

    let addedOrUpdated = 0;
    videos.forEach((v) => {
      if (!v || !v.id) return;
      if (tabVideosCache.has(v.id)) {
        // Enriquece o item existente com métricas ricas de rede
        const existing = tabVideosCache.get(v.id);
        if (v.metrics) {
          if (v.metrics.views) existing.metrics.views = v.metrics.views;
          if (v.metrics.likes) existing.metrics.likes = v.metrics.likes;
          if (v.metrics.comments) existing.metrics.comments = v.metrics.comments;
        }
        if (v.videoUrl) existing.videoUrl = v.videoUrl;
        if (v.thumbnailUrl && !existing.thumbnailUrl) existing.thumbnailUrl = v.thumbnailUrl;
        if (v.caption && (!existing.caption || existing.caption.startsWith("Reel Instagram"))) existing.caption = v.caption;
      } else {
        tabVideosCache.set(v.id, v);
      }
      addedOrUpdated++;
    });

    if (addedOrUpdated > 0) {
      broadcastCapturedVideos();
    }
  });

  // --- MUTATION OBSERVER PARA MONITORAR ROLAGEM EM TEMPO REAL ---
  let scanThrottleTimer = null;
  const observer = new MutationObserver(() => {
    if (scanThrottleTimer) return;
    scanThrottleTimer = setTimeout(() => {
      scanThrottleTimer = null;
      scanCurrentPageDOM();
    }, 600);
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
  });

  // Listener de rolagem nativo do usuário
  window.addEventListener("scroll", () => {
    if (scanThrottleTimer) return;
    scanThrottleTimer = setTimeout(() => {
      scanThrottleTimer = null;
      scanCurrentPageDOM();
    }, 500);
  }, { passive: true });

  // Executa varredura inicial assim que o script sobe
  scanCurrentPageDOM();
  setTimeout(scanCurrentPageDOM, 1000);
  setTimeout(scanCurrentPageDOM, 2500);

  // --- MENSAGENS COM A EXTENSÃO (Side Panel / Background) ---
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_CACHED_VIDEOS") {
      scanCurrentPageDOM();
      sendResponse({
        success: true,
        videos: Array.from(tabVideosCache.values()),
        total: tabVideosCache.size,
        currentUrl: window.location.href,
        author: getAuthorFromPage(),
      });
      return true;
    }

    if (request.action === "FORCE_DOM_SCAN") {
      const added = scanCurrentPageDOM();
      sendResponse({
        success: true,
        addedCount: added,
        videos: Array.from(tabVideosCache.values()),
        total: tabVideosCache.size,
      });
      return true;
    }
  });

  console.log(`${SCRIPT_NAME} Scanner de DOM e observador de rolagem ativos.`);
})();
