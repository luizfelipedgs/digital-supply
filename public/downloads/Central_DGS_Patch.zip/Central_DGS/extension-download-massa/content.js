/**
 * DGS - Download em Massa
 * Content Script (Contexto ISOLATED)
 * Varre o DOM em tempo real, monitora rolagem e injeta botão de download individual na grade
 */

(function () {
  const SCRIPT_NAME = "[DGS Content Script]";
  const tabVideosCache = new Map();

  // --- INJEÇÃO DE ESTILOS DO BOTÃO DE DOWNLOAD DIRETO NA GRADE ---
  function injectGridDownloadStyles() {
    if (document.getElementById("dgs-grid-download-styles")) return;

    const style = document.createElement("style");
    style.id = "dgs-grid-download-styles";
    style.textContent = `
      .dgs-grid-download-btn {
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) scale(0.92) !important;
        width: 44px !important;
        height: 44px !important;
        border-radius: 50% !important;
        background: rgba(0, 0, 0, 0.68) !important;
        backdrop-filter: blur(8px) !important;
        -webkit-backdrop-filter: blur(8px) !important;
        border: 1.5px solid rgba(255, 255, 255, 0.45) !important;
        color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        z-index: 99999 !important;
        opacity: 0 !important;
        transition: opacity 0.22s cubic-bezier(0.4, 0, 0.2, 1), transform 0.22s cubic-bezier(0.4, 0, 0.2, 1), background 0.2s, border-color 0.2s, box-shadow 0.2s !important;
        box-shadow: 0 4px 18px rgba(0, 0, 0, 0.55) !important;
        pointer-events: auto !important;
        user-select: none !important;
        padding: 0 !important;
        margin: 0 !important;
        outline: none !important;
      }

      /* Aparece suavemente no hover do card de vídeo */
      a:hover > .dgs-grid-download-btn,
      div:hover > .dgs-grid-download-btn,
      .dgs-grid-download-btn:hover {
        opacity: 1 !important;
        transform: translate(-50%, -50%) scale(1) !important;
      }

      /* Efeito hover interativo no botão DGS */
      .dgs-grid-download-btn:hover {
        background: rgba(154, 205, 50, 0.95) !important;
        border-color: #9acd32 !important;
        color: #070805 !important;
        box-shadow: 0 0 20px rgba(154, 205, 50, 0.65) !important;
        transform: translate(-50%, -50%) scale(1.12) !important;
      }

      .dgs-grid-download-btn:active {
        transform: translate(-50%, -50%) scale(0.95) !important;
      }

      /* Estado de Carregamento (Spinner) */
      .dgs-grid-download-btn.dgs-loading {
        opacity: 1 !important;
        background: rgba(13, 15, 10, 0.88) !important;
        border-color: #9acd32 !important;
        cursor: wait !important;
      }

      .dgs-grid-download-btn.dgs-loading svg {
        animation: dgs-spin 0.8s linear infinite !important;
        stroke: #9acd32 !important;
      }

      @keyframes dgs-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }

      /* Estado de Sucesso (Check Verde) */
      .dgs-grid-download-btn.dgs-success {
        opacity: 1 !important;
        background: #22c55e !important;
        border-color: #4ade80 !important;
        color: #ffffff !important;
        transform: translate(-50%, -50%) scale(1.1) !important;
        box-shadow: 0 0 22px rgba(34, 197, 94, 0.7) !important;
      }

      /* Estado de Erro */
      .dgs-grid-download-btn.dgs-error {
        opacity: 1 !important;
        background: #ef4444 !important;
        border-color: #f87171 !important;
        color: #ffffff !important;
      }
    `;

    (document.head || document.documentElement).appendChild(style);
  }

  // --- ÍCONES SVG PARA O BOTÃO DA GRADE ---
  const SVG_DOWNLOAD = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
  `;

  const SVG_LOADING = `
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
      <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
    </svg>
  `;

  const SVG_SUCCESS = `
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  `;

  const SVG_ERROR = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="12" cy="12" r="10"></circle>
      <line x1="12" y1="8" x2="12" y2="12"></line>
      <line x1="12" y1="16" x2="12.01" y2="16"></line>
    </svg>
  `;

  function setButtonState(btn, state) {
    btn.classList.remove("dgs-loading", "dgs-success", "dgs-error");
    if (state === "loading") {
      btn.classList.add("dgs-loading");
      btn.innerHTML = SVG_LOADING;
    } else if (state === "success") {
      btn.classList.add("dgs-success");
      btn.innerHTML = SVG_SUCCESS;
    } else if (state === "error") {
      btn.classList.add("dgs-error");
      btn.innerHTML = SVG_ERROR;
    } else {
      btn.innerHTML = SVG_DOWNLOAD;
    }
  }

  // Anexa o botão de download individual direto no tile da grade
  function attachDownloadButtonToTile(containerEl, videoItem) {
    if (!containerEl || !videoItem) return;

    // Se já estiver injetado, apenas garante que o ponteiro de dados está fresco
    const existingBtn = containerEl.querySelector(".dgs-grid-download-btn");
    if (existingBtn) {
      existingBtn._dgsVideo = videoItem;
      return;
    }

    // Garante que o contêiner tem posição relativa para centralização absoluta
    const compStyle = window.getComputedStyle(containerEl);
    if (compStyle.position === "static") {
      containerEl.style.position = "relative";
    }

    const btn = document.createElement("button");
    btn.className = "dgs-grid-download-btn";
    btn.title = "Baixar vídeo em HD (DGS)";
    btn.setAttribute("aria-label", "Baixar vídeo");
    btn.innerHTML = SVG_DOWNLOAD;
    btn._dgsVideo = videoItem;

    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (btn.classList.contains("dgs-loading")) return;

      setButtonState(btn, "loading");

      const itemToDownload = btn._dgsVideo || videoItem;

      chrome.runtime.sendMessage(
        {
          action: "START_SINGLE_DOWNLOAD",
          video: itemToDownload,
        },
        (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            console.error("Falha ao baixar vídeo individual:", chrome.runtime.lastError || res?.error);
            setButtonState(btn, "error");
            setTimeout(() => setButtonState(btn, "default"), 2500);
          } else {
            setButtonState(btn, "success");
            setTimeout(() => setButtonState(btn, "default"), 2500);
          }
        }
      );
    });

    containerEl.appendChild(btn);
  }

  // --- PARSERS DE MÉTRICAS (Ex: "87,6 mil" -> 87600, "1.2M" -> 1200000) ---
  function parseMetricString(str) {
    if (!str) return 0;
    const clean = str.toString().trim().toLowerCase().replace(/\s+/g, "");
    if (!clean) return 0;

    let multiplier = 1;
    let numPart = clean;

    if (/bi$|b$/i.test(clean)) {
      multiplier = 1000000000;
      numPart = clean.replace(/bi$|b$/i, "");
    } else if (/mi$/i.test(clean) || (clean.endsWith("m") && !clean.endsWith("mil"))) {
      multiplier = 1000000;
      numPart = clean.replace(/mi$|m$/i, "");
    } else if (clean.endsWith("mil") || clean.endsWith("k")) {
      multiplier = 1000;
      numPart = clean.replace(/mil$|k$/i, "");
    }

    if (numPart.includes(",")) {
      numPart = numPart.replace(/\./g, "").replace(",", ".");
    } else if (numPart.includes(".")) {
      if (/^\d{1,3}\.\d{3}$/.test(numPart) && multiplier === 1) {
        numPart = numPart.replace(".", "");
      }
    }

    const val = parseFloat(numPart);
    return isNaN(val) ? 0 : Math.round(val * multiplier);
  }

  function getAuthorFromPage() {
    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");

    if (isTikTok) {
      const match = window.location.pathname.match(/@([a-zA-Z0-9_.-]+)/);
      if (match) return match[1];
    }

    if (isInstagram) {
      const pathParts = window.location.pathname.split("/").filter(Boolean);
      if (pathParts.length > 0 && !["explore", "direct", "stories", "reels"].includes(pathParts[0])) {
        return pathParts[0].replace("@", "");
      }
    }

    return "perfil";
  }

  // --- EXTRAÇÃO ROBUSTA DE MINIATURA (EVITA DATA URLs VAZIAS E 403) ---
  function extractThumbnailFromElement(el) {
    if (!el) return "";

    const img = el.querySelector("img");
    if (img) {
      if (img.currentSrc && !img.currentSrc.startsWith("data:") && !img.currentSrc.startsWith("blob:")) {
        return img.currentSrc;
      }
      if (img.src && !img.src.startsWith("data:") && !img.src.startsWith("blob:")) {
        return img.src;
      }
      const rawSrc = img.getAttribute("src");
      if (rawSrc && !rawSrc.startsWith("data:") && !rawSrc.startsWith("blob:")) {
        return rawSrc;
      }
      const srcset = img.srcset || img.getAttribute("srcset");
      if (srcset) {
        const candidates = srcset
          .split(",")
          .map((s) => s.trim().split(/\s+/)[0])
          .filter(Boolean);
        const valid = candidates.filter((u) => !u.startsWith("data:") && !u.startsWith("blob:"));
        if (valid.length > 0) return valid[valid.length - 1];
      }
    }

    const source = el.querySelector("picture source");
    if (source) {
      const srcset = source.srcset || source.getAttribute("srcset");
      if (srcset) {
        const candidates = srcset
          .split(",")
          .map((s) => s.trim().split(/\s+/)[0])
          .filter(Boolean);
        const valid = candidates.filter((u) => !u.startsWith("data:") && !u.startsWith("blob:"));
        if (valid.length > 0) return valid[valid.length - 1];
      }
    }

    const bgEl = el.querySelector('[style*="background-image"]');
    if (bgEl) {
      const m = bgEl.style.backgroundImage.match(/url\(["']?([^"']+)["']?\)/);
      if (m && m[1] && !m[1].startsWith("data:") && !m[1].startsWith("blob:")) {
        return m[1];
      }
    }

    return "";
  }

  // --- VARREDURA ROBUSTA DO DOM PARA INSTAGRAM & TIKTOK ---
  function scanCurrentPageDOM() {
    injectGridDownloadStyles();

    const isInstagram = window.location.hostname.includes("instagram.com");
    const isTikTok = window.location.hostname.includes("tiktok.com");
    const defaultAuthor = getAuthorFromPage();
    let updatedOrNewCount = 0;

    // 1. INSTAGRAM (Aba de Posts, Aba de Reels ou Feed)
    if (isInstagram) {
      const anchors = document.querySelectorAll('a[href*="/reel/"], a[href*="/p/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/(?:p|reel)\/([A-Za-z0-9_-]+)/);
          if (!match) return;
          const code = match[1];
          const id = `ig_${code}`;

          const isReelUrl = href.includes("/reel/");
          const svg = a.querySelector("svg");
          const svgLabel = (svg?.getAttribute("aria-label") || "").toLowerCase();
          const isVideoSvg =
            svgLabel.includes("clipe") ||
            svgLabel.includes("reel") ||
            svgLabel.includes("vídeo") ||
            svgLabel.includes("video");

          const isReelsTab = window.location.pathname.includes("/reels");
          const isVideo = isReelsTab || isReelUrl || isVideoSvg || !!a.querySelector("video");

          if (!isVideo && !isReelUrl) return;

          const thumb = extractThumbnailFromElement(a);
          const img = a.querySelector("img");
          const alt = img ? img.alt || "" : "";

          // Extração de métricas de views visíveis
          let detectedViews = 0;
          const textBlocks = Array.from(a.querySelectorAll("span, div"))
            .map((el) => el.innerText.trim())
            .filter(Boolean);

          for (const t of textBlocks) {
            if (/^[0-9]+([.,][0-9]+)?\s*(k|m|mil|mi)?$/i.test(t)) {
              detectedViews = parseMetricString(t);
              break;
            }
          }

          // Se o item já existe no cache
          if (tabVideosCache.has(id)) {
            const existing = tabVideosCache.get(id);
            let itemChanged = false;
            if (detectedViews > 0 && (!existing.metrics.views || existing.metrics.views === 0)) {
              existing.metrics.views = detectedViews;
              itemChanged = true;
            }
            if (thumb && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
              existing.thumbnailUrl = thumb;
              itemChanged = true;
            }
            if (itemChanged) updatedOrNewCount++;

            // Anexa botão na grade mesmo se o item já estiver no cache
            attachDownloadButtonToTile(a, existing);
            return;
          }

          const videoItem = {
            id,
            rawId: code,
            code,
            platform: "instagram",
            author: defaultAuthor,
            caption: alt || `Reel Instagram @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views: detectedViews,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null,
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          updatedOrNewCount++;

          // Anexa o botão individual diretamente na grade
          attachDownloadButtonToTile(a, videoItem);
        } catch (e) {}
      });
    }

    // 2. TIKTOK (Perfil ou Feed)
    if (isTikTok) {
      const anchors = document.querySelectorAll('a[href*="/video/"]');
      anchors.forEach((a) => {
        try {
          const href = a.href || "";
          const match = href.match(/\/video\/([0-9]+)/);
          if (!match) return;
          const videoId = match[1];
          const id = `tt_${videoId}`;

          const thumb = extractThumbnailFromElement(a);
          const img = a.querySelector("img");
          const alt = img ? img.alt || "" : "";

          let views = 0;
          const viewsEl = a.querySelector('[data-e2e="video-views"]') || a.querySelector("strong");
          if (viewsEl && viewsEl.innerText) {
            views = parseMetricString(viewsEl.innerText);
          }

          if (tabVideosCache.has(id)) {
            const existing = tabVideosCache.get(id);
            let itemChanged = false;
            if (views > 0 && (!existing.metrics.views || existing.metrics.views === 0)) {
              existing.metrics.views = views;
              itemChanged = true;
            }
            if (thumb && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
              existing.thumbnailUrl = thumb;
              itemChanged = true;
            }
            if (itemChanged) updatedOrNewCount++;

            attachDownloadButtonToTile(a, existing);
            return;
          }

          const videoItem = {
            id,
            rawId: videoId,
            platform: "tiktok",
            author: defaultAuthor,
            caption: alt || `Vídeo TikTok @${defaultAuthor}`,
            hashtags: extractHashtags(alt),
            metrics: {
              views,
              likes: 0,
              comments: 0,
              shares: 0,
            },
            videoUrl: null,
            thumbnailUrl: thumb,
            postUrl: href,
            createdAt: Date.now(),
          };

          tabVideosCache.set(id, videoItem);
          updatedOrNewCount++;

          attachDownloadButtonToTile(a, videoItem);
        } catch (e) {}
      });
    }

    if (updatedOrNewCount > 0) {
      broadcastCapturedVideos();
    }

    return updatedOrNewCount;
  }

  function extractHashtags(text) {
    if (!text) return [];
    const matches = text.match(/#[a-zA-Z0-9_\u00C0-\u00FF]+/g);
    if (!matches) return [];
    return matches.map((m) => m.replace("#", "").toLowerCase());
  }

  function broadcastCapturedVideos() {
    chrome.runtime.sendMessage({
      action: "VIDEOS_CAPTURED",
      allVideos: Array.from(tabVideosCache.values()),
      totalInTab: tabVideosCache.size,
      url: window.location.href,
    }).catch(() => {
      // Ignora erro se o painel lateral estiver fechado
    });
  }

  // --- RECONCILIAÇÃO DE DADOS VINDO DO INJECTED.JS (APIs de Rede) ---
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data || event.data.type !== "DGS_VIDEOS_DISCOVERED") {
      return;
    }

    const { videos } = event.data;
    if (!Array.isArray(videos)) return;

    let addedOrUpdated = 0;
    videos.forEach((v) => {
      if (!v || !v.id) return;
      if (tabVideosCache.has(v.id)) {
        const existing = tabVideosCache.get(v.id);
        if (v.metrics) {
          if (v.metrics.views) existing.metrics.views = v.metrics.views;
          if (v.metrics.likes) existing.metrics.likes = v.metrics.likes;
          if (v.metrics.comments) existing.metrics.comments = v.metrics.comments;
        }
        if (v.videoUrl) existing.videoUrl = v.videoUrl;
        if (v.thumbnailUrl && (!existing.thumbnailUrl || existing.thumbnailUrl.startsWith("data:"))) {
          existing.thumbnailUrl = v.thumbnailUrl;
        }
        if (v.caption && (!existing.caption || existing.caption.startsWith("Reel Instagram"))) {
          existing.caption = v.caption;
        }
      } else {
        tabVideosCache.set(v.id, v);
      }
      addedOrUpdated++;
    });

    if (addedOrUpdated > 0) {
      broadcastCapturedVideos();
    }
  });

  // --- MUTATION OBSERVER PARA MONITORAR ROLAGEM E RE-INJEÇÃO ---
  let scanThrottleTimer = null;
  const observer = new MutationObserver(() => {
    if (scanThrottleTimer) return;
    scanThrottleTimer = setTimeout(() => {
      scanThrottleTimer = null;
      scanCurrentPageDOM();
    }, 500);
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
  });

  // Listener de rolagem nativo do usuário
  window.addEventListener(
    "scroll",
    () => {
      if (scanThrottleTimer) return;
      scanThrottleTimer = setTimeout(() => {
        scanThrottleTimer = null;
        scanCurrentPageDOM();
      }, 400);
    },
    { passive: true }
  );

  // Executa varredura inicial assim que o script sobe
  scanCurrentPageDOM();
  setTimeout(scanCurrentPageDOM, 800);
  setTimeout(scanCurrentPageDOM, 2000);

  // --- MENSAGENS COM A EXTENSÃO (Side Panel / Background) ---
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "GET_CACHED_VIDEOS") {
      scanCurrentPageDOM();
      sendResponse({
        success: true,
        videos: Array.from(tabVideosCache.values()),
        total: tabVideosCache.size,
        currentUrl: window.location.href,
        author: getAuthorFromPage(),
      });
      return true;
    }

    if (request.action === "FORCE_DOM_SCAN") {
      const added = scanCurrentPageDOM();
      sendResponse({
        success: true,
        addedCount: added,
        videos: Array.from(tabVideosCache.values()),
        total: tabVideosCache.size,
      });
      return true;
    }
  });

  console.log(`${SCRIPT_NAME} Scanner de DOM, botão na grade e observador de rolagem ativos.`);
})();
