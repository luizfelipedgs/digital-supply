import os
import sys
import math
import random
import asyncio
import threading
from typing import Optional, Callable, Any
from playwright.async_api import async_playwright, BrowserContext, Page, Locator
from backend.database import get_setting

# User agent moderno para evitar bloqueios
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"

# Com channel="chrome" e --disable-blink-features=AutomationControlled,
# o Google Chrome nativo já possui navigator.webdriver == False, PluginArray nativo com 5 plugins,
# propriedades íntegras e objeto window.chrome autêntico.
# Não injetamos scripts que alteram protótipos de JavaScript para não acionar detectores antifraude (Falco/Bloks da Meta).
STEALTH_INIT_SCRIPT = ""

def is_cdp_alive(port: int = 9222) -> bool:
    """Verifica se há um navegador Chrome com porta CDP ativa."""
    try:
        import urllib.request
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1.5) as resp:
            return resp.status == 200
    except Exception:
        return False

class HumanController:
    """
    Simula movimentos e ações humanas autênticas no navegador,
    gerando eventos de ponteiro nativos e confiáveis (isTrusted = True) com
    curvas de Bézier cúbicas, aceleração/desaceleração natural e micro-variações.
    """
    _current_x = 100.0
    _current_y = 100.0

    @classmethod
    async def sleep(cls, min_sec: float = 1.0, max_sec: float = 2.5):
        await asyncio.sleep(random.uniform(min_sec, max_sec))

    @classmethod
    async def move_mouse(cls, page: Page, target_x: float, target_y: float, steps: Optional[int] = None):
        """Move o cursor seguindo uma curva cúbica de Bézier com aceleração e desaceleração humana."""
        start_x, start_y = cls._current_x, cls._current_y
        dx = target_x - start_x
        dy = target_y - start_y
        dist = math.hypot(dx, dy)
        
        if dist < 4:
            cls._current_x, cls._current_y = target_x, target_y
            await page.mouse.move(target_x, target_y)
            return

        if steps is None:
            steps = max(15, min(int(dist / 14), 40))
        
        dev = dist * random.uniform(0.08, 0.22)
        angle = math.atan2(dy, dx) + random.choice([-1, 1]) * random.uniform(0.2, 0.5)
        
        ctrl1_x = start_x + (dx * 0.3) + math.cos(angle) * dev
        ctrl1_y = start_y + (dy * 0.3) + math.sin(angle) * dev
        ctrl2_x = start_x + (dx * 0.7) - math.cos(angle) * (dev * 0.5)
        ctrl2_y = start_y + (dy * 0.7) - math.sin(angle) * (dev * 0.5)

        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 0.5 * (1 - math.cos(t * math.pi))
            u = 1 - ease_t
            tt = ease_t * ease_t
            uu = u * u
            uuu = uu * u
            ttt = tt * ease_t
            
            x = (uuu * start_x) + (3 * uu * ease_t * ctrl1_x) + (3 * u * tt * ctrl2_x) + (ttt * target_x)
            y = (uuu * start_y) + (3 * uu * ease_t * ctrl1_y) + (3 * u * tt * ctrl2_y) + (ttt * target_y)
            
            if i < steps:
                x += random.uniform(-0.6, 0.6)
                y += random.uniform(-0.6, 0.6)
                
            await page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.006, 0.016))

        cls._current_x, cls._current_y = target_x, target_y
        await page.mouse.move(target_x, target_y)

    @classmethod
    async def click(cls, page: Page, locator: Locator, hover_time: float = 0.35):
        """
        Move o cursor humanamente até o elemento, faz hover natural e executa
        clique genuíno de hardware com isTrusted = True.
        """
        try:
            await locator.scroll_into_view_if_needed()
            await asyncio.sleep(0.2)
        except Exception:
            pass

        box = await locator.bounding_box()
        if not box:
            await locator.click()
            return
            
        target_x = box["x"] + box["width"] * random.uniform(0.3, 0.7)
        target_y = box["y"] + box["height"] * random.uniform(0.3, 0.7)
        
        await cls.move_mouse(page, target_x, target_y)
        await asyncio.sleep(random.uniform(hover_time * 0.8, hover_time * 1.3))
        
        await page.mouse.down()
        await asyncio.sleep(random.uniform(0.07, 0.14))
        await page.mouse.up()
        await asyncio.sleep(random.uniform(0.2, 0.4))

    @classmethod
    async def drag(cls, page: Page, start_x: float, start_y: float, target_x: float, target_y: float):
        """Arrasta slider com física de aceleração/desaceleração humana."""
        await cls.move_mouse(page, start_x, start_y)
        await asyncio.sleep(random.uniform(0.15, 0.25))
        await page.mouse.down()
        await asyncio.sleep(random.uniform(0.08, 0.15))
        await cls.move_mouse(page, target_x, target_y, steps=32)
        await asyncio.sleep(random.uniform(0.1, 0.2))
        await page.mouse.up()
        await asyncio.sleep(random.uniform(0.25, 0.45))

    @classmethod
    async def smooth_scroll(cls, page: Page, distance: int = 500, steps: int = 8):
        """
        Rola a página suavemente simulando a rodinha física do mouse com intervalos naturais e micro-variações.
        """
        step_dist = distance / steps
        for _ in range(steps):
            jitter_dist = step_dist * random.uniform(0.85, 1.15)
            await page.mouse.wheel(0, jitter_dist)
            await asyncio.sleep(random.uniform(0.04, 0.08))

def run_proactor(coro_fn: Callable, *args, **kwargs) -> Any:
    """
    Executa uma corotina do Playwright em uma thread isolada com WindowsProactorEventLoopPolicy.
    Necessário no Windows porque servidores web ASGI (Uvicorn) frequentemente utilizam SelectorEventLoop,
    o que impede a inicialização de pipes assíncronos do Playwright (NotImplementedError).
    """
    result = []
    error = []

    def target():
        if sys.platform == "win32":
            loop = asyncio.WindowsProactorEventLoopPolicy().new_event_loop()
        else:
            loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            res = loop.run_until_complete(coro_fn(*args, **kwargs))
            result.append(res)
        except Exception as e:
            error.append(e)
        finally:
            try:
                loop.close()
            except Exception:
                pass

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join()

    if error:
        raise error[0]
    return result[0] if result else None

async def run_proactor_async(coro_fn: Callable, *args, **kwargs) -> Any:
    """
    Executa a corotina do Playwright sem bloquear o loop principal do FastAPI/Uvicorn.
    """
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: run_proactor(coro_fn, *args, **kwargs))

class BrowserManager:
    @staticmethod
    def get_chrome_executable() -> Optional[str]:
        candidate_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]
        for p in candidate_paths:
            if os.path.exists(p):
                return p
        return None

    @staticmethod
    def get_edge_executable() -> Optional[str]:
        candidate_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe")
        ]
        for p in candidate_paths:
            if os.path.exists(p):
                return p
        return None

    @staticmethod
    def get_chrome_major_version() -> str:
        candidate_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]
        for p in candidate_paths:
            if os.path.exists(p):
                try:
                    import subprocess
                    ps_cmd = f"(Get-Item '{p}').VersionInfo.ProductVersion"
                    res = subprocess.run(["powershell", "-NoProfile", "-Command", ps_cmd], capture_output=True, text=True, timeout=2)
                    out = res.stdout.strip()
                    if out and "." in out:
                        return out.split(".")[0]
                except Exception:
                    pass
        return "131"

    @staticmethod
    def get_context_args(profile_dir: str, headless: Optional[bool] = None, mute_audio: Optional[bool] = None) -> dict:
        # Modo 100% autônomo e invisível: processos de automação SEMPRE rodam em segundo plano (headless)
        headless = True
        mute_audio = True

        os.makedirs(profile_dir, exist_ok=True)

        # Sincroniza o User-Agent com a versão real exata do Google Chrome instalado
        chrome_major = BrowserManager.get_chrome_major_version()
        dyn_user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_major}.0.0.0 Safari/537.36"

        context_args = {
            "user_data_dir": profile_dir,
            "headless": headless,
            "user_agent": dyn_user_agent,
            "locale": "pt-BR",
            "timezone_id": "America/Sao_Paulo",
            "permissions": ["clipboard-read", "clipboard-write"],
            "ignore_default_args": ["--enable-automation", "--no-sandbox", "--disable-dev-shm-usage"]
        }
        
        # Prioriza o binário oficial do Google Chrome ou Edge para assinaturas autênticas anti-bloqueio
        if BrowserManager.get_chrome_executable():
            context_args["channel"] = "chrome"
        elif BrowserManager.get_edge_executable():
            context_args["channel"] = "msedge"

        base_args = [
            "--disable-blink-features=AutomationControlled",
            "--disable-infobars",
            "--test-type",
            "--lang=pt-BR"
        ]

        # Silencia 100% qualquer saída de áudio de mídia se requisitado ou em background
        if mute_audio:
            base_args.append("--mute-audio")
            base_args.append("--autoplay-policy=no-user-gesture-required")

        if not headless:
            context_args["no_viewport"] = True
            context_args["args"] = base_args + ["--start-maximized", "--window-position=50,50"]
        else:
            context_args["viewport"] = {"width": 1280, "height": 900}
            context_args["args"] = base_args
        return context_args

    @staticmethod
    def bring_window_to_front(keyword: str = "chrome"):
        """Garante que a janela do Chrome fique em primeiro plano e visível no Windows."""
        if sys.platform != "win32":
            return
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            
            def enum_proc(hwnd, lparam):
                if user32.IsWindowVisible(hwnd):
                    length = user32.GetWindowTextLengthW(hwnd)
                    if length > 0:
                        buff = ctypes.create_unicode_buffer(length + 1)
                        user32.GetWindowTextW(hwnd, buff, length + 1)
                        title = buff.value.lower()
                        if keyword.lower() in title or "instagram" in title or "chrome" in title:
                            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                            user32.SetForegroundWindow(hwnd)
                return True

            WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
            user32.EnumWindows(WNDENUMPROC(enum_proc), 0)
        except Exception:
            pass

    @staticmethod
    def launch_login_browser(platform: str, profile_dir: str, account_name: str = "", account_id: int = 0):
        """
        Inicia a janela de login em segundo plano com ProactorEventLoop isolado.
        Abre o navegador oficial (Chrome / Edge / Chromium) diretamente na tela de login da rede social.
        """
        def background_worker():
            try:
                run_proactor(BrowserManager.open_login_session, platform, profile_dir, account_name, account_id)
            except Exception as e:
                from backend.database import add_log
                add_log(f"Falha ao executar login do {platform}: {str(e)}", "ERROR", platform)

        t = threading.Thread(target=background_worker, daemon=True)
        t.start()

    @staticmethod
    async def open_login_session(platform: str, profile_dir: str, account_name: str = "", account_id: int = 0):
        """
        Abre o navegador de login dedicado para a conta selecionada.
        1. Suporta fallback em cascata: Google Chrome -> Microsoft Edge -> Chromium -> Navegador do Sistema.
        2. Abre diretamente na página de login da plataforma (Instagram, TikTok ou YouTube).
        3. Monitora em tempo real a captura de cookies de autenticação (sessionid, LOGIN_INFO, etc.).
        4. Salva os cookies capturados no profile_dir da conta e atualiza o status para 'connected'.
        """
        import json
        import subprocess
        import webbrowser
        from backend.database import add_log, update_account_status, verify_account_session

        urls = {
            "instagram": "https://www.instagram.com/accounts/login/",
            "tiktok": "https://www.tiktok.com/login",
            "youtube": "https://studio.youtube.com/"
        }
        target_url = urls.get(platform.lower(), "https://www.instagram.com/")
        acc_label = f" ({account_name})" if account_name else ""

        if not profile_dir:
            base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "storage", "profiles")
            profile_dir = os.path.join(base_dir, f"{platform.lower()}_{account_id}")
        os.makedirs(profile_dir, exist_ok=True)
        json_cookies_path = os.path.join(profile_dir, "cookies.json")

        playwright_success = False

        try:
            async with async_playwright() as p:
                args_list = [
                    "--start-maximized",
                    "--disable-blink-features=AutomationControlled",
                    "--disable-infobars",
                    "--test-type",
                    "--lang=pt-BR"
                ]
                launch_kwargs = {
                    "user_data_dir": profile_dir,
                    "headless": False,
                    "no_viewport": True,
                    "args": args_list,
                    "locale": "pt-BR",
                    "timezone_id": "America/Sao_Paulo",
                    "permissions": ["clipboard-read", "clipboard-write"],
                    "ignore_default_args": ["--enable-automation", "--no-sandbox", "--disable-dev-shm-usage"]
                }

                context = None

                # 1. Google Chrome oficial
                if BrowserManager.get_chrome_executable():
                    try:
                        context = await p.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
                    except Exception as e:
                        add_log(f"Aviso Chrome: {e}. Tentando Microsoft Edge...", "WARNING", platform)

                # 2. Microsoft Edge oficial (nativo em todo Windows 10 e 11)
                if context is None and BrowserManager.get_edge_executable():
                    try:
                        context = await p.chromium.launch_persistent_context(channel="msedge", **launch_kwargs)
                    except Exception as e:
                        add_log(f"Aviso Edge: {e}. Tentando Chromium interno...", "WARNING", platform)

                # 3. Playwright Chromium interno
                if context is None:
                    try:
                        context = await p.chromium.launch_persistent_context(**launch_kwargs)
                    except Exception as e:
                        add_log(f"Aviso Chromium Playwright: {e}.", "WARNING", platform)

                if context is not None:
                    playwright_success = True
                    page = context.pages[0] if context.pages else await context.new_page()
                    try:
                        await page.goto(target_url, wait_until="domcontentloaded", timeout=25000)
                    except Exception:
                        pass
                    try:
                        await page.bring_to_front()
                    except Exception:
                        pass

                    add_log(f"Janela de login aberta para {platform.capitalize()}{acc_label}. Conclua o login na janela.", "INFO", platform)

                    # Monitora a autenticação em tempo real
                    confirmed = False
                    for _ in range(300):  # Monitora por até 10 minutos
                        await asyncio.sleep(2)
                        try:
                            if page.is_closed():
                                break
                        except Exception:
                            break

                        try:
                            cookies = await context.cookies()
                            c_names = [c["name"].lower() for c in cookies]
                            plat = platform.lower()

                            is_auth = False
                            if plat == "instagram" and "sessionid" in c_names:
                                is_auth = True
                            elif plat == "tiktok" and any(k in c_names for k in ["sessionid", "sid_guard", "session_key"]):
                                is_auth = True
                            elif plat == "youtube" and any(k in c_names for k in ["sid", "ssid", "login_info"]):
                                is_auth = True

                            if is_auth:
                                try:
                                    with open(json_cookies_path, "w", encoding="utf-8") as f:
                                        json.dump(cookies, f, indent=2)
                                except Exception:
                                    pass
                                confirmed = True
                                break
                        except Exception:
                            pass

                    # Salva cookies finais
                    try:
                        final_cookies = await context.cookies()
                        if final_cookies:
                            with open(json_cookies_path, "w", encoding="utf-8") as f:
                                json.dump(final_cookies, f, indent=2)
                    except Exception:
                        pass

                    if confirmed or (account_id and verify_account_session(account_id)):
                        if account_id:
                            update_account_status(account_id, "connected")
                        add_log(f"Sessão de {platform.capitalize()}{acc_label} CONECTADA E CONFIRMADA com sucesso! Status: Conectado.", "SUCCESS", platform)
                    else:
                        if account_id:
                            update_account_status(account_id, "disconnected")
                        add_log(f"Janela de login fechada antes da confirmação. Conta {account_name} permanece Desconectada.", "WARNING", platform)

        except Exception as e:
            add_log(f"Aviso no monitor de login: {str(e)}", "WARNING", platform)

        # Fallback de emergência caso nenhum engine do Playwright tenha aberto
        if not playwright_success:
            browser_exe = BrowserManager.get_chrome_executable() or BrowserManager.get_edge_executable()
            if browser_exe:
                try:
                    subprocess.Popen([browser_exe, f"--user-data-dir={profile_dir}", target_url])
                    add_log(f"Navegador do sistema aberto para login de {platform.capitalize()}{acc_label}. (Dica: você também pode usar o botão 'Cookie' na Central para conectar instantaneamente).", "INFO", platform)
                    return
                except Exception:
                    pass
            try:
                webbrowser.open(target_url)
                add_log(f"Página de login aberta no navegador padrão. Cole o cookie na Central para conectar.", "INFO", platform)
            except Exception:
                pass
