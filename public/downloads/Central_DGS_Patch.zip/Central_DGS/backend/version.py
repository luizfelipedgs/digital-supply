"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.4.0"
BUILD_DATE = "2026-11-25"
APP_NAME = "Central DGS"
DESCRIPTION = "Conexão Oficial 100% via API (Meta Graph API e TikTok Content Posting API v2), sem robôs de navegador, com interface limpa e publicação direta aos servidores."
