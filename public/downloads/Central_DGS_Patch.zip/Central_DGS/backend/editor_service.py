import os
import shutil
import subprocess
import threading
import urllib.request
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

from backend.database import get_db, add_video, add_log, set_setting, get_setting, update_video_file

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORAGE_DIR = os.path.join(BASE_DIR, "storage")
MUSIC_DIR = os.path.join(STORAGE_DIR, "music")
VIDEOS_DIR = os.path.join(STORAGE_DIR, "videos")
THUMBNAILS_DIR = os.path.join(STORAGE_DIR, "thumbnails")
OUTPUT_DIR = os.path.join(STORAGE_DIR, "editor_output")

os.makedirs(MUSIC_DIR, exist_ok=True)
os.makedirs(VIDEOS_DIR, exist_ok=True)
os.makedirs(THUMBNAILS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

SUPABASE_URL = os.environ.get("NEXT_PUBLIC_SUPABASE_URL", "https://oipbnfcahgmqiwpqhnvt.supabase.co").rstrip("/")
SUPABASE_ANON_KEY = os.environ.get(
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pcGJuZmNhaGdtcWl3cHFobnZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc5NjcxODMsImV4cCI6MjEwMzU0MzE4M30.bU2yDCbWICGcoxDucNOzjBi8H1iOUNPdCxeD-5BEWQs"
)

# Estado global do lote em execução
_batch_lock = threading.Lock()
_batch_state = {
    "status": "idle", # "idle", "processing", "completed", "error"
    "total": 0,
    "processed": 0,
    "current_file": "",
    "error": None,
    "created_video_ids": [],
    "source_video_ids": [],
    "target_video_ids": [],
    "output_files": []
}

def get_editor_status() -> Dict[str, Any]:
    with _batch_lock:
        st = dict(_batch_state)
        # Se target_video_ids não estiver preenchido, tenta resolver a partir de created_video_ids, source_video_ids ou output_files
        target_ids = list(st.get("target_video_ids") or [])
        if not target_ids:
            target_ids = list(st.get("created_video_ids") or [])
        if not target_ids:
            target_ids = list(st.get("source_video_ids") or [])
        if not target_ids and st.get("output_files"):
            try:
                from backend.database import get_db
                conn = get_db()
                cursor = conn.cursor()
                resolved = []
                for out_f in st["output_files"]:
                    base = os.path.basename(out_f)
                    raw_stem = base.split(" [DGS Edit")[0].strip()
                    cursor.execute("SELECT id FROM videos WHERE filepath LIKE ? OR filename = ? LIMIT 1", (f"%{raw_stem}%", f"{raw_stem}.mp4"))
                    row = cursor.fetchone()
                    if row:
                        resolved.append(row[0])
                conn.close()
                if resolved:
                    target_ids = resolved
                    _batch_state["target_video_ids"] = resolved
            except Exception:
                pass
        st["target_video_ids"] = target_ids
        return st

def get_community_music() -> List[Dict[str, Any]]:
    """Busca as faixas de música disponibilizadas pela DGS no Supabase."""
    token = get_setting("auth_access_token", "") or SUPABASE_ANON_KEY
    url = f"{SUPABASE_URL}/rest/v1/music_library?select=*&order=order_index.asc"
    
    def _fetch(tok: str):
        req = urllib.request.Request(url, headers={"apikey": SUPABASE_ANON_KEY, "Authorization": f"Bearer {tok}"})
        with urllib.request.urlopen(req, timeout=10.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    try:
        data = _fetch(token)
    except urllib.error.HTTPError as he:
        if he.code == 401:
            try:
                from backend.auth_service import refresh_session_tokens
                new_token = refresh_session_tokens()
                if new_token:
                    data = _fetch(new_token)
                else:
                    data = []
            except Exception:
                data = []
        else:
            add_log(f"Falha ao carregar biblioteca de músicas DGS: {str(he)}", "WARNING")
            data = []
    except Exception as e:
        add_log(f"Falha ao carregar biblioteca de músicas DGS: {str(e)}", "WARNING")
        data = []

    tracks = []
    for item in (data or []):
        storage_path = item.get("storage_path", "")
        audio_url = f"{SUPABASE_URL}/storage/v1/object/public/music-library/{storage_path}" if storage_path else ""
        tracks.append({
            "id": item.get("id"),
            "title": item.get("title") or "Música sem título",
            "storage_path": storage_path,
            "audio_url": audio_url
        })
    return tracks

def resolve_audio_file(audio_source: str) -> str:
    """Retorna o caminho local absoluto de um áudio (faz download se for URL remota)."""
    if audio_source.startswith("http://") or audio_source.startswith("https://"):
        filename = audio_source.split("?")[0].split("/")[-1]
        if not filename.endswith((".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg")):
            filename += ".mp3"
        local_path = os.path.join(MUSIC_DIR, f"cached_{filename}")
        if not os.path.exists(local_path) or os.path.getsize(local_path) == 0:
            add_log(f"Baixando faixa DGS para edição local: {filename}", "INFO")
            urllib.request.urlretrieve(audio_source, local_path)
        return local_path

    # Se for arquivo local em storage/music
    if os.path.exists(audio_source):
        return audio_source
    candidate = os.path.join(MUSIC_DIR, os.path.basename(audio_source))
    if os.path.exists(candidate):
        return candidate

    raise Exception(f"Arquivo de áudio não encontrado: {audio_source}")

def process_single_video(video_path: str, audio_path: str, start_seconds: float, output_path: str):
    """
    Executa o FFmpeg substituindo o áudio original do vídeo pela música selecionada.
    Corta a música no ponto marcado (start_seconds) e faz loop do áudio caso o vídeo seja mais longo.
    """
    cmd = [
        "ffmpeg",
        "-y",
        "-i", video_path,
        "-ss", str(max(0.0, float(start_seconds))),
        "-stream_loop", "-1",
        "-i", audio_path,
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-shortest",
        "-movflags", "+faststart",
        output_path
    ]

    res = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, timeout=120)
    if res.returncode != 0:
        raise Exception(f"Falha na renderização de áudio (código {res.returncode}): {res.stderr[-400:]}")

def generate_thumbnail(video_path: str, thumbnail_path: str):
    cmd = [
        "ffmpeg", "-ss", "00:00:00.500", "-i", video_path,
        "-vframes", "1", "-q:v", "3", thumbnail_path, "-y"
    ]
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
    except Exception:
        pass

def _run_batch_worker(audio_source: str, start_seconds: float, video_items: List[Dict[str, Any]], save_to_library: bool, custom_output_dir: Optional[str]):
    global _batch_state

    source_ids = [item.get("id") for item in video_items if item.get("id")]

    with _batch_lock:
        _batch_state["status"] = "processing"
        _batch_state["total"] = len(video_items)
        _batch_state["processed"] = 0
        _batch_state["error"] = None
        _batch_state["created_video_ids"] = []
        _batch_state["source_video_ids"] = source_ids
        _batch_state["target_video_ids"] = source_ids
        _batch_state["output_files"] = []

    dest_dir = custom_output_dir if custom_output_dir and os.path.exists(custom_output_dir) else OUTPUT_DIR
    os.makedirs(dest_dir, exist_ok=True)

    try:
        audio_local = resolve_audio_file(audio_source)
        audio_name = os.path.splitext(os.path.basename(audio_local))[0].replace("cached_", "")

        created_ids = []
        output_files = []

        for idx, item in enumerate(video_items, 1):
            src_path = item.get("filepath")
            original_title = item.get("title") or os.path.basename(src_path)
            item_id = item.get("id")

            with _batch_lock:
                _batch_state["current_file"] = os.path.basename(src_path)
                _batch_state["processed"] = idx - 1

            if not os.path.exists(src_path):
                continue

            base_name, ext = os.path.splitext(os.path.basename(src_path))
            out_filename = f"{base_name} [DGS Edit {int(datetime.now().timestamp())}]{ext}"
            out_path = os.path.join(dest_dir, out_filename)

            # Processa no FFmpeg (troca áudio com precisão de corte)
            process_single_video(src_path, audio_local, start_seconds, out_path)
            output_files.append(out_path)

            # Salva na pasta de vídeos da biblioteca
            lib_dest = os.path.join(VIDEOS_DIR, out_filename)
            if dest_dir != VIDEOS_DIR:
                shutil.copy2(out_path, lib_dest)
            else:
                lib_dest = out_path

            filesize = os.path.getsize(lib_dest)
            clean_title = original_title.split(" (Música:")[0].split(" [DGS Edit")[0].strip()
            new_title = f"{clean_title} (Música: {audio_name[:25]})"

            if item_id:
                # O vídeo veio da biblioteca da central: atualiza o registro diretamente
                thumb_path = os.path.join(THUMBNAILS_DIR, f"{item_id}.jpg")
                generate_thumbnail(lib_dest, thumb_path)
                update_video_file(
                    video_id=item_id,
                    filepath=lib_dest,
                    filename=out_filename,
                    filesize=filesize,
                    title=new_title,
                    thumbnail_path=thumb_path
                )
                created_ids.append(item_id)
            else:
                # O vídeo foi enviado via upload: cadastra como novo vídeo na biblioteca
                vid_id = add_video(
                    filename=out_filename,
                    filepath=lib_dest,
                    title=new_title,
                    caption=item.get("caption", ""),
                    hashtags=item.get("hashtags", ""),
                    filesize=filesize
                )
                thumb_path = os.path.join(THUMBNAILS_DIR, f"{vid_id}.jpg")
                generate_thumbnail(lib_dest, thumb_path)
                created_ids.append(vid_id)

            with _batch_lock:
                _batch_state["processed"] = idx

        with _batch_lock:
            _batch_state["status"] = "completed"
            _batch_state["created_video_ids"] = created_ids
            _batch_state["source_video_ids"] = source_ids
            _batch_state["target_video_ids"] = created_ids if len(created_ids) > 0 else source_ids
            _batch_state["output_files"] = output_files
            _batch_state["current_file"] = ""

        add_log(f"Lote do Editor de Músicas finalizado: {len(output_files)} vídeos processados com sucesso!", "SUCCESS")

    except Exception as e:
        with _batch_lock:
            _batch_state["status"] = "error"
            _batch_state["error"] = str(e)
        add_log(f"Erro no processamento do lote do Editor de Músicas: {str(e)}", "ERROR")

def start_batch_processing(audio_source: str, start_seconds: float, video_items: List[Dict[str, Any]], save_to_library: bool = True, custom_output_dir: Optional[str] = None):
    with _batch_lock:
        if _batch_state["status"] == "processing":
            raise Exception("Já existe um lote de vídeos sendo processado no momento.")

    t = threading.Thread(
        target=_run_batch_worker,
        args=(audio_source, start_seconds, video_items, save_to_library, custom_output_dir),
        daemon=True
    )
    t.start()
    return {"success": True, "message": "Processamento iniciado em segundo plano."}
