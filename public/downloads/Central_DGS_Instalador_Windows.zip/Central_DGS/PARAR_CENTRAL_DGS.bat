@echo off
chcp 65001 >nul
title Encerrar Central DGS
color 0C

echo ========================================================
echo               ENCERRAR CENTRAL DGS
echo ========================================================
echo.
echo Fechando processos da Central DGS e liberando porta 8787...

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8787') do (
    taskkill /F /PID %%a >nul 2>&1
)

echo [+] Processos encerrados com sucesso!
timeout /t 3 >nul
exit /b 0
