@echo off
chcp 65001 >nul
title Central DGS - Studio 3 Redes
color 0E

echo ========================================================
echo         CENTRAL DGS - STUDIO DE AGENDAMENTO
echo        Instagram Reels - TikTok - YouTube Shorts
echo ========================================================
echo.
echo Iniciando servidor e painel visual...
echo O painel abrira automaticamente em: http://127.0.0.1:8787
echo.

cd /d "%~dp0"

if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" run.py
) else (
    python run.py
)

pause
