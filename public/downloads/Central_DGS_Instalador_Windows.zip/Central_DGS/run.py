import os
import sys
import webbrowser
import threading
import time
import socket
import urllib.request
import urllib.error
import subprocess
import uvicorn

def ensure_interactive_desktop():
    """
    Garante que a Central DGS execute no desktop interativo do usuario ('Default' na 'winsta0').
    Se iniciado dentro de um ambiente sandbox ou desktop oculto (como subshells do sistema),
    re-executa a si mesmo na area de trabalho visivel para que qualquer janela do Chrome
    (navegador visivel) abra normalmente na tela principal.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        hdesk = user32.GetThreadDesktop(kernel32.GetCurrentThreadId())
        buf = ctypes.create_unicode_buffer(256)
        user32.GetUserObjectInformationW(hdesk, 2, buf, 256, None)
        desk_name = buf.value
        
        # Se ja estiver no desktop Default do usuario, continua normalmente
        if not desk_name or desk_name.lower() == "default":
            return

        print(f"[Central DGS] Executando no desktop '{desk_name}'. Re-iniciando no desktop interativo 'winsta0\\default'...")
        
        class STARTUPINFO(ctypes.Structure):
            _fields_ = [
                ('cb', wintypes.DWORD), ('lpReserved', wintypes.LPWSTR), ('lpDesktop', wintypes.LPWSTR),
                ('lpTitle', wintypes.LPWSTR), ('dwX', wintypes.DWORD), ('dwY', wintypes.DWORD),
                ('dwXSize', wintypes.DWORD), ('dwYSize', wintypes.DWORD), ('dwXCountChars', wintypes.DWORD),
                ('dwYCountChars', wintypes.DWORD), ('dwFillAttribute', wintypes.DWORD), ('dwFlags', wintypes.DWORD),
                ('wShowWindow', wintypes.WORD), ('cbReserved2', wintypes.WORD), ('lpReserved2', ctypes.c_char_p),
                ('hStdInput', wintypes.HANDLE), ('hStdOutput', wintypes.HANDLE), ('hStdError', wintypes.HANDLE),
            ]

        class PROCESS_INFORMATION(ctypes.Structure):
            _fields_ = [
                ('hProcess', wintypes.HANDLE), ('hThread', wintypes.HANDLE),
                ('dwProcessId', wintypes.DWORD), ('dwThreadId', wintypes.DWORD),
            ]

        si = STARTUPINFO()
        si.cb = ctypes.sizeof(STARTUPINFO)
        si.lpDesktop = 'winsta0\\default'
        si.dwFlags = 0x00000100  # STARTF_USESTDHANDLES
        si.hStdInput = kernel32.GetStdHandle(-10)
        si.hStdOutput = kernel32.GetStdHandle(-11)
        si.hStdError = kernel32.GetStdHandle(-12)
        pi = PROCESS_INFORMATION()

        cmd = subprocess.list2cmdline([sys.executable] + sys.argv)
        res = kernel32.CreateProcessW(None, cmd, None, None, True, 0, None, None, ctypes.byref(si), ctypes.byref(pi))
        if res:
            kernel32.WaitForSingleObject(pi.hProcess, 0xFFFFFFFF)
            exit_code = wintypes.DWORD()
            kernel32.GetExitCodeProcess(pi.hProcess, ctypes.byref(exit_code))
            kernel32.CloseHandle(pi.hProcess)
            kernel32.CloseHandle(pi.hThread)
            sys.exit(exit_code.value)
        else:
            print("[Central DGS] Aviso: Nao foi possivel alternar desktop:", kernel32.GetLastError())
    except Exception as e:
        print("[Central DGS] Erro em ensure_interactive_desktop:", e)

ensure_interactive_desktop()

def check_http_health(port: int = 8787, timeout: float = 1.0) -> bool:
    """Verifica se o servidor da Central está ativo e respondendo na porta."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/stats", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False

def clean_zombie_port(port: int = 8787):
    """
    Se a porta 8787 estiver ocupada por um processo fantasma que não responde a requisições,
    encerra o processo travado para permitir a inicialização limpa da Central.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        if s.connect_ex(('127.0.0.1', port)) != 0:
            return  # Porta livre

    # Porta tem conexão: testa se está saudável
    if check_http_health(port, timeout=1.0):
        return  # Está saudável, reutiliza

    # Processo travado (zombie): mata
    print(f"[Central DGS] Detectado processo travado na porta {port}. Liberando porta...")
    try:
        out = subprocess.check_output(f'netstat -ano | findstr :{port}', shell=True).decode(errors="ignore")
        current_pid = str(os.getpid())
        for line in out.strip().splitlines():
            if "LISTENING" in line:
                pid = line.strip().split()[-1]
                if pid and pid.isdigit() and pid != current_pid:
                    print(f"[Central DGS] Encerrando processo órfão (PID {pid})...")
                    subprocess.call(f'taskkill /F /PID {pid}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1.0)
    except Exception as e:
        print("[Central DGS] Aviso ao verificar porta:", e)

def wait_for_server_ready(port: int = 8787, max_wait: float = 15.0) -> bool:
    """Aguarda ativamente até que o servidor HTTP esteja 100% pronto e respondendo 200 OK."""
    start_time = time.time()
    url = f"http://127.0.0.1:{port}/api/stats"
    while time.time() - start_time < max_wait:
        try:
            with urllib.request.urlopen(url, timeout=0.6) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(0.15)
    return False

def open_browser():
    print("[Central DGS] Aguardando inicialização completa do motor e servidor...")
    ready = wait_for_server_ready(8787, max_wait=15.0)
    if ready:
        print("[Central DGS] Servidor 100% pronto! Abrindo painel visual...")
    else:
        print("[Central DGS] Aviso: Servidor demorou para responder, abrindo navegador...")

    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe")
    ]
    chrome_exe = None
    for cp in chrome_paths:
        if os.path.exists(cp):
            chrome_exe = cp
            break

    base_dir = os.path.dirname(os.path.abspath(__file__))
    shared_profile = os.path.join(base_dir, "storage", "profiles", "app_browser")
    os.makedirs(shared_profile, exist_ok=True)

    if chrome_exe:
        print("\n[Central DGS] Abrindo Chrome integrado (CDP porta 9222): http://127.0.0.1:8787\n")
        try:
            subprocess.Popen([
                chrome_exe,
                "--remote-debugging-port=9222",
                "--start-maximized",
                f"--user-data-dir={shared_profile}",
                "--no-first-run",
                "--no-default-browser-check",
                "http://127.0.0.1:8787"
            ])
            return
        except Exception as e:
            print("[Central DGS] Falha ao iniciar Chrome CDP, abrindo navegador padrão:", e)

    print("\n[Central DGS] Abrindo painel no navegador padrão: http://127.0.0.1:8787\n")
    webbrowser.open("http://127.0.0.1:8787")

if __name__ == "__main__":
    print("=" * 60)
    print("   CENTRAL DGS - STUDIO 3 REDES (Instagram, TikTok, YouTube)   ")
    print("=" * 60)

    # 1. Libera a porta se houver processo zumbi travado
    clean_zombie_port(8787)

    # 2. Se já houver uma instância saudável da Central rodando, reutiliza e abre a janela
    if check_http_health(8787, timeout=1.0):
        print("[Central DGS] Servidor da Central já está rodando ativo e saudável na porta 8787!")
        print("[Central DGS] Abrindo interface no navegador...")
        open_browser()
        print("\nPressione CTRL+C para fechar esta janela.")
        try:
            while True:
                time.sleep(2)
        except KeyboardInterrupt:
            sys.exit(0)

    print("Iniciando motor e servidor local na porta 8787...")

    # 3. Abre o navegador automaticamente apenas quando o servidor responder 200 OK
    threading.Thread(target=open_browser, daemon=True).start()

    # 4. Inicia o servidor FastAPI com Uvicorn
    uvicorn.run("backend.app:app", host="127.0.0.1", port=8787, log_level="info", reload=True)
