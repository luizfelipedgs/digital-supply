@echo off
chcp 65001 > nul
title Central DGS - Atualizador Automático
color 0A

echo =======================================================================
echo          CENTRAL DGS - ATUALIZADOR OFICIAL (DIGITAL SUPPLY)
echo =======================================================================
echo.
echo Verificando ambiente de execução...

cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    set "PYTHON_CMD=.venv\Scripts\python.exe"
) else (
    set "PYTHON_CMD=python"
)

echo Iniciando verificação de atualizações...
echo.

:: Auto-correção preventiva de banco de dados
"%PYTHON_CMD%" -c "import sqlite3, os; p='storage/central.db'; [conn:=sqlite3.connect(p), [conn.execute(sql) for sql in ['ALTER TABLE logs ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP', 'ALTER TABLE logs ADD COLUMN timestamp TEXT DEFAULT CURRENT_TIMESTAMP']], conn.commit(), conn.close()] if os.path.exists(p) else None" > nul 2>&1

"%PYTHON_CMD%" -m backend.updater

exit /b 0
