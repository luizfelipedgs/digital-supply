"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.3.1"
BUILD_DATE = "2026-11-24"
APP_NAME = "Central DGS"
DESCRIPTION = "Central Desktop Unificada - Agendamento 3 Redes (Instagram, TikTok, YouTube), Editor de Músicas com Motor Nativo DGS e Gestão Completa."
