"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.1.0"
BUILD_DATE = "2026-11-22"
APP_NAME = "Central DGS"
DESCRIPTION = "Central Desktop Unificada - Agendamento 3 Redes (Instagram, TikTok, YouTube), Editor de Músicas e Gestão Completa."
