"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.3.5"
BUILD_DATE = "2026-11-24"
APP_NAME = "Central DGS"
DESCRIPTION = "Central Desktop Unificada - Novo Calendário estilo Creator Studio, visualização mensal/semanal por dia e horário, e redirecionamento direto para Agenda & Fila após agendamento."
