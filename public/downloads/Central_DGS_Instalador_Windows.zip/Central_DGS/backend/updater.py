import os
import sys
import json
import time
import shutil
import zipfile
import subprocess
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple, List

from backend.version import VERSION, BUILD_DATE, APP_NAME
from backend.database import get_setting, set_setting, add_log

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STORAGE_DIR = os.path.join(BASE_DIR, "storage")

UPDATE_CHECK_URLS = [
    "https://digitalsupply.pro/api/desktop/version",
    "https://digitalsupply.pro/downloads/version.json",
    # Fallback local se o site estiver sendo executado localmente
    "http://127.0.0.1:3000/api/desktop/version"
]

def parse_semver(v_str: str) -> Tuple[int, ...]:
    """Converte '2.1.0' em tupla (2, 1, 0) para comparação correta de versão."""
    clean = v_str.strip().lower().lstrip("v")
    parts = []
    for part in clean.split("."):
        digits = "".join(c for c in part if c.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)

def check_for_updates() -> Dict[str, Any]:
    """
    Verifica se existe uma nova versão da Central DGS disponível no servidor oficial.
    Retorna o status atual, versão mais recente e notas da versão.
    """
    headers = {
        "User-Agent": f"CentralDGS-Desktop/{VERSION} (Windows)",
        "Accept": "application/json"
    }

    last_error = None
    data = None

    for url in UPDATE_CHECK_URLS:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                if resp.status == 200:
                    raw = resp.read().decode("utf-8")
                    data = json.loads(raw)
                    break
        except Exception as e:
            last_error = str(e)
            continue

    # Se não conseguiu conexão com os servidores remotos, tenta fallback no diretório local do site (se existir)
    if not data:
        local_json_path = os.path.join("D:\\Site DGS", "digital-supply", "public", "downloads", "version.json")
        if os.path.exists(local_json_path):
            try:
                with open(local_json_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception as e:
                last_error = str(e)

    if not data:
        return {
            "current_version": VERSION,
            "latest_version": VERSION,
            "update_available": False,
            "error": last_error or "Não foi possível conectar ao servidor de atualizações.",
            "release_notes": [],
            "patch_url": "",
            "download_url": ""
        }

    latest_version = data.get("version", VERSION)
    is_newer = parse_semver(latest_version) > parse_semver(VERSION)

    return {
        "current_version": VERSION,
        "latest_version": latest_version,
        "update_available": is_newer,
        "release_date": data.get("release_date", ""),
        "release_notes": data.get("release_notes", []),
        "patch_url": data.get("patch_url", ""),
        "download_url": data.get("download_url", ""),
        "min_compatible_version": data.get("min_compatible_version", "2.0.0")
    }

def download_patch(patch_url: str, dest_path: str) -> None:
    """Baixa o pacote de atualização ZIP para o caminho de destino com cabeçalhos apropriados."""
    if os.path.exists(patch_url):
        # Se for um caminho de arquivo local
        shutil.copy2(patch_url, dest_path)
        return

    headers = {
        "User-Agent": f"CentralDGS-Desktop/{VERSION} (Windows)"
    }
    req = urllib.request.Request(patch_url, headers=headers)
    with urllib.request.urlopen(req, timeout=30.0) as resp:
        with open(dest_path, "wb") as out_f:
            while chunk := resp.read(65536):
                out_f.write(chunk)

def apply_update(patch_url: Optional[str] = None) -> Dict[str, Any]:
    """
    Baixa e aplica com segurança o pacote de atualização da Central DGS.
    
    REGRA DE SEGURANÇA CRÍTICA:
    - NUNCA sobrescreve ou modifica arquivos dentro de 'storage/' (banco central.db, perfis, cookies e vídeos).
    - Apenas atualiza código de 'backend/', 'frontend/', 'scripts/', 'requirements.txt' e inicializadores.
    """
    # 1. Se patch_url não for fornecido, obtém o mais recente
    if not patch_url:
        info = check_for_updates()
        patch_url = info.get("patch_url")
        if not patch_url:
            # Fallback se não informado e patch local existir
            local_patch = os.path.join("D:\\Site DGS", "digital-supply", "public", "downloads", "Central_DGS_Patch.zip")
            if os.path.exists(local_patch):
                patch_url = local_patch
            else:
                raise Exception("URL do pacote de atualização não encontrada.")

    os.makedirs(STORAGE_DIR, exist_ok=True)
    temp_zip = os.path.join(STORAGE_DIR, "temp_update.zip")

    try:
        add_log("INFO", f"Iniciando download da atualização a partir de: {patch_url}")
        download_patch(patch_url, temp_zip)

        if not os.path.exists(temp_zip) or os.path.getsize(temp_zip) < 1000:
            raise Exception("Pacote de atualização inválido ou corrompido durante o download.")

        # Valida integridade do ZIP
        if not zipfile.is_zipfile(temp_zip):
            raise Exception("O arquivo baixado não é um arquivo ZIP válido.")

        add_log("INFO", "Pacote baixado com sucesso. Aplicando atualizações de arquivos...")

        # Lista de pastas e extensões permitidas para atualização segura
        SAFE_PREFIXES = ("backend/", "frontend/", "scripts/")
        SAFE_FILES = (
            "requirements.txt",
            "run.py",
            "validate_integrity.py",
            "Launcher_Central_DGS.exe",
            "INSTALAR_CENTRAL_DGS.bat",
            "INICIAR_CENTRAL_DGS.bat",
            "INICIAR_CENTRAL_DGS.vbs",
            "ATUALIZAR_CENTRAL_DGS.bat",
            "PARAR_CENTRAL_DGS.bat",
            "LEIA_ME_PRIMEIROS_PASSOS.txt"
        )

        updated_count = 0

        with zipfile.ZipFile(temp_zip, "r") as z:
            namelist = z.namelist()

            for item in namelist:
                # Normaliza separador
                norm_item = item.replace("\\", "/")

                # Ignora diretórios e metadados
                if norm_item.endswith("/") or "__MACOSX" in norm_item:
                    continue

                # Proteção anti-traversal
                if ".." in norm_item or norm_item.startswith("/"):
                    continue

                # REGRA DE SEGURANÇA MÁXIMA: NUNCA tocar na pasta storage ou banco de dados do aluno
                if norm_item.startswith("storage/") or "central.db" in norm_item.lower():
                    continue

                # Normaliza caminho relativo (alguns zips colocam Central_DGS/ como raiz)
                rel_path = norm_item
                if rel_path.startswith("Central_DGS/"):
                    rel_path = rel_path[len("Central_DGS/"):]

                # Valida se é um arquivo seguro para atualização
                is_safe = rel_path.startswith(SAFE_PREFIXES) or rel_path in SAFE_FILES
                if not is_safe:
                    continue

                dest_file = os.path.join(BASE_DIR, os.path.normpath(rel_path))
                os.makedirs(os.path.dirname(dest_file), exist_ok=True)

                # Extrai sobrescrevendo o arquivo existente
                with z.open(item, "r") as src, open(dest_file, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                updated_count += 1

        # Limpa caches Python (__pycache__)
        for root, dirs, files in os.walk(BASE_DIR):
            if "__pycache__" in dirs:
                try:
                    shutil.rmtree(os.path.join(root, "__pycache__"))
                except Exception:
                    pass

        # Registra atualização no banco
        set_setting("last_updated_at", str(time.time()))
        add_log("INFO", f"Central DGS atualizada com sucesso! {updated_count} arquivos atualizados.")

        return {
            "success": True,
            "updated_files_count": updated_count,
            "message": f"Central DGS atualizada com sucesso ({updated_count} arquivos instalados)."
        }

    finally:
        if os.path.exists(temp_zip):
            try:
                os.remove(temp_zip)
            except Exception:
                pass

def restart_central() -> None:
    """
    Reinicia o processo da Central DGS de forma limpa e desanexada.
    """
    python_exe = sys.executable
    run_script = os.path.join(BASE_DIR, "run.py")

    # Comando em background para aguardar 1 segundo e iniciar a Central novamente
    cmd = f'ping 127.0.0.1 -n 2 > nul & "{python_exe}" "{run_script}"'
    subprocess.Popen(cmd, shell=True, cwd=BASE_DIR, creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))

    # Dá um breve tempo para a resposta da API retornar antes do encerramento
    def delayed_exit():
        time.sleep(0.8)
        os._exit(0)

    import threading
    threading.Thread(target=delayed_exit, daemon=True).start()

def main_cli():
    """Modo linha de comando interativo para o script ATUALIZAR_CENTRAL_DGS.bat"""
    print("=" * 65)
    print("          ATUALIZADOR AUTOMÁTICO - CENTRAL DGS")
    print("=" * 65)
    print(f"Versão instalada: v{VERSION}")
    print("Verificando se há novas atualizações no servidor oficial...")

    info = check_for_updates()
    latest = info.get("latest_version", VERSION)
    update_avail = info.get("update_available", False)

    if not update_avail:
        print(f"\n[OK] A sua Central DGS já está atualizada na versão mais recente (v{VERSION})!")
        if "--force" not in sys.argv:
            print("Nenhuma ação necessária.")
            input("\nPressione ENTER para fechar...")
            return

    print(f"\n[NOVA VERSÃO ENCONTRADA] Versão v{latest} disponível!")
    notes = info.get("release_notes", [])
    if notes:
        print("\nNovidades desta versão:")
        for n in notes:
            print(f"  • {n}")

    print("\nAVISO: Seus dados, contas conectadas, vídeos e agendamentos")
    print("serão 100% PRESERVADOS com total segurança.")
    
    if "--yes" not in sys.argv and "--cli" not in sys.argv:
        conf = input("\nDeseja instalar a atualização agora? (S/N): ").strip().upper()
        if conf not in ("S", "SIM", "Y", "YES"):
            print("Atualização cancelada pelo usuário.")
            return

    print("\nBaixando e instalando atualização...")
    try:
        res = apply_update(info.get("patch_url"))
        print(f"[SUCESSO] {res.get('message')}")
        print("\nCentral DGS pronta para uso!")
        
        start = input("\nDeseja iniciar a Central DGS agora? (S/N): ").strip().upper()
        if start in ("S", "SIM", "Y", "YES", ""):
            run_script = os.path.join(BASE_DIR, "INICIAR_CENTRAL_DGS.bat")
            if os.path.exists(run_script):
                subprocess.Popen([run_script], shell=True, cwd=BASE_DIR)
    except Exception as e:
        print(f"\n[ERRO] Falha ao aplicar atualização: {e}")
        input("\nPressione ENTER para fechar...")

if __name__ == "__main__":
    main_cli()
