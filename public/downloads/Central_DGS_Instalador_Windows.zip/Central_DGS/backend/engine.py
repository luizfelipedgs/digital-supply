import asyncio
import os
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

from backend.database import (
    get_setting, set_setting, get_queue, update_queue_status,
    get_account_by_id, add_log, get_accounts
)
from backend.automation.instagram import post_instagram_reel, schedule_instagram_batch
from backend.automation.tiktok import post_tiktok_video
from backend.automation.youtube import post_youtube_short
from backend.automation.browser_manager import run_proactor_async

class PublishingEngine:
    def __init__(self):
        self.is_running: bool = False
        self.started_at: Optional[datetime] = None
        self.current_in_flight: int = 0
        self.loop_task: Optional[asyncio.Task] = None

        # Campos de progresso em lote para a Visão Geral
        self.batch_active: bool = False
        self.batch_total: int = 0
        self.batch_current: int = 0
        self.batch_percent: int = 0
        self.batch_detail: str = ""
        self.batch_platform: str = ""

        # Recupera possíveis itens pendentes que ficaram travados em 'uploading'
        try:
            from backend.database import get_db
            conn = get_db()
            conn.execute("UPDATE queue SET status = 'pending', status_detail = 'Aguardando envio' WHERE status = 'uploading'")
            conn.commit()
            conn.close()
        except Exception:
            pass

    def reset_batch(self):
        """Reseta completamente o estado de processamento em lote."""
        self.batch_active = False
        self.batch_total = 0
        self.batch_current = 0
        self.batch_percent = 0
        self.batch_detail = ""
        self.batch_platform = ""
        self.current_in_flight = 0
        try:
            from backend.database import get_db
            conn = get_db()
            conn.execute("UPDATE queue SET status = 'pending', status_detail = 'Aguardando envio' WHERE status = 'uploading'")
            conn.commit()
            conn.close()
        except Exception:
            pass

    def start(self):
        if not self.is_running:
            self.is_running = True
            self.started_at = datetime.now()
            set_setting("engine_running", "true")
            add_log("Motor de agendamento INICIADO", "INFO")
            self.loop_task = asyncio.create_task(self._run_loop())

    def stop(self):
        if self.is_running:
            self.is_running = False
            set_setting("engine_running", "false")
            if self.loop_task:
                self.loop_task.cancel()
                self.loop_task = None
            add_log("Motor de agendamento PAUSADO", "WARNING")
        if self.batch_active:
            self.reset_batch()

    def get_status(self) -> Dict[str, Any]:
        uptime_str = "Parado"
        uptime_minutes = 0
        if self.is_running and self.started_at:
            delta = datetime.now() - self.started_at
            uptime_minutes = int(delta.total_seconds() // 60)
            uptime_str = f"há {uptime_minutes} min" if uptime_minutes > 0 else "há poucos segundos"

        accounts = get_accounts()
        active_accounts = len([a for a in accounts if a.get("status") == "active"])

        test_mode = get_setting("test_mode", "false") == "true"
        visible_browser = get_setting("visible_browser", "true") == "true"

        return {
            "running": self.is_running,
            "uptime_text": uptime_str,
            "uptime_minutes": uptime_minutes,
            "active_accounts": active_accounts,
            "in_flight": self.current_in_flight,
            "test_mode": test_mode,
            "visible_browser": visible_browser,
            "batch_active": self.batch_active,
            "batch_total": self.batch_total,
            "batch_current": self.batch_current,
            "batch_percent": self.batch_percent,
            "batch_detail": self.batch_detail,
            "batch_platform": self.batch_platform
        }

    async def _run_loop(self):
        while self.is_running:
            try:
                await self._check_and_process_queue()
            except asyncio.CancelledError:
                break
            except Exception as e:
                add_log(f"Erro no ciclo do motor: {str(e)}", "ERROR")

            await asyncio.sleep(15)

    async def process_meta_batch(self, account: Dict[str, Any], items: List[Dict[str, Any]]):
        """
        Executa a programação nativa de um lote de vídeos no Instagram Web (/scheduled_content/)
        com intervalo humano completo entre cada vídeo e feedback de progresso em tempo real na Visão Geral.
        """
        total = len(items)
        if total == 0:
            return

        self.batch_active = True
        self.batch_platform = "instagram"
        self.batch_total = total
        self.batch_current = 1
        self.batch_percent = 5
        self.batch_detail = f"Iniciando agendamento na Meta ({total} vídeos para {account['name']})..."
        self.current_in_flight = 1
        test_mode = get_setting("test_mode", "false") == "true"
        visible_browser = get_setting("visible_browser", "true") == "true"

        add_log(f"Iniciando lote de agendamento na Meta para {account['name']} ({total} vídeos)", "INFO", "instagram")

        if test_mode:
            for idx, item in enumerate(items, 1):
                base_pct = round(((idx - 1) / total) * 100)
                slice_pct = round((1.0 / total) * 100)

                self.batch_current = idx
                self.batch_percent = min(99, base_pct + round(0.35 * slice_pct))
                self.batch_detail = f"Modo Teste: Agendando vídeo {idx}/{total} na Meta..."
                await asyncio.sleep(2)

                self.batch_percent = min(99, base_pct + round(0.70 * slice_pct))
                self.batch_detail = f"Modo Teste: Vídeo {idx}/{total} confirmado na Meta!"
                await asyncio.sleep(1.5)

                if idx < total:
                    self.batch_percent = min(99, base_pct + round(0.95 * slice_pct))
                    self.batch_detail = f"Modo Teste ({self.batch_percent}%): Intervalo humano (Perfil -> Feed -> Reels)..."
                    await asyncio.sleep(2.5)

                update_queue_status(
                    item["id"],
                    status="published",
                    detail=f"Simulado na Meta ({item.get('scheduled_time', '')})",
                    published_url="https://www.instagram.com/scheduled_content/"
                )
                add_log(f"Post #{item['id']} simulado na Meta com sucesso!", "SUCCESS", "instagram")

            self.batch_percent = 100
            self.batch_detail = f"Modo Teste: Todos os {total} vídeos programados na Meta!"
            self.batch_active = False
            self.current_in_flight = 0
            return

        # Modo Real via Playwright + Navegador
        try:
            profile_dir = account.get("profile_dir")
            if not profile_dir or not os.path.exists(profile_dir):
                profile_dir = os.path.join(
                    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "storage", "profiles", f"instagram_{account['id']}"
                )
                os.makedirs(profile_dir, exist_ok=True)

            for it in items:
                update_queue_status(it["id"], "uploading", detail="Aguardando no lote de agendamento...")

            account_name = (account.get("username") or account.get("name") or "").strip()
            headless_mode = not visible_browser

            def on_progress(idx, tot, pct, msg):
                self.batch_current = idx
                self.batch_total = tot
                self.batch_percent = pct
                self.batch_detail = msg

            res = await run_proactor_async(
                schedule_instagram_batch,
                profile_dir=profile_dir,
                items=items,
                headless=headless_mode,
                account_name=account_name,
                progress_callback=on_progress
            )

            for item_res in res.get("results", []):
                qid = item_res.get("queue_id")
                s_res = item_res.get("result", {})
                if s_res.get("success"):
                    dt_detail = s_res.get("detail", "Programado na Meta")
                    update_queue_status(
                        qid,
                        status="published",
                        detail=dt_detail,
                        published_url=s_res.get("url", "https://www.instagram.com/scheduled_content/")
                    )
                    add_log(f"Post #{qid} agendado na Meta com sucesso! ({dt_detail})", "SUCCESS", "instagram")
                else:
                    err = s_res.get("error", "Falha ao agendar na Meta")
                    update_queue_status(qid, status="failed", detail=f"Falha na Meta: {err}", error_message=err)
                    add_log(f"Post #{qid} falhou no agendador da Meta: {err}", "ERROR", "instagram")

            self.batch_percent = 100
            self.batch_detail = f"Lote de {total} vídeos concluído na Meta!"
            self.batch_active = False

        except Exception as e_batch:
            self.batch_active = False
            self.batch_detail = f"Erro no processamento do lote: {str(e_batch)}"
            add_log(f"Erro no processamento do lote da Meta: {str(e_batch)}", "ERROR", "instagram")

        finally:
            self.batch_active = False
            self.current_in_flight = 0

    async def _check_and_process_queue(self):
        if self.current_in_flight > 0:
            return

        pending_items = get_queue(status="pending")
        if not pending_items:
            return

        now_str = datetime.now().isoformat()
        test_mode = get_setting("test_mode", "false") == "true"
        visible_browser = get_setting("visible_browser", "true") == "true"
        headless_mode = not visible_browser

        for item in pending_items:
            sched_time = item["scheduled_time"]
            if sched_time <= now_str:
                self.current_in_flight = 1
                queue_id = item["id"]
                platform = item["platform"].lower()
                account_id = item["account_id"]
                video_path = item["filepath"]
                title = item.get("display_title") or item.get("custom_title") or item.get("title") or "Vídeo Central DGS"
                caption = item.get("display_caption") or item.get("custom_caption") or item.get("caption") or ""
                hashtags = item.get("display_hashtags") or item.get("custom_hashtags") or item.get("hashtags") or ""

                account = get_account_by_id(account_id)
                if not account:
                    update_queue_status(queue_id, "failed", error_message="Conta associada não encontrada")
                    self.current_in_flight = 0
                    continue

                profile_dir = account.get("profile_dir")
                if not profile_dir or not os.path.exists(profile_dir):
                    profile_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "profiles", f"{platform}_{account_id}")
                    os.makedirs(profile_dir, exist_ok=True)

                update_queue_status(queue_id, "uploading", detail="Enviando para a rede...")
                add_log(f"Processando post #{queue_id} para {account['name']} ({platform})", "INFO", platform)

                if test_mode:
                    await asyncio.sleep(4)
                    update_queue_status(
                        queue_id,
                        status="published",
                        detail="Simulado com sucesso (Modo Teste)",
                        published_url="https://localhost:8787/teste"
                    )
                    add_log(f"Post #{queue_id} concluído no Modo Teste", "SUCCESS", platform)
                    self.current_in_flight = 0
                    continue

                result = {"success": False, "error": "Plataforma não suportada"}
                mode_str = "VISÍVEL NA TELA" if visible_browser else "BACKGROUND (Oculto)"
                add_log(f"Motor iniciando disparo no modo {mode_str} para {account['name']} ({platform})", "INFO", platform)

                try:
                    if platform == "tiktok":
                        sound_name = item.get("custom_sound") or ""
                        result = await run_proactor_async(post_tiktok_video, profile_dir, video_path, caption, hashtags, headless_mode, sound_name, account["name"])
                    elif platform == "instagram":
                        result = await run_proactor_async(post_instagram_reel, profile_dir, video_path, caption, hashtags, headless_mode, account["name"])
                    elif platform == "youtube":
                        result = await run_proactor_async(post_youtube_short, profile_dir, video_path, title, caption, hashtags, headless_mode)
                except Exception as ex:
                    result = {"success": False, "error": str(ex)}

                if result.get("success"):
                    update_queue_status(
                        queue_id,
                        status="published",
                        detail=result.get("detail", "publicado e confirmado"),
                        published_url=result.get("url", "")
                    )
                    add_log(f"Post #{queue_id} publicado com sucesso em {account['name']}!", "SUCCESS", platform)
                else:
                    err = result.get("error", "Falha desconhecida no envio")
                    attempts = item.get("attempts", 0) + 1

                    is_security_alert = any(k in err.lower() for k in [
                        "restricted", "restriç", "bloque", "challenge", "humano", "verificação", 
                        "sessão não autenticada", "login necessário", "checkpoint"
                    ])

                    if is_security_alert or attempts >= 3:
                        status_detail = f"Interrompido por proteção: {err}" if is_security_alert else "Falhou após 3 tentativas"
                        update_queue_status(queue_id, status="failed", detail=status_detail, error_message=err)
                        add_log(f"Post #{queue_id} cancelado preventivamente ({status_detail}) para proteger a conta {account['name']}.", "ERROR", platform)
                    else:
                        update_queue_status(queue_id, status="pending", detail=f"tentativa {attempts} falhou, reagendando...", error_message=err)
                        add_log(f"Tentativa {attempts} do post #{queue_id} falhou. Tentará novamente: {err}", "WARNING", platform)

                self.current_in_flight = 0
                await asyncio.sleep(5)

engine = PublishingEngine()
