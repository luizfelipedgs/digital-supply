"""
Script de Auditoria e Verificação de Integridade - Central DGS
Executa verificações completas no Frontend (HTML/JS) e Backend (FastAPI/Supabase)
para garantir que a Central DGS nunca inicialize com falhas ou trave na tela de carregamento.
"""

import sys
import os
import json
import urllib.request
import re

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def check_html_js_syntax():
    print("[1/3] Verificando integridade sintática do Frontend (index.html)...")
    html_path = os.path.join(BASE_DIR, "frontend", "index.html")
    if not os.path.exists(html_path):
        print("  ERRO: frontend/index.html não encontrado!")
        return False

    with open(html_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Extrai blocos <script>
    scripts = re.findall(r"<script>(.*?)</script>", content, re.DOTALL)
    if not scripts:
        print("  ERRO: Nenhum bloco <script> encontrado!")
        return False

    total_braces = 0
    total_parens = 0
    total_brackets = 0

    for i, script in enumerate(scripts):
        # Validação de balanceamento de chaves, parênteses e colchetes
        open_b = script.count("{")
        close_b = script.count("}")
        open_p = script.count("(")
        close_p = script.count(")")
        open_k = script.count("[")
        close_k = script.count("]")

        if open_b != close_b:
            print(f"  ALERTA: Desbalanceamento de chaves {{}}: {open_b} abertas vs {close_b} fechadas (script {i+1})")
        if open_p != close_p:
            print(f"  ALERTA: Desbalanceamento de parênteses (): {open_p} abertos vs {close_p} fechados (script {i+1})")
        if open_k != close_k:
            print(f"  ALERTA: Desbalanceamento de colchetes []: {open_k} abertos vs {close_k} fechados (script {i+1})")

    # Verifica IDs essenciais para a interface
    required_ids = [
        "user-display-name",
        "user-avatar-initial",
        "user-avatar-img",
        "user-subscription-period",
        "user-badge-adm",
        "section-admin",
        "stat-accounts-total",
        "stat-published-today",
        "stat-pending-today",
        "dash-cover-banner"
    ]
    missing_ids = [req for req in required_ids if f'id="{req}"' not in content and f"id='{req}'" not in content]
    if missing_ids:
        print(f"  ERRO: IDs vitais ausentes no HTML: {missing_ids}")
        return False

    print("  ✓ Frontend HTML e elementos essenciais verificados com sucesso!")
    return True

def check_backend_api():
    print("[2/3] Verificando rotas e respostas da API FastAPI...")
    endpoints = [
        ("/api/stats", ["total_accounts", "current_date_str", "greeting"]),
        ("/api/auth/session", ["authenticated", "has_access"]),
        ("/api/accounts", None),
        ("/api/videos", None),
        ("/api/queue", None),
        ("/api/engine/status", ["running"])
    ]

    all_passed = True
    for ep, required_keys in endpoints:
        url = f"http://127.0.0.1:8787{ep}"
        try:
            with urllib.request.urlopen(url, timeout=2.5) as resp:
                if resp.status != 200:
                    print(f"  FALHA em {ep}: Retornou status HTTP {resp.status}")
                    all_passed = False
                    continue
                body = resp.read().decode("utf-8")
                data = json.loads(body)
                if required_keys and isinstance(data, dict):
                    for k in required_keys:
                        if k not in data:
                            print(f"  FALHA em {ep}: Chave obrigatória '{k}' não encontrada na resposta!")
                            all_passed = False
                print(f"  ✓ {ep}: 200 OK")
        except Exception as e:
            print(f"  ERRO de conexão com {ep}: {e}")
            all_passed = False

    return all_passed

def check_chrome_cdp():
    print("[3/3] Verificando conexão do Chrome e renderização da página...")
    try:
        with urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=2.0) as resp:
            tabs = json.loads(resp.read().decode("utf-8"))
            central_tab = [t for t in tabs if "8787" in t.get("url", "")]
            if central_tab:
                print(f"  ✓ Chrome CDP ativo (Porta 9222): Painel aberto e conectado ({central_tab[0].get('title', '')})")
                return True
            else:
                print("  ! Chrome CDP ativo, mas aba da Central (8787) não encontrada.")
                return False
    except Exception as e:
        print(f"  ! Chrome CDP (porta 9222) não disponível no momento: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("   CENTRAL DGS - AUDITORIA DE INTEGRIDADE DO SISTEMA")
    print("=" * 60)
    frontend_ok = check_html_js_syntax()
    backend_ok = check_backend_api()
    chrome_ok = check_chrome_cdp()

    print("=" * 60)
    if frontend_ok and backend_ok:
        print("RESULTADO: CENTRAL DGS 100% OPERACIONAL E PROTEGIDA CONTRA FALHAS!")
        sys.exit(0)
    else:
        print("RESULTADO: Foram identificadas inconsistências no sistema!")
        sys.exit(1)
