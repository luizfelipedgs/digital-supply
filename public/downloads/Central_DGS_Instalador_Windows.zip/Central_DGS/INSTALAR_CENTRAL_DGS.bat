@echo off
chcp 65001 >nul
title INSTALADOR CENTRAL DGS - DIGITAL SUPPLY
color 0A

echo =======================================================================
echo               DIGITAL SUPPLY - COMUNIDADE OFICIAL DGS
echo                  INSTALADOR AUTOMÁTICO - CENTRAL DGS
echo =======================================================================
echo.
echo Olá Aluno! Este assistente vai configurar a Central DGS no seu computador.
echo Tudo será preparado de forma 100%% automática.
echo.
pause

echo.
echo [1/5] Verificando instalação do Python no seu computador...
set "PYTHON_CMD="

python --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=python"
    goto :PYTHON_OK
)

py -3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=py -3"
    goto :PYTHON_OK
)

echo [!] Python não encontrado. Tentando instalar automaticamente via Windows Package Manager...
winget install Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] Python 3.12 instalado com sucesso pelo Windows!
    timeout /t 3 >nul
    python --version >nul 2>&1
    if %errorlevel% equ 0 (
        set "PYTHON_CMD=python"
        goto :PYTHON_OK
    )
)

echo.
echo [ATENÇÃO] Não foi possível instalar o Python automaticamente.
echo Por favor, baixe e instale o Python 3.12 ou superior em:
echo https://www.python.org/downloads/
echo.
echo IMPORTANTE: Na tela de instalação, MARQUE a caixinha:
echo [X] "Add python.exe to PATH"
echo.
pause
exit /b 1

:PYTHON_OK
echo [+] Python detectado com sucesso!
%PYTHON_CMD% --version

echo.
echo [2/5] Criando ambiente virtual isolado (.venv)...
cd /d "%~dp0"
if not exist ".venv" (
    %PYTHON_CMD% -m venv .venv
    if %errorlevel% neq 0 (
        echo [!] Aviso ao criar ambiente virtual, continuando com Python do sistema...
        set "ENV_PYTHON=%PYTHON_CMD%"
    ) else (
        echo [+] Ambiente virtual (.venv) criado com sucesso!
        set "ENV_PYTHON=%~dp0.venv\Scripts\python.exe"
    )
) else (
    echo [+] Ambiente virtual (.venv) já existente.
    set "ENV_PYTHON=%~dp0.venv\Scripts\python.exe"
)

echo.
echo [3/5] Instalando dependências e bibliotecas do sistema...
if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
    "%~dp0.venv\Scripts\python.exe" -m pip install -r requirements.txt
) else (
    %PYTHON_CMD% -m pip install --upgrade pip --quiet
    %PYTHON_CMD% -m pip install -r requirements.txt
)
if %errorlevel% neq 0 (
    echo [!] Aviso: Algumas dependências reportaram avisos, continuando...
) else (
    echo [+] Todas as dependências foram instaladas com sucesso!
)

echo.
echo [4/5] Instalando navegador de automação (Playwright Chromium)...
if exist "%~dp0.venv\Scripts\playwright.exe" (
    "%~dp0.venv\Scripts\playwright.exe" install chromium
) else (
    playwright install chromium
)
echo [+] Navegador Chromium configurado com sucesso!

echo.
echo [5/5] Criando atalhos na Área de Trabalho e Menu Iniciar...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$WshShell = New-Object -ComObject WScript.Shell; " ^
    "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
    "$shortcut = $WshShell.CreateShortcut(\"$desktop\Central DGS.lnk\"); " ^
    "$shortcut.TargetPath = \"wscript.exe\"; " ^
    "$shortcut.Arguments = \"`\"%~dp0INICIAR_CENTRAL_DGS.vbs`\"\"; " ^
    "$shortcut.WorkingDirectory = \"%~dp0\"; " ^
    "$icon = \"%~dp0frontend\static\icon.ico\"; " ^
    "if (Test-Path $icon) { $shortcut.IconLocation = \"$icon,0\" }; " ^
    "$shortcut.Description = \"Central DGS - Comunidade Digital Supply\"; " ^
    "$shortcut.Save(); " ^
    "$startMenu = [Environment]::GetFolderPath('StartMenu') + '\Programs\Digital Supply'; " ^
    "if (!(Test-Path $startMenu)) { New-Item -ItemType Directory -Path $startMenu -Force | Out-Null }; " ^
    "$shortcut2 = $WshShell.CreateShortcut(\"$startMenu\Central DGS.lnk\"); " ^
    "$shortcut2.TargetPath = \"wscript.exe\"; " ^
    "$shortcut2.Arguments = \"`\"%~dp0INICIAR_CENTRAL_DGS.vbs`\"\"; " ^
    "$shortcut2.WorkingDirectory = \"%~dp0\"; " ^
    "if (Test-Path $icon) { $shortcut2.IconLocation = \"$icon,0\" }; " ^
    "$shortcut2.Description = \"Central DGS - Comunidade Digital Supply\"; " ^
    "$shortcut2.Save();"

echo [+] Atalho 'Central DGS' criado na Área de Trabalho com sucesso!

echo.
echo =======================================================================
echo                 PARABÉNS! INSTALAÇÃO 100%% CONCLUÍDA!
echo =======================================================================
echo.
echo A Central DGS foi configurada perfeitamente na sua máquina.
echo Um atalho foi adicionado na sua Área de Trabalho para uso diário.
echo.
set /p START_NOW="Deseja iniciar a Central DGS agora? (S/N) [Padrão: S]: "
if /i "%START_NOW%"=="N" goto :END

echo.
echo Iniciando Central DGS...
start "" "%~dp0INICIAR_CENTRAL_DGS.vbs"

:END
echo.
echo Obrigado por fazer parte da Comunidade Digital Supply!
timeout /t 5 >nul
exit /b 0
