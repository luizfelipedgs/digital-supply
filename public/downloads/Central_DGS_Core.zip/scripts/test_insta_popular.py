from playwright.sync_api import sync_playwright

def scrape_popular_instagram(topic):
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True)
        page = b.new_page(user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        clean_topic = topic.replace(" ", "").replace("#", "").lower()
        url = f"https://www.instagram.com/popular/{clean_topic}/"
        page.goto(url, timeout=25000)
        page.wait_for_timeout(3000)
        
        # Scroll para carregar mais reels
        for _ in range(3):
            page.evaluate("window.scrollBy(0, 1000)")
            page.wait_for_timeout(1000)
            
        anchors = page.query_selector_all("a")
        results = []
        for a in anchors:
            href = a.get_attribute("href") or ""
            if "/reel/" in href:
                img = a.query_selector("img")
                img_src = img.get_attribute("src") if img else ""
                img_alt = img.get_attribute("alt") if img else ""
                code = href.split("/reel/")[1].split("/")[0] if "/reel/" in href else ""
                if code and not any(r["id"] == code for r in results):
                    results.append({
                        "id": code,
                        "url": f"https://www.instagram.com/reel/{code}/",
                        "cover": img_src,
                        "title": img_alt or f"Reel em alta de #{clean_topic}"
                    })
        print(f"Total de reels reais extraídos de {url}: {len(results)}")
        if results:
            print("Exemplo 1:", results[0])
        b.close()
        return results

scrape_popular_instagram("marketing")
