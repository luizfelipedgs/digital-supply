import urllib.request
import urllib.parse
import json
import re

term = urllib.parse.quote('inteligencia artificial')
url = f'https://html.duckduckgo.com/html/?q=site:tiktok.com+{term}'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
try:
    with urllib.request.urlopen(req, timeout=10) as resp:
        html = resp.read().decode('utf-8', errors='ignore')
        raw_links = re.findall(r'uddg=([^&"\']+)', html)
        tt_links = [urllib.parse.unquote(l) for l in raw_links if 'tiktok.com/@' in urllib.parse.unquote(l) and '/video/' in urllib.parse.unquote(l)]
        print(f"TikTok links reais encontrados: {len(tt_links)}")
        for t in tt_links[:5]:
            print(t)
except Exception as e:
    print(f"Erro: {e}")
