from playwright.sync_api import sync_playwright

def search_tiktok_real(query):
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True)
        page = b.new_page(user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        page.goto(f"https://www.tiktok.com/search?q={query}", timeout=30000)
        page.wait_for_timeout(4000)
        
        cards = page.query_selector_all('div[data-e2e="search_video-item"]')
        print(f"Vídeos encontrados no DOM: {len(cards)}")
        results = []
        for card in cards[:10]:
            a_el = card.query_selector('a[href*="/video/"]')
            img_el = card.query_selector('img')
            desc_el = card.query_selector('div[data-e2e="search-card-video-caption"]') or card.query_selector('span')
            author_el = card.query_selector('p[data-e2e="search-card-user-unique-id"]')
            
            href = a_el.get_attribute('href') if a_el else ""
            img = img_el.get_attribute('src') if img_el else ""
            desc = desc_el.inner_text() if desc_el else ""
            author = author_el.inner_text() if author_el else ""
            
            if href:
                results.append({"url": href, "cover": img, "title": desc, "author": author})
        
        print("Coletados:", len(results))
        if results:
            print("Exemplo 1:", results[0])
        b.close()

search_tiktok_real("marketing")
