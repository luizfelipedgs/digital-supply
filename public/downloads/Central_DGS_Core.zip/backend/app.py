import os
import time
import threading
import shutil
import asyncio
import re
import uuid
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from backend.database import (
    init_db, get_dashboard_stats, get_accounts, add_account, delete_account, update_account,
    get_account_by_id, get_videos, get_video_by_id, add_video, update_video_details, delete_video, 
    get_queue, get_queue_item, add_to_queue, update_queue_details, delete_queue_item, update_queue_status, 
    get_logs, get_setting, set_setting, add_log, verify_account_session, update_account_status
)
from backend.auth_service import (
    login as auth_login, logout as auth_logout, get_current_session,
    admin_get_alunos, admin_update_aluno_status, admin_delete_aluno,
    update_user_avatar, update_user_nickname, PROFILES_DIR
)
from backend.editor_service import (
    get_community_music, get_editor_status, start_batch_processing, MUSIC_DIR
)
from backend.content_service import (
    get_campaigns, get_lessons,
    admin_get_music_library, admin_upload_music_track, admin_rename_music_track, admin_delete_music_track,
    admin_get_lessons, admin_create_lesson, admin_update_lesson, admin_delete_lesson, admin_reorder_lesson,
    admin_get_campaigns, admin_create_campaign, admin_update_campaign, admin_delete_campaign,
    admin_get_announcements, admin_create_announcement, admin_delete_announcement,
    get_grupo_info, admin_update_grupo_settings, admin_create_grupo_regra, admin_update_grupo_regra, admin_delete_grupo_regra,
    get_affiliate_info, admin_update_affiliate_settings,
    get_desktop_tutorial_settings, admin_update_desktop_tutorial_settings
)
from backend.engine import engine
from backend.automation.browser_manager import BrowserManager
from backend.version import VERSION
from backend.updater import check_for_updates, apply_update, restart_central

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
STORAGE_DIR = os.path.join(BASE_DIR, "storage")
VIDEOS_DIR = os.path.join(STORAGE_DIR, "videos")
THUMBNAILS_DIR = os.path.join(STORAGE_DIR, "thumbnails")

os.makedirs(VIDEOS_DIR, exist_ok=True)
os.makedirs(THUMBNAILS_DIR, exist_ok=True)

app = FastAPI(title="Central DGS")

# --- MONITOR DE JANELA & AUTO-FINALIZAÇÃO (HEARTBEAT) ---
_last_heartbeat_time = time.time()
_has_received_heartbeat = False
_is_shutting_down = False

def shutdown_everything(force: bool = False):
    global _is_shutting_down
    if _is_shutting_down:
        return
    _is_shutting_down = True
    print("[Central DGS] Encerrando motor e todos os processos da Central DGS...")
    try:
        engine.stop()
    except Exception as e:
        print("[Central DGS] Erro ao parar motor:", e)

    try:
        add_log("Central DGS encerrada pelo usuário.", "INFO")
    except Exception:
        pass

    def force_exit():
        time.sleep(0.5 if force else 1.0)
        os._exit(0)

    threading.Thread(target=force_exit, daemon=True).start()

def _heartbeat_watchdog():
    global _last_heartbeat_time, _has_received_heartbeat, _is_shutting_down
    # Dá 30 segundos no início para que o navegador abra e o frontend carregue
    time.sleep(30)
    while not _is_shutting_down:
        time.sleep(1.5)
        # Se o sistema já recebeu heartbeat do frontend e parou de receber por mais de 300 segundos (5 minutos de inatividade total):
        if _has_received_heartbeat:
            elapsed = time.time() - _last_heartbeat_time
            if elapsed > 300.0:
                print(f"[Central DGS] Janela da Central foi fechada pelo usuário ({elapsed:.1f}s sem atividade). Encerrando processos...")
                shutdown_everything(force=True)
                break

@app.on_event("startup")
async def startup_event():
    init_db()
    sess = get_current_session()
    if sess.get("has_access", False):
        engine.start()
    threading.Thread(target=_heartbeat_watchdog, daemon=True).start()

@app.on_event("shutdown")
async def shutdown_event():
    shutdown_everything(force=True)

@app.post("/api/system/heartbeat")
async def api_system_heartbeat():
    global _last_heartbeat_time, _has_received_heartbeat
    _last_heartbeat_time = time.time()
    _has_received_heartbeat = True
    return {"status": "ok"}

@app.post("/api/system/shutdown")
async def api_system_shutdown(force: bool = False):
    if not force:
        # Ignora unloads automáticos de abas temporárias ou popups
        return {"success": True, "message": "Ignorado"}
    print(f"[Central DGS] Requisição de encerramento manual recebida.")
    def do_shutdown():
        shutdown_everything(force=True)

    threading.Thread(target=do_shutdown, daemon=True).start()
    return {"success": True, "message": "Encerrando Central DGS..."}

# --- Rotas de Autenticação & Assinatura (Supabase) ---

class LoginRequest(BaseModel):
    email: str
    password: str

@app.get("/api/auth/session")
async def api_auth_session(sync: bool = False):
    return get_current_session(validate_remote=sync)

@app.post("/api/auth/login")
async def api_auth_login(req: LoginRequest):
    try:
        return auth_login(req.email, req.password)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/auth/logout")
async def api_auth_logout():
    return auth_logout()

@app.post("/api/auth/sync")
async def api_auth_sync():
    return get_current_session(validate_remote=True)

class UpdateNicknameRequest(BaseModel):
    nickname: str

@app.post("/api/auth/profile/nickname")
async def api_profile_nickname(req: UpdateNicknameRequest):
    try:
        return update_user_nickname(req.nickname)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/auth/profile/avatar")
async def api_profile_avatar_upload(file: UploadFile = File(...)):
    try:
        file_bytes = await file.read()
        return update_user_avatar(file_bytes, file.filename, file.content_type or "image/jpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/auth/profile/avatar")
async def api_profile_avatar_serve():
    sess = get_current_session()
    user_id = sess.get("user", {}).get("id", "")
    p1 = os.path.join(PROFILES_DIR, f"avatar_{user_id}.jpg")
    if os.path.exists(p1):
        return FileResponse(p1)
    p2 = os.path.join(PROFILES_DIR, "avatar.jpg")
    if os.path.exists(p2):
        return FileResponse(p2)
    raise HTTPException(status_code=404, detail="Avatar não encontrado")

# --- Rotas do Painel Administrativo (Exclusivas is_admin) ---

class AdminUpdateAlunoRequest(BaseModel):
    status: str
    plan: Optional[str] = None

@app.get("/api/admin/alunos")
async def api_admin_alunos():
    try:
        return admin_get_alunos()
    except Exception as e:
        raise HTTPException(status_code=403, detail=str(e))

@app.post("/api/admin/alunos/{user_id}/status")
async def api_admin_update_aluno(user_id: str, req: AdminUpdateAlunoRequest):
    try:
        return admin_update_aluno_status(user_id, req.status, req.plan)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Rotas do Editor de Músicas ---

class EditorProcessRequest(BaseModel):
    audio_source: str
    start_seconds: float = 0.0
    video_ids: Optional[List[int]] = None
    custom_video_paths: Optional[List[str]] = None
    save_to_library: bool = True
    custom_output_dir: Optional[str] = None

@app.get("/api/editor/music-library")
async def api_editor_music_library():
    return get_community_music()

@app.post("/api/editor/upload-music")
async def api_editor_upload_music(file: UploadFile = File(...)):
    filename = file.filename
    dest_path = os.path.join(MUSIC_DIR, filename)
    with open(dest_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {
        "success": True,
        "filename": filename,
        "filepath": dest_path,
        "audio_url": f"/api/editor/audio/{filename}"
    }

@app.get("/api/editor/audio/{filename}")
async def api_editor_serve_audio(filename: str):
    p = os.path.join(MUSIC_DIR, filename)
    if os.path.exists(p):
        return FileResponse(p)
    cached = os.path.join(MUSIC_DIR, f"cached_{filename}")
    if os.path.exists(cached):
        return FileResponse(cached)
    raise HTTPException(status_code=404, detail="Arquivo de áudio não encontrado.")

@app.post("/api/editor/process")
async def api_editor_process(req: EditorProcessRequest):
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada. Acesse digitalsupply.pro para regularizar.")

    video_items = []
    if req.video_ids:
        for vid in req.video_ids:
            item = get_video_by_id(vid)
            if item and os.path.exists(item["filepath"]):
                video_items.append(dict(item))
    if req.custom_video_paths:
        for p in req.custom_video_paths:
            if os.path.exists(p):
                video_items.append({"filepath": p, "title": os.path.basename(p)})

    if not video_items:
        raise HTTPException(status_code=400, detail="Nenhum vídeo válido selecionado para processamento.")

    try:
        return start_batch_processing(
            audio_source=req.audio_source,
            start_seconds=req.start_seconds,
            video_items=video_items,
            save_to_library=True,
            custom_output_dir=req.custom_output_dir
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/editor/status")
async def api_editor_status():
    return get_editor_status()

# --- Rotas de Aulas & Campanhas Unificadas ---
@app.get("/api/campaigns")
async def api_campaigns():
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada.")
    return get_campaigns()

@app.get("/api/lessons")
async def api_lessons():
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada.")
    return get_lessons()

@app.get("/api/grupo")
async def api_grupo():
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada.")
    return get_grupo_info()

@app.get("/api/indique")
async def api_indique():
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada.")
    return get_affiliate_info()

# --- Modelos & Rotas do Painel Administrativo Completo ---

class AdminMusicRename(BaseModel):
    title: str

class AdminLessonCreate(BaseModel):
    title: str
    subtitle: Optional[str] = None
    content_type: str = "video"
    video_url: Optional[str] = None
    body_text: Optional[str] = None
    is_bonus: bool = False

class AdminCampaignCreate(BaseModel):
    title: str
    description: Optional[str] = None
    prize_label: Optional[str] = None
    start_date: str = ""
    end_date: str = ""
    link_url: str = ""
    featured: bool = False

class AdminAnnouncementCreate(BaseModel):
    title: str
    body: Optional[str] = None

class AdminReorderRequest(BaseModel):
    direction: str

class AdminGrupoSettingsUpdate(BaseModel):
    group_link: Optional[str] = None
    title: Optional[str] = "Grupo exclusivo DGS PRO"
    description: Optional[str] = None

class AdminGrupoRegraCreate(BaseModel):
    text: str

class AdminGrupoRegraUpdate(BaseModel):
    text: str

class AdminAffiliateSettingsUpdate(BaseModel):
    affiliate_link: Optional[str] = None
    title: Optional[str] = "Programa de Afiliados DGS"
    commission_headline: Optional[str] = "25% até 40%"
    commission_note: Optional[str] = None
    intro_text: Optional[str] = None

class AdminDesktopTutorialUpdate(BaseModel):
    tutorial_video_url: str

# 1. Admin Músicas
@app.get("/api/admin/music-library")
async def api_admin_get_music():
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_get_music_library()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/music-library/upload")
async def api_admin_upload_music(file: UploadFile = File(...), title: str = Form(...)):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        content = await file.read()
        res = admin_upload_music_track(content, file.filename, title)
        return {"success": True, "data": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.patch("/api/admin/music-library/{track_id}")
async def api_admin_rename_music(track_id: str, req: AdminMusicRename):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_rename_music_track(track_id, req.title)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/admin/music-library/{track_id}")
async def api_admin_delete_music(track_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_delete_music_track(track_id)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 2. Admin Aulas & Treinamento
@app.get("/api/admin/lessons")
async def api_admin_get_lessons():
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_get_lessons()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/lessons")
async def api_admin_create_lesson(req: AdminLessonCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        res = admin_create_lesson(req.title, req.subtitle, req.content_type, req.video_url, req.body_text, req.is_bonus)
        return {"success": True, "data": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.patch("/api/admin/lessons/{lesson_id}")
async def api_admin_update_lesson(lesson_id: str, req: AdminLessonCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_lesson(lesson_id, req.title, req.subtitle, req.content_type, req.video_url, req.body_text, req.is_bonus)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/admin/lessons/{lesson_id}")
async def api_admin_delete_lesson(lesson_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_delete_lesson(lesson_id)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/lessons/{lesson_id}/reorder")
async def api_admin_reorder_lesson(lesson_id: str, req: AdminReorderRequest):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_reorder_lesson(lesson_id, req.direction)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 3. Admin Campanhas
@app.get("/api/admin/campaigns")
async def api_admin_get_campaigns():
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_get_campaigns()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/campaigns")
async def api_admin_create_campaign(req: AdminCampaignCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        res = admin_create_campaign(req.title, req.description, req.prize_label, req.start_date, req.end_date, req.link_url, req.featured)
        return {"success": True, "data": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.patch("/api/admin/campaigns/{campaign_id}")
async def api_admin_update_campaign(campaign_id: str, req: AdminCampaignCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_campaign(campaign_id, req.title, req.description, req.prize_label, req.start_date, req.end_date, req.link_url, req.featured)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/admin/campaigns/{campaign_id}")
async def api_admin_delete_campaign(campaign_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_delete_campaign(campaign_id)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 4. Admin Avisos & Comunicados
@app.get("/api/admin/announcements")
async def api_admin_get_announcements():
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_get_announcements()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/announcements")
async def api_admin_create_announcement(req: AdminAnnouncementCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        res = admin_create_announcement(req.title, req.body)
        return {"success": True, "data": res}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/admin/announcements/{announcement_id}")
async def api_admin_delete_announcement(announcement_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_delete_announcement(announcement_id)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 5. Admin Deletar Aluno
@app.delete("/api/admin/alunos/{user_id}")
async def api_admin_delete_aluno_route(user_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_delete_aluno(user_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 6. Admin Grupo DGS PRO
@app.post("/api/admin/grupo/settings")
async def api_admin_grupo_settings(req: AdminGrupoSettingsUpdate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_grupo_settings(req.group_link, req.title, req.description)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/admin/grupo/regras")
async def api_admin_grupo_regra_create(req: AdminGrupoRegraCreate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_create_grupo_regra(req.text)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.patch("/api/admin/grupo/regras/{regra_id}")
async def api_admin_grupo_regra_update(regra_id: str, req: AdminGrupoRegraUpdate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_grupo_regra(regra_id, req.text)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/admin/grupo/regras/{regra_id}")
async def api_admin_grupo_regra_delete(regra_id: str):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        ok = admin_delete_grupo_regra(regra_id)
        return {"success": ok}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 7. Admin Indique e Ganhe
@app.post("/api/admin/indique/settings")
async def api_admin_indique_settings(req: AdminAffiliateSettingsUpdate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_affiliate_settings(req.affiliate_link, req.title, req.commission_headline, req.commission_note, req.intro_text)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 8. Admin Vídeo Tutorial /bemvindo
@app.get("/api/admin/desktop-settings")
async def api_admin_get_desktop_settings():
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    return get_desktop_tutorial_settings()

@app.post("/api/admin/desktop-settings")
async def api_admin_update_desktop_settings(req: AdminDesktopTutorialUpdate):
    sess = get_current_session()
    if not sess.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Acesso restrito ao administrador.")
    try:
        return admin_update_desktop_tutorial_settings(req.tutorial_video_url)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# 6. Reset Completo de Fila e Motor
@app.post("/api/queue/reset")
async def api_queue_reset():
    from backend.database import get_db
    with get_db() as conn:
        conn.execute("DELETE FROM queue")
    engine.reset_batch()
    add_log("Fila de agendamentos e status do motor resetados com sucesso.", "INFO")
    return {"success": True, "message": "Fila e status do motor resetados com sucesso."}

# --- Rotas da API ---

@app.get("/api/stats")
async def api_stats():
    return get_dashboard_stats()

@app.get("/api/engine/status")
async def api_engine_status():
    return engine.get_status()

@app.post("/api/engine/start")
async def api_engine_start():
    sess = get_current_session()
    if not sess.get("has_access", False):
        raise HTTPException(status_code=403, detail="Assinatura inativa ou expirada. Acesse digitalsupply.pro para regularizar.")
    engine.start()
    return {"success": True, "status": engine.get_status()}
    engine.start()
    return {"success": True, "status": engine.get_status()}

@app.post("/api/engine/stop")
async def api_engine_stop():
    engine.stop()
    return {"success": True, "status": engine.get_status()}

class ToggleSettingRequest(BaseModel):
    enabled: Optional[bool] = None

@app.post("/api/engine/toggle-test")
async def api_toggle_test(req: Optional[ToggleSettingRequest] = None):
    if req is not None and req.enabled is not None:
        new_val = "true" if req.enabled else "false"
    else:
        curr = get_setting("test_mode", "false") == "true"
        new_val = "false" if curr else "true"
    set_setting("test_mode", new_val)
    add_log(f"Modo teste alterado para: {new_val}", "INFO")
    return {"success": True, "test_mode": new_val == "true"}

@app.post("/api/engine/toggle-visibility")
async def api_toggle_visibility(req: Optional[ToggleSettingRequest] = None):
    if req is not None and req.enabled is not None:
        new_val = "true" if req.enabled else "false"
    else:
        curr = get_setting("visible_browser", "true") == "true"
        new_val = "false" if curr else "true"
    set_setting("visible_browser", new_val)
    add_log(f"Navegador visível alterado para: {new_val}", "INFO")
    return {"success": True, "visible_browser": new_val == "true"}

# --- Contas ---

class AccountCreate(BaseModel):
    name: str
    platform: str
    username: Optional[str] = ""

class AccountUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None

@app.get("/api/accounts")
async def api_get_accounts():
    return get_accounts()

@app.post("/api/accounts")
async def api_add_account(acc: AccountCreate):
    acc_id = add_account(acc.name, acc.platform, acc.username or "")
    return {"success": True, "account_id": acc_id}

@app.put("/api/accounts/{account_id}")
async def api_update_account(account_id: int, data: AccountUpdate):
    account = get_account_by_id(account_id)
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada")
    update_account(account_id, name=data.name, username=data.username)
    return {"success": True, "message": "Conta atualizada com sucesso"}

@app.delete("/api/accounts/{account_id}")
async def api_delete_account(account_id: int):
    delete_account(account_id)
    return {"success": True}

@app.post("/api/accounts/{account_id}/open-login")
async def api_open_login(account_id: int):
    account = get_account_by_id(account_id)
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada no banco de dados local.")

    profile_dir = account.get("profile_dir")
    platform = account.get("platform", "instagram").lower()
    acc_name = account.get("name", "")

    if not profile_dir:
        base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "profiles")
        profile_dir = os.path.join(base_dir, f"{platform}_{account_id}")
    os.makedirs(profile_dir, exist_ok=True)

    try:
        # Inicia a janela de login e valida a sessão
        BrowserManager.launch_login_browser(platform, profile_dir, acc_name, account_id)
        add_log(f"Abrindo navegador de login para a conta {account['name']} ({platform}). Aguardando autenticação...", "INFO", platform)
        return {
            "success": True, 
            "message": f"Navegador aberto para {account['name']}. Faça o login na janela ou use o botão 'Cookie' ao lado para conectar instantaneamente. O status atualizará para 'Conectado' automaticamente após a validação."
        }
    except Exception as e:
        add_log(f"Erro ao abrir navegador de login para {account['name']}: {str(e)}", "ERROR", platform)
        raise HTTPException(status_code=500, detail=f"Erro ao abrir navegador: {str(e)}")

class QuickConnect(BaseModel):
    name: str
    username: Optional[str] = ""
    platform: str = "instagram"

@app.post("/api/accounts/quick-connect")
async def api_quick_connect(data: QuickConnect):
    name = (data.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="Por favor, informe a identificação ou @ da conta.")
    
    username = (data.username or "").strip() or name
    if username and not username.startswith("@") and " " not in username:
        username = f"@{username}"
    
    platform = data.platform.lower()
    acc_id = add_account(name=name, platform=platform, username=username)
    
    base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "profiles")
    profile_dir = os.path.join(base_dir, f"{platform}_{acc_id}")
    os.makedirs(profile_dir, exist_ok=True)
    
    try:
        BrowserManager.launch_login_browser(platform, profile_dir, name, acc_id)
        add_log(f"Abrindo navegador de login para a conta {name} ({platform}). Aguardando autenticação...", "INFO", platform)
        return {
            "success": True,
            "account_id": acc_id,
            "message": f"Navegador aberto para {name}! Faça o login com usuário e senha na janela que abriu."
        }
    except Exception as e:
        add_log(f"Erro ao abrir navegador de login para {name}: {str(e)}", "ERROR", platform)
        raise HTTPException(status_code=500, detail=f"Erro ao abrir navegador: {str(e)}")

class CookieImport(BaseModel):
    session_id: str

@app.post("/api/accounts/{account_id}/import-cookie")
async def api_import_cookie(account_id: int, data: CookieImport):
    account = get_account_by_id(account_id)
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada")

    profile_dir = account.get("profile_dir")
    platform = account.get("platform", "").lower()
    if not profile_dir:
        base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "profiles")
        profile_dir = os.path.join(base_dir, f"{platform}_{account_id}")
    os.makedirs(profile_dir, exist_ok=True)

    raw_val = data.session_id.strip()
    if not raw_val:
        raise HTTPException(status_code=400, detail="Valor do cookie não pode ser vazio")

    # Tratamento inteligente do cookie: se o usuário colou com prefixo (ex: sessionid=xxxx) ou lista com ';'
    cookie_val = raw_val
    if "=" in cookie_val and not cookie_val.startswith("{"):
        for part in cookie_val.split(";"):
            part = part.strip()
            if part.lower().startswith("sessionid="):
                cookie_val = part.split("=", 1)[1].strip()
                break
            elif part.lower().startswith("login_info="):
                cookie_val = part.split("=", 1)[1].strip()
                break
    cookie_val = cookie_val.strip("\"' ")

    domain = f".{platform}.com" if platform in ["tiktok", "instagram"] else ".youtube.com"
    cookie_name = "sessionid" if platform in ["instagram", "tiktok"] else "LOGIN_INFO"

    cookies_list = [
        {
            "name": cookie_name,
            "value": cookie_val,
            "domain": domain,
            "path": "/",
            "httpOnly": True,
            "secure": True
        }
    ]

    import json
    json_path = os.path.join(profile_dir, "cookies.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(cookies_list, f, indent=2)

    update_account_status(account_id, "connected")
    add_log(f"Sessão de {account['name']} ({platform}) conectada via importação direta de cookie!", "SUCCESS", platform)
    return {"success": True, "message": "Cookie importado com sucesso! Conta conectada e pronta para publicação."}

class QuickCookie(BaseModel):
    name: str
    username: Optional[str] = ""
    platform: str = "instagram"
    session_id: str

@app.post("/api/accounts/quick-cookie")
async def api_quick_cookie(data: QuickCookie):
    name = (data.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="Por favor, informe a identificação ou @ da conta.")
    raw_val = (data.session_id or "").strip()
    if not raw_val:
        raise HTTPException(status_code=400, detail="Por favor, informe o valor do cookie sessionid.")
    username = (data.username or "").strip() or name
    if username and not username.startswith("@") and " " not in username:
        username = f"@{username}"
    platform = data.platform.lower()

    cookie_val = raw_val
    if "=" in cookie_val and not cookie_val.startswith("{"):
        for part in cookie_val.split(";"):
            part = part.strip()
            if part.lower().startswith("sessionid="):
                cookie_val = part.split("=", 1)[1].strip()
                break
            elif part.lower().startswith("login_info="):
                cookie_val = part.split("=", 1)[1].strip()
                break
    cookie_val = cookie_val.strip("\"' ")

    acc_id = add_account(name=name, platform=platform, username=username)
    base_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "storage", "profiles")
    profile_dir = os.path.join(base_dir, f"{platform}_{acc_id}")
    os.makedirs(profile_dir, exist_ok=True)

    domain = f".{platform}.com" if platform in ["tiktok", "instagram"] else ".youtube.com"
    cookie_name = "sessionid" if platform in ["instagram", "tiktok"] else "LOGIN_INFO"
    cookies_list = [{
        "name": cookie_name,
        "value": cookie_val,
        "domain": domain,
        "path": "/",
        "httpOnly": True,
        "secure": True
    }]
    import json
    json_path = os.path.join(profile_dir, "cookies.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(cookies_list, f, indent=2)

    update_account_status(acc_id, "connected")
    add_log(f"Conta {name} ({platform}) conectada instantaneamente via cookie!", "SUCCESS", platform)
    return {"success": True, "account_id": acc_id, "message": f"Conta {name} conectada com sucesso!"}

@app.post("/api/accounts/{account_id}/verify")
async def api_verify_account(account_id: int):
    is_valid = verify_account_session(account_id)
    return {"success": True, "connected": is_valid, "status": "connected" if is_valid else "disconnected"}

# --- Integração Oficial Meta Graph API (Instagram Business/Creator) ---

class MetaTokenRequest(BaseModel):
    access_token: str

class MetaImportRequest(BaseModel):
    accounts: List[Dict[str, Any]]

# --- Meta OAuth 2.0 (Login Oficial em 1 Clique para Alunos) ---

class MetaSyncRequest(BaseModel):
    page_id: Optional[str] = None

@app.get("/api/meta/session")
async def api_meta_session():
    import json
    from backend.database import get_setting, get_accounts
    raw_sess = get_setting("meta_user_session", "")
    if raw_sess:
        try:
            sess = json.loads(raw_sess)
            return {
                "connected": True,
                "user_name": sess.get("user_name", "Usuário Facebook"),
                "user_id": sess.get("user_id", ""),
                "connected_at": sess.get("connected_at", "")
            }
        except Exception:
            pass

    accounts = get_accounts()
    meta_accs = [a for a in accounts if a.get("connection_type") == "meta_api"]
    if meta_accs:
        return {
            "connected": True,
            "user_name": meta_accs[0].get("name", "Usuário Conectado"),
            "user_id": meta_accs[0].get("meta_account_id", ""),
            "connected_at": meta_accs[0].get("created_at", "")
        }

    return {"connected": False}

@app.post("/api/meta/sync")
async def api_meta_sync(payload: Optional[MetaSyncRequest] = None):
    import json
    from backend.database import get_setting, get_accounts
    from backend.meta_service import validate_token_and_list_accounts

    page_id = payload.page_id.strip() if (payload and payload.page_id) else None

    # Tenta usar o token da sessão do usuário primeiro
    token = ""
    raw_sess = get_setting("meta_user_session", "")
    if raw_sess:
        try:
            sess = json.loads(raw_sess)
            token = sess.get("access_token", "")
        except Exception:
            pass

    # Se não tiver token de sessão, tenta pegar o token de qualquer conta Meta conectada
    if not token:
        accounts = get_accounts()
        meta_accs = [a for a in accounts if a.get("connection_type") == "meta_api" and a.get("meta_access_token")]
        if meta_accs:
            token = meta_accs[0]["meta_access_token"]

    if not token:
        return {
            "success": False,
            "error": "Nenhuma sessão ativa do Facebook encontrada. Por favor, conecte via Facebook primeiro."
        }

    result = validate_token_and_list_accounts(token, page_id=page_id)
    if not result.get("success"):
        return result

    # Marca quais contas já estão importadas no banco local
    existing_accs = get_accounts()
    existing_meta_ids = {str(a.get("meta_account_id")) for a in existing_accs if a.get("meta_account_id")}

    discovered = result.get("accounts", [])
    for acc in discovered:
        acc["is_already_imported"] = str(acc.get("instagram_id")) in existing_meta_ids

    return {
        "success": True,
        "user_name": result.get("user_name", "Usuário Facebook"),
        "accounts": discovered
    }

# --- Rotas de Conexão Oficial Direta pelo Instagram ---
@app.get("/api/instagram/oauth/login")
async def api_instagram_oauth_login(redirect: bool = False):
    from backend.meta_service import get_instagram_direct_oauth_url
    redirect_uri = "http://localhost:8787/api/meta/oauth/callback"
    auth_url = get_instagram_direct_oauth_url(redirect_uri)
    if redirect:
        return RedirectResponse(url=auth_url)
    return {"success": True, "auth_url": auth_url}

@app.get("/api/instagram/oauth/callback")
async def api_instagram_oauth_callback(
    code: Optional[str] = None,
    error: Optional[str] = None,
    error_description: Optional[str] = None
):
    import json
    from backend.meta_service import exchange_instagram_direct_code
    from backend.database import add_or_update_meta_account

    redirect_uri = "http://localhost:8787/api/instagram/oauth/callback"

    if error:
        err_msg = error_description or error or "Autorização cancelada ou recusada no Instagram."
        html_error = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Falha no Login do Instagram</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #ef4444; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(239, 68, 68, 0.15); border: 2px solid #ef4444; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ef4444; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #ef4444; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Falha na Conexão</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'instagram_direct_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_error, status_code=400)

    if not code:
        html_empty = """<!DOCTYPE html><html><body style="background:#0f0f13;color:#fff;font-family:sans-serif;text-align:center;padding:50px;">
        <h3>Nenhum código de autorização recebido do Instagram.</h3><button onclick="window.close()">Fechar</button></body></html>"""
        return HTMLResponse(content=html_empty, status_code=400)

    # Limpa eventual fragmento #_ adicionado pelo Instagram
    clean_code = code.split("#")[0].strip()

    # Troca o código pelo token oficial e descobre a conta diretamente
    result = exchange_instagram_direct_code(code=clean_code, redirect_uri=redirect_uri)

    if not result.get("success"):
        err_msg = result.get("error", "Erro ao obter autorização do Instagram.")
        html_fail = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Erro ao Conectar</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #ef4444; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(239, 68, 68, 0.15); border: 2px solid #ef4444; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ef4444; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #ef4444; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Não foi possível conectar</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'instagram_direct_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_fail, status_code=400)

    acc = result.get("account", {})
    imported_id = None
    try:
        imported_id = add_or_update_meta_account(
            name=acc.get("name") or acc.get("username", "Instagram Oficial"),
            username=acc.get("username", ""),
            meta_account_id=str(acc.get("instagram_id", "")),
            meta_access_token=acc.get("user_access_token", ""),
            meta_page_id="direct_instagram",
            avatar=acc.get("avatar", ""),
            meta_profile_data=json.dumps(acc)
        )
    except Exception as ex:
        print(f"[Instagram Direct] Erro ao salvar conta no banco: {ex}")

    acc_display = acc.get("username") or acc.get("name", "Sua Conta")

    html_success = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Instagram Conectado!</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0b0b10; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #13141f; border: 1px solid #10b981; border-radius: 20px; padding: 36px; max-width: 440px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045); border-radius: 18px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #fff; box-shadow: 0 8px 25px rgba(253, 29, 29, 0.4); }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #10b981; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 24px; line-height: 1.5; }}
    .acc-badge {{ display: inline-block; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3); color: #34d399; padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 13px; margin-bottom: 20px; }}
    .btn {{ background: linear-gradient(135deg, #833ab4, #fd1d1d); color: #fff; border: none; padding: 12px 32px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; transition: 0.2s; }}
    .btn:hover {{ opacity: 0.9; transform: scale(1.02); }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">📷</div>
    <h2>Instagram Conectado!</h2>
    <div class="acc-badge">{acc_display}</div>
    <p>Sua conta do Instagram foi vinculada com sucesso à Central DGS via API Oficial!</p>
    <button class="btn" onclick="window.close()">Concluir</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{
        type: 'instagram_direct_success',
        account: {json.dumps(acc)},
        imported_id: {json.dumps(imported_id)}
      }}, '*');
      setTimeout(function() {{ window.close(); }}, 1800);
    }}
  </script>
</body>
</html>"""
    return HTMLResponse(content=html_success, status_code=200)

# --- TikTok Content Posting API v2 (Login e Publicação Oficial em 1 Clique) ---

@app.get("/api/tiktok/oauth/login")
async def api_tiktok_oauth_login(redirect: bool = False):
    from backend.tiktok_service import get_tiktok_oauth_url
    redirect_uri = "http://localhost:8787/api/tiktok/oauth/callback"
    auth_url = get_tiktok_oauth_url(redirect_uri)
    if redirect:
        return RedirectResponse(url=auth_url)
    return {"success": True, "auth_url": auth_url}

@app.get("/api/tiktok/oauth/callback")
async def api_tiktok_oauth_callback(
    code: Optional[str] = None,
    error: Optional[str] = None,
    error_description: Optional[str] = None,
    state: Optional[str] = None
):
    import json
    from backend.tiktok_service import exchange_code_for_token
    from backend.database import add_or_update_meta_account

    redirect_uri = "http://localhost:8787/api/tiktok/oauth/callback"

    if error:
        err_msg = error_description or error or "Autorização cancelada ou recusada no TikTok."
        html_error = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Falha no Login do TikTok</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #fe2c55; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(254, 44, 85, 0.15); border: 2px solid #fe2c55; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #fe2c55; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #fe2c55; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Falha na Conexão TikTok</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'tiktok_oauth_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_error, status_code=400)

    if not code:
        html_empty = """<!DOCTYPE html><html><body style="background:#0f0f13;color:#fff;font-family:sans-serif;text-align:center;padding:50px;">
        <h3>Nenhum código de autorização recebido do TikTok.</h3><button onclick="window.close()">Fechar</button></body></html>"""
        return HTMLResponse(content=html_empty, status_code=400)

    clean_code = code.split("#")[0].strip()
    result = exchange_code_for_token(code=clean_code, redirect_uri=redirect_uri)

    if not result.get("success"):
        err_msg = result.get("error", "Erro ao obter autorização do TikTok.")
        html_fail = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Erro ao Conectar</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #fe2c55; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(254, 44, 85, 0.15); border: 2px solid #fe2c55; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #fe2c55; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #fe2c55; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Não foi possível conectar</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'tiktok_oauth_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_fail, status_code=400)

    acc = result.get("account", {})
    imported_id = None
    try:
        from backend.database import add_account, get_accounts, update_account_status
        # Salva a conta oficial do TikTok
        # Procura se ja existe
        existing = [a for a in get_accounts() if a.get("platform") == "tiktok" and a.get("meta_account_id") == acc.get("open_id")]
        if existing:
            imported_id = existing[0]["id"]
            import sqlite3
            from backend.database import DB_PATH
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    """UPDATE accounts SET 
                        name = ?, username = ?, avatar = ?, status = 'connected', 
                        connection_type = 'tiktok_api', meta_access_token = ?, 
                        meta_profile_data = ?, last_check = CURRENT_TIMESTAMP 
                       WHERE id = ?""",
                    (
                        acc.get("name") or acc.get("username"),
                        acc.get("username"),
                        acc.get("avatar"),
                        acc.get("access_token"),
                        json.dumps(acc),
                        imported_id
                    )
                )
        else:
            imported_id = add_account(
                name=acc.get("name") or acc.get("username", "TikTok Oficial"),
                platform="tiktok",
                username=acc.get("username", ""),
                avatar=acc.get("avatar", "")
            )
            import sqlite3
            from backend.database import DB_PATH
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    """UPDATE accounts SET 
                        connection_type = 'tiktok_api', meta_account_id = ?, 
                        meta_access_token = ?, meta_profile_data = ? 
                       WHERE id = ?""",
                    (
                        acc.get("open_id"),
                        acc.get("access_token"),
                        json.dumps(acc),
                        imported_id
                    )
                )
    except Exception as ex:
        print(f"[TikTok OAuth] Erro ao salvar conta no banco: {ex}")

    acc_display = acc.get("username") or acc.get("name", "Sua Conta")

    html_success = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>TikTok Conectado!</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0b0b10; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #13141f; border: 1px solid #00f2fe; border-radius: 20px; padding: 36px; max-width: 440px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: linear-gradient(135deg, #00f2fe, #fe2c55); border-radius: 18px; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #fff; box-shadow: 0 8px 25px rgba(254, 44, 85, 0.4); }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #00f2fe; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 24px; line-height: 1.5; }}
    .acc-badge {{ display: inline-block; background: rgba(0, 242, 254, 0.15); border: 1px solid rgba(0, 242, 254, 0.3); color: #00f2fe; padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 13px; margin-bottom: 20px; }}
    .btn {{ background: linear-gradient(135deg, #fe2c55, #00f2fe); color: #fff; border: none; padding: 12px 32px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; transition: 0.2s; }}
    .btn:hover {{ opacity: 0.9; transform: scale(1.02); }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">🎵</div>
    <h2>TikTok Conectado!</h2>
    <div class="acc-badge">{acc_display}</div>
    <p>Sua conta do TikTok foi vinculada com sucesso à Central DGS via TikTok Content Posting API!</p>
    <button class="btn" onclick="window.close()">Concluir</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{
        type: 'tiktok_oauth_success',
        account: {json.dumps(acc)},
        imported_id: {json.dumps(imported_id)}
      }}, '*');
      setTimeout(function() {{ window.close(); }}, 1800);
    }}
  </script>
</body>
</html>"""
    return HTMLResponse(content=html_success, status_code=200)

@app.get("/api/meta/oauth/login")
async def api_meta_oauth_login(redirect: bool = False):
    from backend.meta_service import get_meta_oauth_url
    redirect_uri = "http://localhost:8787/api/meta/oauth/callback"
    auth_url = get_meta_oauth_url(redirect_uri)
    if redirect:
        return RedirectResponse(url=auth_url)
    return {"success": True, "auth_url": auth_url}

@app.get("/api/meta/oauth/callback")
async def api_meta_oauth_callback(
    code: Optional[str] = None,
    error: Optional[str] = None,
    error_description: Optional[str] = None
):
    import json
    from backend.meta_service import exchange_code_for_token
    from backend.database import set_setting, get_accounts

    redirect_uri = "http://localhost:8787/api/meta/oauth/callback"

    if error:
        err_msg = error_description or error or "Autorização cancelada ou recusada no Facebook."
        html_error = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Falha na Conexão Meta</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #ef4444; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(239, 68, 68, 0.15); border: 2px solid #ef4444; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ef4444; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #ef4444; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Falha na Autorização</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'meta_oauth_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_error, status_code=400)

    if not code:
        html_empty = """<!DOCTYPE html><html><body style="background:#0f0f13;color:#fff;font-family:sans-serif;text-align:center;padding:50px;">
        <h3>Nenhum código de autorização recebido da Meta.</h3><button onclick="window.close()">Fechar</button></body></html>"""
        return HTMLResponse(content=html_empty, status_code=400)

    # Troca o código pelo token oficial e descobre as contas
    result = exchange_code_for_token(code=code, redirect_uri=redirect_uri)

    if not result.get("success"):
        err_msg = result.get("error", "Erro ao obter permissões da Meta.")
        html_fail = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Erro ao Conectar</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f0f13; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #181824; border: 1px solid #ef4444; border-radius: 16px; padding: 32px; max-width: 440px; text-align: center; }}
    .icon {{ width: 64px; height: 64px; margin: 0 auto 16px; background: rgba(239, 68, 68, 0.15); border: 2px solid #ef4444; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: #ef4444; }}
    h2 {{ margin: 0 0 8px; font-size: 20px; font-weight: 700; color: #ef4444; }}
    p {{ color: #a1a1aa; font-size: 14px; margin: 0 0 20px; line-height: 1.5; }}
    .btn {{ background: #27273a; color: #fff; border: 1px solid #3f3f5a; padding: 10px 24px; border-radius: 8px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">✕</div>
    <h2>Não foi possível conectar</h2>
    <p>{err_msg}</p>
    <button class="btn" onclick="window.close()">Fechar Janela</button>
  </div>
  <script>
    if (window.opener) {{
      window.opener.postMessage({{ type: 'meta_oauth_error', error: {json.dumps(err_msg)} }}, '*');
    }}
  </script>
</body>
</html>"""
        return HTMLResponse(content=html_fail, status_code=400)

    # Salva a sessão ativa do usuário no banco local para permitir sincronizações futuras com 1 clique
    user_name = result.get("user_name", "Usuário Facebook")
    user_id = result.get("user_id", "")
    access_token = result.get("access_token", "")
    set_setting("meta_user_session", json.dumps({
        "user_name": user_name,
        "user_id": user_id,
        "access_token": access_token,
        "connected_at": datetime.now().isoformat()
    }))

    accounts = result.get("accounts", [])
    existing_accs = get_accounts()
    existing_meta_ids = {str(a.get("meta_account_id")) for a in existing_accs if a.get("meta_account_id")}

    for acc in accounts:
        acc["is_already_imported"] = str(acc.get("instagram_id")) in existing_meta_ids

    count_str = f"{len(accounts)} conta(s) detectada(s)" if accounts else "Nenhuma conta vinculada detectada"

    html_success = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Autorizado com Sucesso!</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0b0b10; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }}
    .card {{ background: #13131d; border: 1px solid #2a2a3d; border-radius: 20px; padding: 36px 32px; max-width: 440px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }}
    .icon-badge {{ width: 72px; height: 72px; margin: 0 auto 20px; background: linear-gradient(135deg, #833ab4, #fd1d1d, #fcb045); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 36px; box-shadow: 0 8px 25px rgba(253, 29, 29, 0.4); }}
    h2 {{ margin: 0 0 10px; font-size: 22px; font-weight: 700; color: #fff; }}
    .highlight {{ color: #38bdf8; font-weight: 600; font-size: 16px; margin-bottom: 8px; }}
    p {{ color: #94a3b8; font-size: 14px; margin: 0 0 24px; line-height: 1.5; }}
    .meta-shield {{ display: inline-flex; align-items: center; gap: 6px; background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); color: #34d399; font-size: 12px; font-weight: 600; padding: 4px 12px; border-radius: 20px; margin-bottom: 20px; }}
    .btn {{ background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; border: none; padding: 12px 28px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon-badge">✓</div>
    <div class="meta-shield">🛡️ Conexão Oficial Meta Graph API</div>
    <h2>Facebook Autorizado!</h2>
    <div class="highlight">{user_name}</div>
    <p>{count_str}.<br>Carregando seleção de contas na Central DGS...</p>
    <button class="btn" onclick="window.close()">Continuar na Central</button>
  </div>
  <script>
    const payload = {{
      type: 'meta_oauth_discovered',
      user_name: {json.dumps(user_name)},
      accounts: {json.dumps(accounts)}
    }};
    if (window.opener) {{
      window.opener.postMessage(payload, '*');
      setTimeout(() => {{ window.close(); }}, 1000);
    }}
  </script>
</body>
</html>"""
    return HTMLResponse(content=html_success, status_code=200)

@app.post("/api/meta/validate-token")
async def api_meta_validate_token(payload: MetaTokenRequest):
    from backend.meta_service import validate_token_and_list_accounts
    result = validate_token_and_list_accounts(payload.access_token)
    return result

@app.post("/api/meta/import-accounts")
async def api_meta_import_accounts(payload: MetaImportRequest):
    import json
    from backend.database import add_or_update_meta_account
    imported_ids = []
    for acc in payload.accounts:
        try:
            aid = add_or_update_meta_account(
                name=acc.get("name", "Instagram Meta"),
                username=acc.get("username", ""),
                meta_account_id=str(acc.get("instagram_id", "")),
                meta_access_token=acc.get("page_access_token") or acc.get("user_access_token", ""),
                meta_page_id=str(acc.get("page_id", "")),
                avatar=acc.get("avatar", ""),
                meta_profile_data=json.dumps(acc)
            )
            imported_ids.append(aid)
        except Exception as ex:
            print(f"Erro ao importar conta Meta: {ex}")

    return {
        "success": True,
        "imported_count": len(imported_ids),
        "imported_ids": imported_ids
    }

@app.get("/api/meta/accounts/{account_id}/insights")
async def api_meta_account_insights(account_id: int):
    account = get_account_by_id(account_id)
    if not account:
        raise HTTPException(status_code=404, detail="Conta não encontrada.")
    if account.get("connection_type") != "meta_api":
        raise HTTPException(status_code=400, detail="Esta conta não está conectada via Meta API.")
    
    from backend.meta_service import get_account_insights
    return get_account_insights(account)

@app.get("/api/meta/media/{queue_id}/insights")
async def api_meta_media_insights(queue_id: int):
    item = get_queue_item(queue_id)
    if not item:
        raise HTTPException(status_code=404, detail="Publicação não encontrada.")
    
    media_id = item.get("meta_media_id")
    if not media_id:
        return {"success": False, "error": "Esta publicação não possui ID de mídia da Meta API."}
    
    account = get_account_by_id(item["account_id"])
    if not account:
        raise HTTPException(status_code=404, detail="Conta associada não encontrada.")
    
    from backend.meta_service import get_reel_insights
    return get_reel_insights(account, media_id)

# --- Vídeos / Biblioteca ---

class VideoUpdate(BaseModel):
    title: str
    caption: str
    hashtags: str

class BulkDeleteVideos(BaseModel):
    video_ids: List[int]

class BatchDownloadRequest(BaseModel):
    video_ids: List[int]

def _build_batch_download_response(ids: List[int]):
    if not ids:
        raise HTTPException(status_code=400, detail="Nenhum ID de vídeo fornecido.")
    
    vids = [get_video_by_id(vid) for vid in ids]
    valid_vids = [v for v in vids if v and os.path.exists(v["filepath"])]
    if not valid_vids:
        raise HTTPException(status_code=404, detail="Nenhum vídeo válido encontrado no disco.")

    if len(valid_vids) == 1:
        v = valid_vids[0]
        fname = v.get("filename") or os.path.basename(v["filepath"])
        return FileResponse(
            v["filepath"],
            media_type="video/mp4",
            filename=fname,
            headers={"Content-Disposition": f'attachment; filename="{fname}"'}
        )

    import zipfile, tempfile
    temp_zip = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    temp_zip_path = temp_zip.name
    temp_zip.close()

    with zipfile.ZipFile(temp_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        used_names = set()
        for v in valid_vids:
            base_name = v.get("filename") or os.path.basename(v["filepath"])
            counter = 1
            entry_name = base_name
            while entry_name in used_names:
                name_part, ext = os.path.splitext(base_name)
                entry_name = f"{name_part}_{counter}{ext}"
                counter += 1
            used_names.add(entry_name)
            zf.write(v["filepath"], arcname=entry_name)

    zip_filename = f"videos_prontos_DGS_{int(datetime.now().timestamp())}.zip"
    return FileResponse(
        temp_zip_path,
        media_type="application/zip",
        filename=zip_filename,
        headers={"Content-Disposition": f'attachment; filename="{zip_filename}"'}
    )

@app.get("/api/videos")
async def api_get_videos():
    return get_videos()

@app.get("/api/videos/batch/download")
async def api_get_batch_download(video_ids: str):
    try:
        ids = [int(x.strip()) for x in video_ids.split(",") if x.strip().isdigit()]
    except Exception:
        ids = []
    return _build_batch_download_response(ids)

@app.post("/api/videos/batch/download")
async def api_post_batch_download(data: BatchDownloadRequest):
    return _build_batch_download_response(data.video_ids)

@app.post("/api/videos/open-folder")
async def api_open_videos_folder():
    """Abre a pasta local de vídeos no Windows Explorer."""
    import subprocess
    os.makedirs(VIDEOS_DIR, exist_ok=True)
    try:
        if os.name == 'nt':
            norm = os.path.normpath(VIDEOS_DIR)
            try:
                subprocess.Popen(['explorer.exe', norm])
            except Exception:
                os.startfile(norm)
        else:
            subprocess.Popen(['xdg-open', VIDEOS_DIR])
        return {"success": True, "path": VIDEOS_DIR}
    except Exception as e:
        return {"success": False, "error": str(e), "path": VIDEOS_DIR}

@app.post("/api/downloader/open-extension-folder")
async def api_open_extension_folder():
    """Abre a pasta descompactada da extensão Chrome no Windows Explorer para o aluno carregar no navegador."""
    import subprocess
    import zipfile
    ext_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "extension-download-massa"))
    os.makedirs(ext_dir, exist_ok=True)

    # Se a pasta estiver vazia ou sem manifest, extrai automaticamente do pacote .zip
    manifest_file = os.path.join(ext_dir, "manifest.json")
    zip_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "static", "DGS_Download_em_Massa_Extensao.zip"))
    if (not os.path.exists(manifest_file) or len(os.listdir(ext_dir)) == 0) and os.path.exists(zip_path):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                zf.extractall(ext_dir)
        except Exception:
            pass

    try:
        if os.name == 'nt':
            norm = os.path.normpath(ext_dir)
            try:
                subprocess.Popen(['explorer.exe', norm])
            except Exception:
                os.startfile(norm)
        else:
            subprocess.Popen(['xdg-open', ext_dir])
        return {"success": True, "path": ext_dir}
    except Exception as e:
        return {"success": False, "error": str(e), "path": ext_dir}

@app.post("/api/downloader/open-downloads-folder")
async def api_open_downloads_folder():
    """Abre a pasta onde os vídeos são salvos pelo Chrome (Downloads/DGS_Downloads)."""
    import subprocess
    user_home = os.path.expanduser("~")
    downloads_dir = os.path.join(user_home, "Downloads", "DGS_Downloads")
    os.makedirs(downloads_dir, exist_ok=True)
    try:
        if os.name == 'nt':
            norm = os.path.normpath(downloads_dir)
            try:
                subprocess.Popen(['explorer.exe', norm])
            except Exception:
                os.startfile(norm)
        else:
            subprocess.Popen(['xdg-open', downloads_dir])
        return {"success": True, "path": downloads_dir}
    except Exception as e:
        return {"success": False, "error": str(e), "path": downloads_dir}

@app.get("/api/downloader/info")
async def api_get_downloader_info():
    """Retorna informações e caminhos do módulo de Download em Massa."""
    ext_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "extension-download-massa"))
    zip_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "static", "DGS_Download_em_Massa_Extensao.zip"))
    return {
        "installed": os.path.exists(ext_dir),
        "extension_path": ext_dir,
        "zip_available": os.path.exists(zip_path),
        "zip_url": "/static/DGS_Download_em_Massa_Extensao.zip",
        "max_batch_limit": 100
    }

@app.get("/api/videos/{video_id}")
async def api_get_video_item(video_id: int):
    vid = get_video_by_id(video_id)
    if not vid:
        raise HTTPException(status_code=404, detail="Vídeo não encontrado")
    return vid

@app.get("/api/videos/{video_id}/stream")
async def api_stream_video(video_id: int):
    vid = get_video_by_id(video_id)
    if not vid or not os.path.exists(vid["filepath"]):
        raise HTTPException(status_code=404, detail="Vídeo não encontrado")
    return FileResponse(vid["filepath"], media_type="video/mp4")

@app.get("/api/videos/{video_id}/download")
async def api_download_video(video_id: int):
    vid = get_video_by_id(video_id)
    if not vid or not os.path.exists(vid["filepath"]):
        raise HTTPException(status_code=404, detail="Vídeo não encontrado")
    filename = vid.get("filename") or os.path.basename(vid["filepath"])
    return FileResponse(
        vid["filepath"],
        media_type="video/mp4",
        filename=filename,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.get("/api/videos/{video_id}/thumbnail")
async def api_get_thumbnail(video_id: int):
    vid = get_video_by_id(video_id)
    if not vid or not os.path.exists(vid["filepath"]):
        raise HTTPException(status_code=404, detail="Vídeo não encontrado")
    
    thumb_path = os.path.join(THUMBNAILS_DIR, f"{video_id}.jpg")
    if not os.path.exists(thumb_path):
        from backend.ffmpeg_utils import generate_video_thumbnail
        generate_video_thumbnail(vid["filepath"], thumb_path)

    if os.path.exists(thumb_path):
        return FileResponse(thumb_path, media_type="image/jpeg")
    raise HTTPException(status_code=404, detail="Thumbnail indisponível")

@app.put("/api/videos/{video_id}")
async def api_update_video(video_id: int, data: VideoUpdate):
    update_video_details(video_id, data.title, data.caption, data.hashtags)
    return {"success": True}

@app.post("/api/videos/upload")
async def api_upload_videos(
    files: List[UploadFile] = File(...),
    title_prefix: str = Form(""),
    caption_template: str = Form(""),
    hashtags: str = Form("")
):
    saved_ids = []
    errors = []
    for file in files:
        if not file or not file.filename:
            continue

        raw_name = os.path.basename(file.filename)
        if not raw_name.lower().endswith(('.mp4', '.mov', '.avi', '.mkv', '.webm')):
            continue

        try:
            # Sanitiza o nome do arquivo para compatibilidade estrita com o sistema de arquivos Windows
            clean_name = re.sub(r'[\\/*?:"<>|]', '_', raw_name)
            unique_prefix = f"{int(datetime.now().timestamp())}_{uuid.uuid4().hex[:6]}"
            safe_filename = f"{unique_prefix}_{clean_name}"
            dest_path = os.path.join(VIDEOS_DIR, safe_filename)

            with open(dest_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)

            size = os.path.getsize(dest_path)
            base_title = title_prefix if title_prefix else os.path.splitext(clean_name)[0]

            vid_id = add_video(
                filename=clean_name,
                filepath=dest_path,
                title=base_title,
                caption=caption_template,
                hashtags=hashtags,
                filesize=size
            )

            # Gera thumbnail do vídeo enviado
            try:
                from backend.ffmpeg_utils import generate_video_thumbnail
                thumb_path = os.path.join(THUMBNAILS_DIR, f"{vid_id}.jpg")
                generate_video_thumbnail(dest_path, thumb_path)
            except Exception:
                pass

            saved_ids.append(vid_id)
        except Exception as e:
            add_log(f"Falha ao processar upload do vídeo {file.filename}: {str(e)}", "ERROR")
            errors.append(f"{file.filename}: {str(e)}")

    if not saved_ids and errors:
        raise HTTPException(status_code=500, detail=f"Erro ao processar arquivo(s): {'; '.join(errors)}")

    return {"success": True, "count": len(saved_ids), "video_ids": saved_ids, "errors": errors}

@app.delete("/api/videos/{video_id}")
async def api_delete_video(video_id: int):
    delete_video(video_id)
    return {"success": True}

@app.post("/api/videos/bulk-delete")
async def api_bulk_delete_videos(data: BulkDeleteVideos):
    for vid in data.video_ids:
        delete_video(vid)
    return {"success": True, "deleted_count": len(data.video_ids)}

class AntiDuplicityRequest(BaseModel):
    video_ids: Optional[List[int]] = None
    brightness: float = 0.04
    contrast: float = 1.08
    saturation: float = 1.03
    crop_scale: float = 1.012
    trim_start: float = 0.2
    trim_end: float = 0.2

@app.post("/api/videos/apply-antiduplicity")
async def api_apply_antiduplicity(data: AntiDuplicityRequest):
    import subprocess
    vids = get_videos()
    if data.video_ids is not None:
        vids = [v for v in vids if v["id"] in data.video_ids]
    
    processed = 0
    vf_filter = f"eq=brightness={data.brightness}:contrast={data.contrast}:saturation={data.saturation},crop=trunc(iw/{data.crop_scale}/2)*2:trunc(ih/{data.crop_scale}/2)*2,scale=1080:1920"

    for vid in vids:
        filepath = vid["filepath"]
        if not os.path.exists(filepath):
            continue
        try:
            from backend.ffmpeg_utils import get_ffmpeg_binary, extract_video_metadata, generate_video_thumbnail
            dur, has_audio = extract_video_metadata(filepath)
            start_cut = data.trim_start
            end_cut = max(start_cut + 1.0, dur - data.trim_end)

            tmp_path = filepath + ".antidup.mp4"
            ffmpeg_bin = get_ffmpeg_binary()
            cmd = [
                ffmpeg_bin, "-ss", str(start_cut), "-to", str(end_cut),
                "-i", filepath, "-vf", vf_filter,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20"
            ]
            if has_audio:
                cmd.extend(["-c:a", "copy"])
            else:
                cmd.append("-an")

            cmd.extend(["-map_metadata", "-1", "-bitexact", tmp_path, "-y"])
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60, check=True)
            if os.path.exists(tmp_path) and os.path.getsize(tmp_path) > 10000:
                os.replace(tmp_path, filepath)
                new_size = os.path.getsize(filepath)
                from backend.database import get_db
                conn = get_db()
                conn.cursor().execute("UPDATE videos SET filesize = ? WHERE id = ?", (new_size, vid["id"]))
                conn.commit()
                conn.close()

                thumb_path = os.path.join(THUMBNAILS_DIR, f"{vid['id']}.jpg")
                generate_video_thumbnail(filepath, thumb_path)
                processed += 1
        except Exception:
            pass

    add_log(f"Filtro Anti-Duplicidade aplicado em {processed} vídeo(s) (Áudio Original Preservado)", "SUCCESS", "system")
    return {"success": True, "processed_count": processed}

# --- Utilitário: Parser de Anotações do Canva (.pptx / .txt) ---

def _native_extract_pptx(file_bytes: bytes) -> List[Dict[str, Any]]:
    """
    Parser nativo de apresentações PPTX baseado em zipfile e xml.etree.
    Executa sem depender de nenhuma biblioteca externa e garante leitura de arquivos gerados pelo Canva.
    """
    import zipfile
    import io
    import xml.etree.ElementTree as ET

    slides_data = []
    with zipfile.ZipFile(io.BytesIO(file_bytes), 'r') as z:
        nl = z.namelist()
        slide_order = []

        # Tenta descobrir a ordem exata dos slides através de ppt/presentation.xml
        if 'ppt/presentation.xml' in nl and 'ppt/_rels/presentation.xml.rels' in nl:
            try:
                rels_root = ET.fromstring(z.read('ppt/_rels/presentation.xml.rels'))
                rel_map = {}
                for rel in rels_root.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
                    r_id = rel.attrib.get('Id')
                    target = rel.attrib.get('Target', '')
                    if 'slide' in target.lower() and 'master' not in target.lower() and 'layout' not in target.lower():
                        if not target.startswith('ppt/'):
                            target = 'ppt/' + target.lstrip('/')
                        rel_map[r_id] = target
                pres_root = ET.fromstring(z.read('ppt/presentation.xml'))
                for sld_id in pres_root.findall('.//{http://schemas.openxmlformats.org/presentationml/2006/main}sldId'):
                    rid = sld_id.attrib.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
                    if rid in rel_map and rel_map[rid] in nl:
                        slide_order.append(rel_map[rid])
            except Exception:
                slide_order = []

        if not slide_order:
            slide_files = [n for n in nl if re.match(r'^ppt/slides/slide\d+\.xml$', n)]
            slide_order = sorted(slide_files, key=lambda s: int(re.search(r'slide(\d+)\.xml', s).group(1)) if re.search(r'slide(\d+)\.xml', s) else 9999)

        # Mapeia cada slide para seu respectivo arquivo de anotações (notesSlide)
        notes_map = {}
        for s_path in slide_order:
            base_s = os.path.basename(s_path)
            rels_path = f'ppt/slides/_rels/{base_s}.rels'
            if rels_path in nl:
                try:
                    s_rels = ET.fromstring(z.read(rels_path))
                    for rel in s_rels.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
                        typ = rel.attrib.get('Type', '')
                        target = rel.attrib.get('Target', '')
                        if 'notesSlide' in typ or 'notesSlide' in target:
                            clean_target = os.path.normpath(os.path.join('ppt/slides', target)).replace('\\', '/')
                            if clean_target in nl:
                                notes_map[s_path] = clean_target
                                break
                except Exception:
                    pass

        p_tag = '{http://schemas.openxmlformats.org/drawingml/2006/main}p'
        for idx, s_path in enumerate(slide_order, start=1):
            note_text = ''
            body_text = ''
            n_path = notes_map.get(s_path)
            if not n_path and f'ppt/notesSlides/notesSlide{idx}.xml' in nl:
                n_path = f'ppt/notesSlides/notesSlide{idx}.xml'

            if n_path and n_path in nl:
                try:
                    n_root = ET.fromstring(z.read(n_path))
                    lines = []
                    for p in n_root.findall(f'.//{p_tag}'):
                        t = ''.join(p.itertext()).strip()
                        if t and not (t.isdigit() and len(t) <= 3):
                            lines.append(t)
                    note_text = '\n'.join(lines).strip()
                except Exception:
                    pass

            if s_path in nl:
                try:
                    s_root = ET.fromstring(z.read(s_path))
                    body_lines = []
                    for p in s_root.findall(f'.//{p_tag}'):
                        t = ''.join(p.itertext()).strip()
                        if t:
                            body_lines.append(t)
                    body_text = '\n'.join(body_lines).strip()
                except Exception:
                    pass

            raw_text = note_text if note_text else body_text
            lines = [l.strip() for l in raw_text.splitlines() if l.strip()]
            tags_list = []
            caption_list = []
            for l in lines:
                if l.startswith('#') or (l.startswith('@') and ' ' not in l):
                    tags_list.append(l)
                else:
                    caption_list.append(l)

            caption = '\n\n'.join(caption_list).strip()
            hashtags = ' '.join(tags_list).strip()
            if not caption and raw_text:
                caption = raw_text
                hashtags = ''

            title = f'Vídeo {idx}'
            if caption_list:
                first = caption_list[0]
                if len(first) <= 70:
                    title = first

            slides_data.append({
                'index': idx,
                'title': title,
                'caption': caption,
                'hashtags': hashtags
            })

    return slides_data

def extract_canva_content(file_bytes: bytes, filename: str) -> List[Dict[str, Any]]:
    lower = filename.lower()
    extracted = []

    if lower.endswith(".pptx"):
        # Tentativa 1: Leitor nativo resiliente (não falha em arquivos do Canva e não exige dependências)
        try:
            native_res = _native_extract_pptx(file_bytes)
            if native_res and len(native_res) > 0:
                return native_res
        except Exception as e:
            add_log(f"Leitor nativo PPTX tentará fallback: {str(e)}", "WARNING")

        # Tentativa 2: Biblioteca python-pptx se instalada
        try:
            import io
            from pptx import Presentation
            prs = Presentation(io.BytesIO(file_bytes))
            for idx, slide in enumerate(prs.slides, start=1):
                note_text = ""
                if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                    note_text = slide.notes_slide.notes_text_frame.text.strip()

                body_text = ""
                for shape in slide.shapes:
                    if shape.has_text_frame and shape.text_frame.text:
                        body_text += shape.text_frame.text.strip() + "\n"

                raw_text = note_text if note_text else body_text.strip()
                lines = [l.strip() for l in raw_text.splitlines() if l.strip()]

                tags_list = []
                caption_list = []
                for l in lines:
                    if l.startswith("#") or (l.startswith("@") and " " not in l):
                        tags_list.append(l)
                    else:
                        caption_list.append(l)

                caption = "\n\n".join(caption_list).strip()
                hashtags = " ".join(tags_list).strip()
                if not caption and raw_text:
                    caption = raw_text
                    hashtags = ""

                title = f"Vídeo {idx}"
                if caption_list:
                    first = caption_list[0]
                    if len(first) <= 70:
                        title = first

                extracted.append({
                    "index": idx,
                    "title": title,
                    "caption": caption,
                    "hashtags": hashtags
                })
            if extracted:
                return extracted
        except Exception:
            pass

    elif lower.endswith((".txt", ".csv")):
        import re
        content = file_bytes.decode("utf-8", errors="ignore")
        blocks = re.split(r'\n\s*\n|(?:\n|^)(?=\d+[\.\)\-]\s+)', content)
        idx = 1
        for blk in blocks:
            b = blk.strip()
            if not b:
                continue
            clean = re.sub(r'^\d+[\.\)\-]\s*', '', b).strip()
            extracted.append({
                "index": idx,
                "title": f"Vídeo {idx}",
                "caption": clean,
                "hashtags": ""
            })
            idx += 1

    return extracted

@app.post("/api/utils/parse-canva-pptx")
async def api_parse_canva_pptx(file: UploadFile = File(...)):
    try:
        content = await file.read()
        if not content:
            return {"success": False, "count": 0, "slides": [], "error": "Arquivo vazio ou inválido."}
        slides = extract_canva_content(content, file.filename)
        return {"success": True, "count": len(slides), "slides": slides, "filename": file.filename}
    except Exception as e:
        add_log(f"Erro ao processar arquivo do Canva ({file.filename}): {str(e)}", "ERROR")
        return {"success": False, "count": 0, "slides": [], "error": f"Falha ao processar arquivo: {str(e)}", "filename": file.filename}

# --- Fila e Agendamento em Massa ---

class IndividualVideoItem(BaseModel):
    video_id: int
    title: Optional[str] = ""
    caption: Optional[str] = ""
    hashtags: Optional[str] = ""
    sound: Optional[str] = ""

class BatchScheduleRequest(BaseModel):
    account_ids: List[int]
    start_time: str
    interval_minutes: int = 180
    mode: Optional[str] = "identical" # "identical" ou "individual"
    video_ids: Optional[List[int]] = []
    custom_title: Optional[str] = ""
    custom_caption: Optional[str] = ""
    custom_hashtags: Optional[str] = ""
    tiktok_sound: Optional[str] = ""
    items: Optional[List[IndividualVideoItem]] = []

class QueueItemUpdate(BaseModel):
    scheduled_time: str
    custom_title: Optional[str] = ""
    custom_caption: Optional[str] = ""
    custom_hashtags: Optional[str] = ""
    custom_sound: Optional[str] = None
    account_id: Optional[int] = None

class BulkQueueAction(BaseModel):
    queue_ids: List[int]

@app.get("/api/queue")
async def api_get_queue():
    return get_queue()

@app.get("/api/queue/{queue_id}")
async def api_get_queue_item(queue_id: int):
    item = get_queue_item(queue_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item da fila não encontrado")
    return item

@app.put("/api/queue/{queue_id}")
@app.patch("/api/queue/{queue_id}")
async def api_update_queue_item(queue_id: int, data: QueueItemUpdate):
    update_queue_details(
        queue_id=queue_id,
        scheduled_time=data.scheduled_time,
        custom_title=data.custom_title or "",
        custom_caption=data.custom_caption or "",
        custom_hashtags=data.custom_hashtags or "",
        custom_sound=data.custom_sound,
        account_id=data.account_id
    )
    add_log(f"Post #{queue_id} atualizado pelo usuário na fila.", "INFO")
    return {"success": True, "message": "Post atualizado com sucesso!"}

@app.post("/api/queue/schedule-batch")
async def api_schedule_batch(req: BatchScheduleRequest):
    if not req.account_ids:
        raise HTTPException(status_code=400, detail="Nenhuma conta selecionada")

    try:
        current_time = datetime.fromisoformat(req.start_time)
    except Exception:
        current_time = datetime.now() + timedelta(minutes=5)

    # Proteção de Conta: Intervalo mínimo de 45 minutos para evitar bloqueios de velocidade da Meta e do TikTok
    safe_interval = max(45, req.interval_minutes) if req.interval_minutes else 180

    created_ids = []
    accounts_map = {a["id"]: a for a in get_accounts()}

    if req.mode == "individual" and req.items:
        # Modo 2: Descrições individuais importadas do Canva ou personalizadas
        for item in req.items:
            for acc_id in req.account_ids:
                acc = accounts_map.get(acc_id)
                if not acc:
                    continue
                scheduled_iso = current_time.strftime("%Y-%m-%dT%H:%M:00")
                qid = add_to_queue(
                    video_id=item.video_id,
                    account_id=acc_id,
                    platform=acc["platform"],
                    scheduled_time=scheduled_iso,
                    custom_title=item.title or "",
                    custom_caption=item.caption or "",
                    custom_hashtags=item.hashtags or req.custom_hashtags or "",
                    custom_sound=item.sound or req.tiktok_sound or ""
                )
                created_ids.append(qid)
            current_time += timedelta(minutes=safe_interval)

    else:
        # Modo 1: Descrições idênticas para todos os vídeos
        if not req.video_ids:
            raise HTTPException(status_code=400, detail="Nenhum vídeo selecionado")

        for v_id in req.video_ids:
            for acc_id in req.account_ids:
                acc = accounts_map.get(acc_id)
                if not acc:
                    continue
                scheduled_iso = current_time.strftime("%Y-%m-%dT%H:%M:00")
                qid = add_to_queue(
                    video_id=v_id,
                    account_id=acc_id,
                    platform=acc["platform"],
                    scheduled_time=scheduled_iso,
                    custom_title=req.custom_title or "",
                    custom_caption=req.custom_caption or "",
                    custom_hashtags=req.custom_hashtags or "",
                    custom_sound=req.tiktok_sound or ""
                )
                created_ids.append(qid)
            current_time += timedelta(minutes=safe_interval)

    add_log(f"Agendamento em massa ({req.mode}): {len(created_ids)} publicações criadas na fila!", "SUCCESS")
    return {"success": True, "scheduled_count": len(created_ids), "queue_ids": created_ids}

@app.post("/api/queue/{queue_id}/post-now")
async def api_post_now(queue_id: int):
    now_str = (datetime.now() - timedelta(minutes=1)).isoformat()
    update_queue_status(queue_id, status="pending", detail="Disparo manual solicitado (Postar agora)")
    from backend.database import get_db, get_queue_item
    conn = get_db()
    conn.cursor().execute("UPDATE queue SET scheduled_time = ? WHERE id = ?", (now_str, queue_id))
    conn.commit()
    conn.close()

    add_log(f"Post #{queue_id} adiantado para postagem imediata", "INFO")
    
    # Inicia o motor se estiver parado e dispara a postagem de forma assíncrona
    engine.ensure_running()
    item = get_queue_item(queue_id)
    if item:
        asyncio.create_task(engine.execute_queue_item(item))

    return {"success": True}

@app.post("/api/queue/bulk-delete")
async def api_bulk_delete_queue(data: BulkQueueAction):
    for qid in data.queue_ids:
        delete_queue_item(qid)
    add_log(f"{len(data.queue_ids)} posts removidos da fila em massa", "INFO")
    return {"success": True, "deleted_count": len(data.queue_ids)}

@app.post("/api/queue/bulk-post-now")
async def api_bulk_post_now(data: BulkQueueAction):
    from backend.database import get_db, get_queue_item
    conn = get_db()
    now_str = (datetime.now() - timedelta(minutes=1)).isoformat()
    for qid in data.queue_ids:
        update_queue_status(qid, status="pending", detail="Disparo em massa solicitado")
        conn.cursor().execute("UPDATE queue SET scheduled_time = ? WHERE id = ?", (now_str, qid))
    conn.commit()
    conn.close()
    add_log(f"{len(data.queue_ids)} posts adiantados para postagem imediata", "INFO")

    engine.ensure_running()
    # Executa os itens
    for qid in data.queue_ids:
        item = get_queue_item(qid)
        if item:
            asyncio.create_task(engine.execute_queue_item(item))

    return {"success": True, "count": len(data.queue_ids)}

@app.post("/api/queue/schedule-instagram-meta")
async def api_schedule_instagram_meta():
    """Dispara imediatamente a programação nativa de posts pendentes do Instagram na Meta."""
    if engine.batch_active:
        return {"success": False, "message": "Já existe um lote de programação em andamento no momento."}

    pending_items = get_queue(status="pending")
    ig_pending = [it for it in pending_items if it.get("platform", "").lower() == "instagram"]
    if not ig_pending:
        return {"success": False, "message": "Nenhum post pendente do Instagram encontrado na fila."}

    acc_id = ig_pending[0]["account_id"]
    account = get_account_by_id(acc_id)
    if not account:
        return {"success": False, "message": "Conta do Instagram não encontrada para o lote."}

    items_for_acc = [it for it in ig_pending if it.get("account_id") == acc_id][:25]
    asyncio.create_task(engine.process_meta_batch(account, items_for_acc))
    return {
        "success": True, 
        "message": f"Agendamento na Meta iniciado para {len(items_for_acc)} vídeos!",
        "count": len(items_for_acc)
    }

@app.delete("/api/queue/{queue_id}")
async def api_delete_queue_item(queue_id: int):
    delete_queue_item(queue_id)
    return {"success": True}

# --- Atualização do Sistema (Auto-Updater) ---

class SystemUpdateRequest(BaseModel):
    patch_url: Optional[str] = None

@app.get("/api/system/version")
async def api_system_version():
    return check_for_updates()

@app.post("/api/system/update")
async def api_system_apply_update(req: Optional[SystemUpdateRequest] = None):
    try:
        patch_url = req.patch_url if req else None
        res = apply_update(patch_url=patch_url)
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/system/restart")
async def api_system_restart():
    restart_central()
    return {"success": True, "message": "Reiniciando Central DGS..."}

# --- Logs ---

@app.get("/api/logs")
async def api_get_logs():
    return get_logs(limit=40)

# --- Frontend estático ---
app.mount("/static", StaticFiles(directory=os.path.join(FRONTEND_DIR, "static")), name="static")

@app.get("/")
async def serve_index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))
