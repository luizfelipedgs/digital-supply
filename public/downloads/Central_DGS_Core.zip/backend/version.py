"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.3.4"
BUILD_DATE = "2026-11-24"
APP_NAME = "Central DGS"
DESCRIPTION = "Central Desktop Unificada - Encerramento automático de processos ao fechar janela, prevenção de instâncias duplicadas, Motor 100% Invisível e Agendamento 3 Redes."
