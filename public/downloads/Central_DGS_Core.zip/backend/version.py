"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.3.3"
BUILD_DATE = "2026-11-24"
APP_NAME = "Central DGS"
DESCRIPTION = "Central Desktop Unificada - Agendamento 3 Redes (Instagram, TikTok, YouTube), Motor 100% Invisível, Automação do TikTok com sincronização de música e capa."
