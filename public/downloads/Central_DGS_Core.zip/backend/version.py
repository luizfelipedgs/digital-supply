"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.6.1"
BUILD_DATE = "2026-11-27"
APP_NAME = "Central DGS"
DESCRIPTION = "Central DGS - Radar Viral Oficial com capas 100% autênticas, scraping nativo de Reels e TikTok sem quotas."
