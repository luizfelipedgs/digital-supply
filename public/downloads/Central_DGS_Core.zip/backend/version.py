"""
Central DGS - Controle de Versão Oficial
"""

VERSION = "2.4.2"
BUILD_DATE = "2026-11-25"
APP_NAME = "Central DGS"
DESCRIPTION = "Central DGS - Publicação direta, agendamento automático e conexão oficial com Instagram e TikTok."
