"""
Módulo de Integração Oficial com a Meta Graph API (Instagram Business/Creator)
Permite:
1. Validação de token e listagem em massa de contas do Instagram vinculadas às Páginas do Facebook.
2. Publicação de Reels oficial diretamente via Resumable Upload (servidor para servidor, sem navegador).
3. Coleta de insights e métricas detalhadas (plays, reach, likes, comments, shares, saves).
"""

import os
import time
import json
import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
from backend.database import add_log, update_queue_status

GRAPH_API_VERSION = "v21.0"
BASE_URL = f"https://graph.facebook.com/{GRAPH_API_VERSION}"

META_APP_ID = os.environ.get("META_APP_ID", "1446800700414572")
META_APP_SECRET = os.environ.get("META_APP_SECRET", "2f2df33685ba9c35226efe91f1d38658")
META_CONFIG_ID = os.environ.get("META_CONFIG_ID", "1191196110146135")
META_SCOPES = "pages_show_list,instagram_basic,instagram_content_publish,instagram_manage_insights,pages_read_engagement"

def get_meta_oauth_url(redirect_uri: str, state: Optional[str] = None, use_unified_login: bool = True) -> str:
    """
    Gera a URL oficial de autorização OAuth 2.0 da Meta para o aluno conectar em 1 clique.
    Usa o Login Unificado da Meta (config_id), permitindo conectar diretamente
    o Instagram sem a necessidade de configurações manuais.
    """
    import urllib.parse
    params = {
        "client_id": META_APP_ID,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "display": "popup"
    }
    if use_unified_login and META_CONFIG_ID:
        params["config_id"] = META_CONFIG_ID
        params["override_default_response_type"] = "true"
    else:
        params["scope"] = META_SCOPES
        params["auth_type"] = "rerequest"
    if state:
        params["state"] = state
    return "https://www.facebook.com/dialog/oauth?" + urllib.parse.urlencode(params)

def get_instagram_direct_oauth_url(redirect_uri: Optional[str] = None, state: Optional[str] = None) -> str:
    """
    Gera a URL oficial de Login Unificado da Meta para Instagram
    (permitindo ao usuário clicar em 'Continuar com o Instagram' e entrar diretamente com usuário/senha do Instagram).
    """
    callback_uri = redirect_uri or "http://localhost:8787/api/meta/oauth/callback"
    return get_meta_oauth_url(callback_uri, state=state, use_unified_login=True)

def exchange_instagram_direct_code(code: str, redirect_uri: str) -> Dict[str, Any]:
    """
    Troca o authorization code retornado pelo login direto do Instagram por um token
    de curta duração e depois por um token de longa duração (60 dias) via graph.instagram.com.
    """
    client = httpx.Client(timeout=30.0)
    try:
        # 1. Troca code por short-lived token via api.instagram.com
        resp = client.post(
            "https://api.instagram.com/oauth/access_token",
            data={
                "client_id": META_APP_ID,
                "client_secret": META_APP_SECRET,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
                "code": code.strip()
            }
        )
        data = resp.json()
        if "error" in data or "error_type" in data:
            err_msg = data.get("error_message") or data.get("error", {}).get("message", "Falha ao autenticar com Instagram.")
            return {"success": False, "error": f"Erro Instagram: {err_msg}"}

        short_token = data.get("access_token")
        user_id = str(data.get("user_id", ""))

        if not short_token:
            return {"success": False, "error": "Nenhum token retornado pelo Instagram."}

        # 2. Troca por long-lived token (60 dias) via graph.instagram.com
        long_token = short_token
        try:
            ex_resp = client.get(
                "https://graph.instagram.com/access_token",
                params={
                    "grant_type": "ig_exchange_token",
                    "client_secret": META_APP_SECRET,
                    "access_token": short_token
                }
            )
            ex_data = ex_resp.json()
            if "access_token" in ex_data:
                long_token = ex_data["access_token"]
        except Exception as e:
            print(f"[Instagram Direct] Aviso ao obter long-lived token: {e}")

        # 3. Busca perfil oficial da conta via graph.instagram.com
        profile_resp = client.get(
            f"https://graph.instagram.com/v21.0/me",
            params={
                "fields": "id,username,name,profile_picture_url,followers_count,media_count",
                "access_token": long_token
            }
        )
        profile_data = profile_resp.json()
        username = profile_data.get("username", "")
        if username and not username.startswith("@"):
            username = f"@{username}"

        return {
            "success": True,
            "account": {
                "instagram_id": str(profile_data.get("id") or user_id),
                "username": username,
                "name": profile_data.get("name") or username,
                "avatar": profile_data.get("profile_picture_url") or "",
                "followers_count": profile_data.get("followers_count", 0),
                "media_count": profile_data.get("media_count", 0),
                "page_id": "direct_instagram",
                "page_name": "Instagram Direto",
                "page_access_token": long_token,
                "user_access_token": long_token
            }
        }
    except Exception as e:
        return {"success": False, "error": f"Erro interno ao processar login direto do Instagram: {str(e)}"}
    finally:
        client.close()

def exchange_code_for_token(code: str, redirect_uri: str) -> Dict[str, Any]:
    """
    Troca o authorization code retornado pelo Facebook por um User Access Token de longa duração (60 dias)
    e já descobre automaticamente todas as contas de Instagram associadas às Páginas.
    """
    client = httpx.Client(timeout=30.0)
    try:
        # 1. Troca code por short-lived user token
        resp = client.get(
            f"{BASE_URL}/oauth/access_token",
            params={
                "client_id": META_APP_ID,
                "client_secret": META_APP_SECRET,
                "redirect_uri": redirect_uri,
                "code": code.strip()
            }
        )
        data = resp.json()
        if "error" in data:
            err_msg = data["error"].get("message", "Falha ao trocar código por token.")
            return {"success": False, "error": f"Erro OAuth da Meta: {err_msg}"}

        short_token = data.get("access_token")
        if not short_token:
            return {"success": False, "error": "Nenhum token retornado pela Meta."}

        # 2. Troca short-lived por long-lived user token (válido por 60 dias)
        long_token = short_token
        try:
            exchange_resp = client.get(
                f"{BASE_URL}/oauth/access_token",
                params={
                    "grant_type": "fb_exchange_token",
                    "client_id": META_APP_ID,
                    "client_secret": META_APP_SECRET,
                    "fb_exchange_token": short_token
                }
            )
            ex_data = exchange_resp.json()
            if "access_token" in ex_data:
                long_token = ex_data["access_token"]
        except Exception as e:
            print(f"[Meta OAuth] Aviso ao trocar por long-lived token: {e}")

        # 3. Descobre contas do Instagram usando o token
        discovery = validate_token_and_list_accounts(long_token)
        if not discovery.get("success"):
            return discovery

        return {
            "success": True,
            "access_token": long_token,
            "user_name": discovery.get("user_name", ""),
            "user_id": discovery.get("user_id", ""),
            "accounts": discovery.get("accounts", [])
        }
    except Exception as e:
        return {"success": False, "error": f"Erro interno ao processar OAuth: {str(e)}"}
    finally:
        client.close()

def validate_token_and_list_accounts(access_token: str, page_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Valida um Access Token do Facebook/Meta e busca todas as contas do Instagram Business/Creator
    vinculadas às Páginas do usuário ou diretamente associadas ao token (User Token ou Page Token).
    """
    clean_token = access_token.strip()
    if not clean_token:
        return {"success": False, "error": "Token de acesso vazio."}

    client = httpx.Client(timeout=30.0)

    try:
        # 1. Valida o dono do token via /me (apenas campos universais id e name)
        me_resp = client.get(f"{BASE_URL}/me", params={"fields": "id,name", "access_token": clean_token})
        me_data = me_resp.json()

        if "error" in me_data:
            err_msg = me_data["error"].get("message", "Token da Meta inválido ou expirado.")
            err_code = me_data["error"].get("code", 0)
            return {
                "success": False,
                "error": f"Erro na validação do Token ({err_code}): {err_msg}"
            }

        user_name = me_data.get("name", "Usuário Meta")
        user_id = me_data.get("id", "")
        discovered_accounts = []
        pages = []

        # 2. Se o token for um Page Token (ou se /me já for uma Página), consulta diretamente o instagram_business_account
        try:
            page_direct_resp = client.get(
                f"{BASE_URL}/me",
                params={
                    "fields": "id,name,instagram_business_account{id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count},connected_instagram_account{id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count}",
                    "access_token": clean_token
                }
            )
            p_data = page_direct_resp.json()
            ig = p_data.get("instagram_business_account") or p_data.get("connected_instagram_account")
            if ig and ig.get("id"):
                uname = ig.get("username", "")
                if uname and not uname.startswith("@"):
                    uname = f"@{uname}"
                discovered_accounts.append({
                    "instagram_id": str(ig["id"]),
                    "username": uname,
                    "name": ig.get("name") or p_data.get("name") or uname,
                    "avatar": ig.get("profile_picture_url") or "",
                    "followers_count": ig.get("followers_count", 0),
                    "follows_count": ig.get("follows_count", 0),
                    "media_count": ig.get("media_count", 0),
                    "page_id": str(p_data.get("id", user_id)),
                    "page_name": p_data.get("name", "Página do Facebook"),
                    "page_access_token": clean_token,
                    "user_access_token": clean_token
                })
        except Exception:
            pass

        # 3. Busca Páginas do Facebook administradas por este usuário via /me/accounts
        try:
            fields = (
                "id,name,category,access_token,"
                "instagram_business_account{"
                "id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count"
                "},connected_instagram_account{"
                "id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count"
                "}"
            )
            accounts_resp = client.get(f"{BASE_URL}/me/accounts", params={"fields": fields, "access_token": clean_token})
            accounts_data = accounts_resp.json()
            if "data" in accounts_data and isinstance(accounts_data["data"], list):
                pages = accounts_data["data"]
                for p in pages:
                    ig = p.get("instagram_business_account") or p.get("connected_instagram_account")
                    if not ig and p.get("id"):
                        page_token = p.get("access_token") or clean_token
                        try:
                            p_resp = client.get(
                                f"{BASE_URL}/{p['id']}",
                                params={
                                    "fields": "id,name,instagram_business_account{id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count},connected_instagram_account{id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count}",
                                    "access_token": page_token
                                }
                            )
                            p_sub = p_resp.json()
                            ig = p_sub.get("instagram_business_account") or p_sub.get("connected_instagram_account")
                        except Exception:
                            pass

                    if ig and ig.get("id"):
                        uname = ig.get("username", "")
                        if uname and not uname.startswith("@"):
                            uname = f"@{uname}"
                        if not any(a["instagram_id"] == str(ig["id"]) for a in discovered_accounts):
                            discovered_accounts.append({
                                "instagram_id": str(ig["id"]),
                                "username": uname,
                                "name": ig.get("name") or p.get("name") or uname,
                                "avatar": ig.get("profile_picture_url") or "",
                                "followers_count": ig.get("followers_count", 0),
                                "follows_count": ig.get("follows_count", 0),
                                "media_count": ig.get("media_count", 0),
                                "page_id": str(p["id"]),
                                "page_name": p.get("name", ""),
                                "page_access_token": p.get("access_token", clean_token),
                                "user_access_token": clean_token
                            })
        except Exception:
            pass

        # 4. Caso debug_token revele profile_id específico (ex: quando o OAuth retorna token de página)
        if not discovered_accounts:
            try:
                app_token = f"{META_APP_ID}|{META_APP_SECRET}"
                dbg = client.get(f"{BASE_URL}/debug_token", params={"input_token": clean_token, "access_token": app_token}).json()
                dbg_data = dbg.get("data", {})
                dbg_profile_id = dbg_data.get("profile_id")
                if dbg_profile_id:
                    p_resp = client.get(
                        f"{BASE_URL}/{dbg_profile_id}",
                        params={
                            "fields": "id,name,instagram_business_account{id,username,name,profile_picture_url,followers_count},connected_instagram_account{id,username,name,profile_picture_url,followers_count}",
                            "access_token": clean_token
                        }
                    )
                    p_sub = p_resp.json()
                    ig = p_sub.get("instagram_business_account") or p_sub.get("connected_instagram_account")
                    if ig and ig.get("id"):
                        uname = ig.get("username", "")
                        if uname and not uname.startswith("@"):
                            uname = f"@{uname}"
                        if not any(a["instagram_id"] == str(ig["id"]) for a in discovered_accounts):
                            discovered_accounts.append({
                                "instagram_id": str(ig["id"]),
                                "username": uname,
                                "name": ig.get("name") or p_sub.get("name") or uname,
                                "avatar": ig.get("profile_picture_url") or "",
                                "followers_count": ig.get("followers_count", 0),
                                "follows_count": ig.get("follows_count", 0),
                                "media_count": ig.get("media_count", 0),
                                "page_id": str(dbg_profile_id),
                                "page_name": p_sub.get("name", "Página Oficial"),
                                "page_access_token": clean_token,
                                "user_access_token": clean_token
                            })
            except Exception:
                pass

        # 5. Páginas conhecidas e registradas do usuário / empresa
        candidate_pages = []
        if page_id:
            candidate_pages.append(str(page_id).strip())
        for default_pid in ["1526579993870498", "1421827047691009"]:
            if default_pid not in candidate_pages:
                candidate_pages.append(default_pid)

        for c_pid in candidate_pages:
            if not c_pid or any(a.get("page_id") == str(c_pid) for a in discovered_accounts):
                continue
            try:
                p_resp = client.get(
                    f"{BASE_URL}/{c_pid}",
                    params={
                        "fields": "id,name,access_token,instagram_business_account{id,username,name,profile_picture_url,followers_count},connected_instagram_account{id,username,name,profile_picture_url,followers_count}",
                        "access_token": clean_token
                    }
                )
                p_data = p_resp.json()
                ig = p_data.get("instagram_business_account") or p_data.get("connected_instagram_account")
                if ig and ig.get("id"):
                    uname = ig.get("username", "")
                    if uname and not uname.startswith("@"):
                        uname = f"@{uname}"
                    if not any(a["instagram_id"] == str(ig["id"]) for a in discovered_accounts):
                        discovered_accounts.append({
                            "instagram_id": str(ig["id"]),
                            "username": uname,
                            "name": ig.get("name") or p_data.get("name") or uname,
                            "avatar": ig.get("profile_picture_url") or "",
                            "followers_count": ig.get("followers_count", 0),
                            "follows_count": ig.get("follows_count", 0),
                            "media_count": ig.get("media_count", 0),
                            "page_id": str(p_data.get("id", c_pid)),
                            "page_name": p_data.get("name", "Central DGS"),
                            "page_access_token": p_data.get("access_token", clean_token),
                            "user_access_token": clean_token
                        })
            except Exception:
                pass

        # Caso alternativo: o token passado pode ser diretamente um Page Token ou Instagram User Token
        if not discovered_accounts:
            try:
                direct_ig_resp = client.get(
                    f"{BASE_URL}/me",
                    params={
                        "fields": "id,name,username,profile_picture_url,followers_count,media_count",
                        "access_token": clean_token
                    }
                )
                direct_ig = direct_ig_resp.json()
                if "username" in direct_ig and "id" in direct_ig:
                    uname = direct_ig.get("username", "")
                    if uname and not uname.startswith("@"):
                        uname = f"@{uname}"
                    discovered_accounts.append({
                        "instagram_id": str(direct_ig["id"]),
                        "username": uname,
                        "name": direct_ig.get("name") or uname,
                        "avatar": direct_ig.get("profile_picture_url") or "",
                        "followers_count": direct_ig.get("followers_count", 0),
                        "follows_count": direct_ig.get("follows_count", 0),
                        "media_count": direct_ig.get("media_count", 0),
                        "page_id": "",
                        "page_name": "",
                        "page_access_token": clean_token,
                        "user_access_token": clean_token
                    })
            except Exception:
                pass

        if not discovered_accounts:
            if len(pages) > 0:
                return {
                    "success": False,
                    "error": (
                        f"Encontramos {len(pages)} página(s) do Facebook no seu perfil ({', '.join(p.get('name', '') for p in pages)}), "
                        "mas nenhuma possui conta do Instagram Comercial ou Criador conectada.\n\n"
                        "💡 Como resolver: No Instagram ou no Meta Business Suite, vincule seu Instagram à sua Página do Facebook e tente novamente."
                    )
                }
            else:
                return {
                    "success": False,
                    "error": (
                        "Nenhuma Página do Facebook foi encontrada com este Token. "
                        "Certifique-se de que sua conta do Facebook possui uma Página criada e vinculada ao Instagram Profissional."
                    )
                }

        return {
            "success": True,
            "user": {"id": user_id, "name": user_name},
            "total_found": len(discovered_accounts),
            "accounts": discovered_accounts
        }

    except Exception as e:
        return {"success": False, "error": f"Erro de conexão com os servidores da Meta: {str(e)}"}
    finally:
        client.close()


def publish_reel_to_meta(
    account: Dict[str, Any],
    video_path: str,
    caption: str,
    hashtags: str = ""
) -> Dict[str, Any]:
    """
    Publica um Reel no Instagram utilizando a API Oficial da Meta com Resumable Upload
    diretamente do computador para os servidores da Meta.
    """
    if not os.path.exists(video_path):
        return {"success": False, "error": f"Arquivo de vídeo não encontrado no disco: {video_path}"}

    file_size = os.path.getsize(video_path)
    if file_size == 0:
        return {"success": False, "error": "Arquivo de vídeo está vazio (0 bytes)."}

    token = account.get("meta_access_token")
    ig_user_id = account.get("meta_account_id")

    if not token or not ig_user_id:
        return {"success": False, "error": "Conta não possui credenciais oficiais da Meta API configuradas."}

    full_caption = caption.strip() if caption else ""
    if hashtags and hashtags.strip():
        full_caption = f"{full_caption}\n\n{hashtags.strip()}".strip()

    client = httpx.Client(timeout=60.0)

    try:
        add_log(f"Iniciando envio oficial de Reel para {account.get('name')} (Meta API)", "INFO", "instagram")

        # -------------------------------------------------------------
        # PASSO 1: Criar Container de Mídia (upload_type=resumable)
        # -------------------------------------------------------------
        init_url = f"{BASE_URL}/{ig_user_id}/media"
        init_payload = {
            "media_type": "REELS",
            "upload_type": "resumable",
            "caption": full_caption,
            "share_to_feed": True,
            "access_token": token
        }

        init_resp = client.post(init_url, data=init_payload)
        init_data = init_resp.json()

        if "error" in init_data:
            err_msg = init_data["error"].get("message", "Erro ao iniciar container de Reel na Meta.")
            return {"success": False, "error": f"Meta API [Init]: {err_msg}"}

        container_id = init_data.get("id")
        upload_uri = init_data.get("uri")

        if not container_id or not upload_uri:
            return {"success": False, "error": f"Meta API não retornou URI de upload. Resposta: {init_data}"}

        add_log(f"Container #{container_id} criado na Meta. Enviando arquivo binário ({file_size / (1024*1024):.1f} MB)...", "INFO", "instagram")

        # -------------------------------------------------------------
        # PASSO 2: Enviar os bytes do vídeo para rupload.facebook.com
        # -------------------------------------------------------------
        with open(video_path, "rb") as f:
            video_bytes = f.read()

        upload_headers = {
            "Authorization": f"OAuth {token}",
            "offset": "0",
            "file_size": str(file_size),
            "Content-Type": "application/octet-stream"
        }

        # Timeout de até 180s para envio do vídeo
        upload_resp = client.post(upload_uri, headers=upload_headers, content=video_bytes, timeout=180.0)
        upload_data = upload_resp.json() if upload_resp.headers.get("content-type", "").startswith("application/json") else {}

        if upload_resp.status_code not in (200, 201):
            err_msg = upload_data.get("error", {}).get("message", f"HTTP {upload_resp.status_code}")
            return {"success": False, "error": f"Falha no envio do vídeo para os servidores da Meta: {err_msg}"}

        add_log(f"Upload binário do vídeo concluído com sucesso. Aguardando processamento da Meta...", "INFO", "instagram")

        # -------------------------------------------------------------
        # PASSO 3: Polling de Status do Container (aguarda status_code == FINISHED)
        # -------------------------------------------------------------
        max_attempts = 40  # 40 * 3s = 120 segundos máximo
        status_url = f"{BASE_URL}/{container_id}"
        is_ready = False

        for attempt in range(max_attempts):
            time.sleep(3)
            check_resp = client.get(status_url, params={"fields": "status_code,status", "access_token": token})
            check_data = check_resp.json()
            code = check_data.get("status_code")

            if code == "FINISHED":
                is_ready = True
                break
            elif code in ("ERROR", "EXPIRED"):
                err_detail = check_data.get("status", "Erro interno de codificação da Meta")
                return {"success": False, "error": f"Meta rejeitou o vídeo: {err_detail}"}

        if not is_ready:
            return {"success": False, "error": "Tempo limite excedido aguardando processamento do vídeo na Meta."}

        add_log(f"Vídeo codificado e aprovado pela Meta. Publicando Reel...", "INFO", "instagram")

        # -------------------------------------------------------------
        # PASSO 4: Publicar o Container de Mídia Oficialmente
        # -------------------------------------------------------------
        publish_url = f"{BASE_URL}/{ig_user_id}/media_publish"
        publish_resp = client.post(publish_url, data={"creation_id": container_id, "access_token": token})
        publish_data = publish_resp.json()

        if "error" in publish_data:
            err_msg = publish_data["error"].get("message", "Falha ao disparar publicação na Meta.")
            return {"success": False, "error": f"Meta API [Publish]: {err_msg}"}

        media_id = publish_data.get("id")
        if not media_id:
            return {"success": False, "error": f"Meta API não retornou ID de mídia publicada: {publish_data}"}

        # -------------------------------------------------------------
        # PASSO 5: Obter o Link Permanente do Reel (Permalink)
        # -------------------------------------------------------------
        permalink = ""
        try:
            link_resp = client.get(f"{BASE_URL}/{media_id}", params={"fields": "permalink,timestamp", "access_token": token})
            link_data = link_resp.json()
            permalink = link_data.get("permalink", f"https://www.instagram.com/reel/{media_id}/")
        except Exception:
            permalink = f"https://www.instagram.com/reel/{media_id}/"

        add_log(f"Reel publicado com sucesso via Meta API Oficial! Link: {permalink}", "SUCCESS", "instagram")

        return {
            "success": True,
            "media_id": str(media_id),
            "container_id": str(container_id),
            "url": permalink,
            "detail": "Publicado oficialmente via Meta API"
        }

    except Exception as e:
        return {"success": False, "error": f"Erro durante publicação via Meta API: {str(e)}"}
    finally:
        client.close()


def get_reel_insights(account: Dict[str, Any], media_id: str) -> Dict[str, Any]:
    """
    Captura métricas e insights detalhados de um Reel publicado via Meta API:
    - plays (visualizações de vídeo)
    - reach (alcance de contas únicas)
    - likes (curtidas)
    - comments (comentários)
    - shares (compartilhamentos)
    - saved (salvamentos)
    - total_interactions (engajamento total)
    """
    token = account.get("meta_access_token")
    if not token or not media_id:
        return {"success": False, "error": "Credenciais ou Media ID ausente."}

    client = httpx.Client(timeout=25.0)

    try:
        # Métricas suportadas para Reels no Instagram Graph API v21.0
        metrics = "reach,plays,saved,shares,comments,likes,total_interactions"
        resp = client.get(
            f"{BASE_URL}/{media_id}/insights",
            params={"metric": metrics, "access_token": token}
        )
        data = resp.json()

        if "error" in data:
            return {"success": False, "error": data["error"].get("message", "Erro ao obter métricas da Meta.")}

        metrics_map = {}
        for item in data.get("data", []):
            name = item.get("name")
            values = item.get("values", [])
            val = values[0].get("value", 0) if values else 0
            metrics_map[name] = val

        return {
            "success": True,
            "media_id": media_id,
            "plays": metrics_map.get("plays", 0),
            "reach": metrics_map.get("reach", 0),
            "likes": metrics_map.get("likes", 0),
            "comments": metrics_map.get("comments", 0),
            "shares": metrics_map.get("shares", 0),
            "saved": metrics_map.get("saved", 0),
            "total_interactions": metrics_map.get("total_interactions", 0),
            "updated_at": datetime.now().isoformat()
        }

    except Exception as e:
        return {"success": False, "error": f"Erro ao consultar insights da Meta: {str(e)}"}
    finally:
        client.close()


def get_account_insights(account: Dict[str, Any]) -> Dict[str, Any]:
    """
    Busca informações cadastrais e métricas globais do perfil do Instagram.
    """
    token = account.get("meta_access_token")
    ig_user_id = account.get("meta_account_id")

    if not token or not ig_user_id:
        return {"success": False, "error": "Conta não possui credenciais Meta API configuradas."}

    client = httpx.Client(timeout=25.0)

    try:
        # Perfil
        profile_resp = client.get(
            f"{BASE_URL}/{ig_user_id}",
            params={
                "fields": "id,username,name,profile_picture_url,biography,followers_count,follows_count,media_count",
                "access_token": token
            }
        )
        profile_data = profile_resp.json()

        if "error" in profile_data:
            err_msg = profile_data["error"].get("message")
            # Fallback para dados salvos da conta se houver
            saved = {}
            if account.get("meta_profile_data"):
                try:
                    saved = json.loads(account["meta_profile_data"])
                except Exception:
                    pass
            if saved:
                return {
                    "success": True,
                    "username": saved.get("username", account.get("username", "")),
                    "name": saved.get("name", account.get("name", "")),
                    "avatar": saved.get("avatar", account.get("avatar", "")),
                    "followers_count": saved.get("followers_count", saved.get("followers", 0)),
                    "media_count": saved.get("media_count", 0),
                    "reach_30d": saved.get("reach_30d", 0),
                    "impressions_30d": saved.get("impressions_30d", 0),
                    "cached": True
                }
            return {"success": False, "error": err_msg}

        # Insights da conta (últimos 30 dias de alcance e impressões)
        insights_resp = client.get(
            f"{BASE_URL}/{ig_user_id}/insights",
            params={
                "metric": "reach,impressions,profile_views",
                "period": "day",
                "access_token": token
            }
        )
        insights_data = insights_resp.json()

        reach_total = 0
        impressions_total = 0
        if "data" in insights_data:
            for item in insights_data["data"]:
                m_name = item.get("name")
                for val_obj in item.get("values", []):
                    v = val_obj.get("value", 0)
                    if m_name == "reach":
                        reach_total += v
                    elif m_name == "impressions":
                        impressions_total += v

        return {
            "success": True,
            "username": profile_data.get("username", ""),
            "name": profile_data.get("name", ""),
            "avatar": profile_data.get("profile_picture_url", ""),
            "followers_count": profile_data.get("followers_count", 0),
            "media_count": profile_data.get("media_count", 0),
            "reach_30d": reach_total,
            "impressions_30d": impressions_total
        }

    except Exception as e:
        return {"success": False, "error": f"Erro ao consultar insights da conta: {str(e)}"}
    finally:
        client.close()
