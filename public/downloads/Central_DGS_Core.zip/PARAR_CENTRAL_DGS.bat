@echo off
chcp 65001 >nul
title Encerrar Central DGS
color 0C

echo ========================================================
echo               ENCERRAR CENTRAL DGS
echo ========================================================
echo.
echo Finalizando todos os processos da Central DGS...

:: 1. Encerra processos associados à porta 8787
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8787') do (
    if not "%%a"=="0" (
        taskkill /F /PID %%a >nul 2>&1
    )
)

:: 2. Encerra qualquer processo Python executando run.py
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -like '*python*' -and $_.CommandLine -like '*run.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

echo [+] Todos os processos da Central DGS foram finalizados com sucesso!
timeout /t 2 >nul
exit /b 0
